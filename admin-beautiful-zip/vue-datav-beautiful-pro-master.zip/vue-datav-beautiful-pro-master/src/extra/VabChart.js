import * as echarts from 'echarts'
import VabChart from 'vue-echarts'
import theme from './vab-echarts-theme.json'
echarts.registerTheme('vab-echarts-theme', theme)
VabChart.graphic = echarts.graphic
export default VabChart
