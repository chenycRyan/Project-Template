<template>
  <div class="index-container">
    <router-link target="_blank" to="/home">
      <el-button>看板1点我演示</el-button>
    </router-link>
    <router-link target="_blank" to="/map">
      <el-button>看板2点我演示</el-button>
    </router-link>
  </div>
</template>

<script>
  export default {
    name: 'Index',
  }
</script>

<style lang="scss" scoped>
  .index-container {
    padding-top: 20px;
  }

  ::v-deep {
    a + a {
      margin-left: 10px;
    }
  }
</style>
