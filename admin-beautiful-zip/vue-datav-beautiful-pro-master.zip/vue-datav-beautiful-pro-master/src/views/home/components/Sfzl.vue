<template>
  <div class="sfzl">
    <div class="sfzl-background">
      <div
        style="
          font-size: 16px;
          color: #07f5ff;
          padding-top: 48px;
          margin-left: -10px;
          font-weight: bold;
        "
      >
        算法种类
      </div>
      <div class="sfzl-tag" style="left: 65px; top: 20px">目标检测</div>
      <div class="sfzl-tag" style="left: 10px; top: 60px">图像分割</div>
      <div class="sfzl-tag" style="left: 72px; top: 105px">图像分类</div>
      <div class="sfzl-tag" style="left: 172px; top: 115px">人脸识别</div>
      <div class="sfzl-tag" style="right: 78px; top: 105px">图像检索</div>
      <div class="sfzl-tag" style="right: 10px; top: 60px">GAN网络</div>
      <div class="sfzl-tag" style="right: 72px; top: 25px">...</div>
    </div>
  </div>
</template>
<style lang="scss" scoped>
  .sfzl {
    position: relative;
    height: 100%;

    &-background {
      margin: auto;
      background: url('~@/assets/ai_big_data_images/zhonglei.png') no-repeat;
      background-size: 100% 80%;
      margin-top: 10%;
      width: 90%;
      height: 200px;
      animation: twinkImage 10s linear infinite;
    }

    &-tag {
      position: absolute;
      width: 28px;
      height: 30px;
      font-size: 12px;
      color: #53fcf9;
      background: linear-gradient(0deg, #53fcf9 0%, #ffffff 100%);
      background-clip: text;
      -webkit-text-fill-color: transparent;
    }
  }
</style>
