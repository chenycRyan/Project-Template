<template>
  <div class="sfzyc">
    <div class="sfzyc-panel">
      <div class="sfzyc-node">节点1</div>
      <vab-chart :option="options" autoresize theme="vab-echarts-theme" />
      <div class="sfzyc-text">
        <el-row>
          <el-col :span="11">
            <span>20%</span>
            <p>CPU剩余</p>
          </el-col>
          <el-col :span="2">
            <div class="sfzyc-line"></div>
          </el-col>
          <el-col :span="11">
            <span>15%</span>
            <p>内存剩余</p>
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="sfzyc-panel">
      <div class="sfzyc-node">节点2</div>
      <vab-chart :option="options" autoresize theme="vab-echarts-theme" />
      <div class="sfzyc-text">
        <el-row>
          <el-col :span="11">
            <span>30%</span>
            <p>CPU剩余</p>
          </el-col>
          <el-col :span="2">
            <div class="sfzyc-line"></div>
          </el-col>
          <el-col :span="11">
            <span>10%</span>
            <p>内存剩余</p>
          </el-col>
        </el-row>
      </div>
    </div>
    <div class="sfzyc-panel">
      <div class="sfzyc-node">节点3</div>
      <vab-chart :option="options" autoresize theme="vab-echarts-theme" />
      <div class="sfzyc-text">
        <el-row>
          <el-col :span="11">
            <span>40%</span>
            <p>CPU剩余</p>
          </el-col>
          <el-col :span="2">
            <div class="sfzyc-line"></div>
          </el-col>
          <el-col :span="11">
            <span>20%</span>
            <p>内存剩余</p>
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>

<script>
  import * as echarts from 'echarts'
  import VabChart from '@/extra/VabChart'
  import { getAllNodeResource } from '@/api/kanban'

  export default {
    name: 'Sfzyc',
    components: { VabChart },
    data() {
      return {
        options: {
          title: [
            {
              text: 'Gpu剩余',
              x: 'center',
              top: '50%',
              textStyle: {
                color: '#fff',
                fontSize: 14,
              },
            },
            {
              text: '14%',
              x: 'center',
              top: '40%',
              textStyle: {
                fontSize: 14,
                color: '#fff',
              },
            },
          ],
          polar: {
            radius: ['60%', '70%'],
            center: ['50%', '50%'],
          },
          grid: { top: 0, left: 0, right: 0, bottom: 0 },
          angleAxis: {
            max: 100,
            show: false,
          },
          radiusAxis: {
            type: 'category',
            show: true,
            axisLabel: {
              show: false,
            },
            axisLine: {
              show: false,
            },
            axisTick: {
              show: false,
            },
          },
          series: [
            {
              name: '',
              type: 'bar',
              roundCap: true,
              barWidth: 60,
              showBackground: true,
              backgroundStyle: {
                color: 'rgba(66, 66, 66, .3)',
              },
              data: [60],
              coordinateSystem: 'polar',

              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 1, 0, 0, [
                    {
                      offset: 0,
                      color: '#449EFF',
                    },
                    {
                      offset: 1,
                      color: '#60DAFF',
                    },
                  ]),
                },
              },
            },
            {
              type: 'gauge',
              name: '',
              radius: '57%',
              startAngle: '0',
              endAngle: '-359.99',
              splitNumber: '200',
              center: ['50%', '50%'],
              pointer: {
                show: false,
              },
              title: {
                show: false,
              },
              detail: {
                show: false,
              },
              data: [
                {
                  value: 95,
                  name: '',
                },
              ],
              axisLine: {
                lineStyle: {
                  width: 20,
                  opacity: 0,
                },
              },
              axisTick: {
                show: false,
              },
              splitLine: {
                show: false,
                length: 13,
                lineStyle: {
                  color: {
                    type: 'linear',
                    x: 1,
                    y: 0,
                    x2: 0,
                    y2: 0,
                    colorStops: [
                      {
                        offset: 0,
                        color: '#111',
                      },
                      {
                        offset: 0.5,
                        color: 'rgba(66, 66, 66, 1)',
                      },
                      {
                        offset: 1,
                        color: '#111',
                      },
                    ],
                    globalCoord: false,
                  },
                  width: 1,
                  type: 'solid',
                },
              },
              axisLabel: {
                show: false,
              },
            },
          ],
        },
      }
    },
    created() {
      getAllNodeResource().then(({ data }) => {
        this.options.title[1].text = data[0].gpuAvailable
        this.options.angleAxis.max = data[0].gpuMemTotal
        console.log(data)
        this.options.series[0].data = [data[0].gpuUsedTotal]
      })
      setInterval(() => {
        getAllNodeResource().then(({ data }) => {
          this.options.title[1].text = data[0].gpuAvailable
          this.options.angleAxis.max = data[0].gpuMemTotal
          console.log(data)
          this.options.series[0].data = [data[0].gpuUsedTotal]
        })
      }, 1000 * 15)
    },
  }
</script>
<style lang="scss" scoped>
  .sfzyc {
    position: relative;
    height: 100%;
    &:before {
      content: '';
      display: block;
      clear: both;
    }
    &-panel {
      width: 33.333%;
      height: 100%;
      float: left;
      position: relative;
      ::v-deep {
        .echarts {
          width: 100%;
          height: 80%;
          margin-top: -3%;
          margin-bottom: -6%;
        }
      }
    }
    &-node {
      width: 60px;
      margin: 2% auto 0 auto;
      height: 20px;
      background: url('~@/assets/ai_big_data_images/bbb.jpg') no-repeat;
      background-size: 100% 100%;
    }
    &-text {
      width: 120px;
      margin: 0 auto 0 auto;
      span {
        font-size: 12px;
        color: #01d6e8;
      }
      p {
        font-size: 12px;
      }
    }
    &-line {
      width: 1px;
      height: 18px;
      background: #ffffff;
      opacity: 0.5;
      margin: 10px auto;
    }
  }
</style>
