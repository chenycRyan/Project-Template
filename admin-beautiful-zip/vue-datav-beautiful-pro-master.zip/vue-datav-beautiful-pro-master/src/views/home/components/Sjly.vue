<template>
  <div class="sjly">
    <el-image
      class="sjly-image"
      :src="require('@/assets/ai_big_data_images/laiyuan.png')"
    />
    <div class="sjly-tag" style="left: 20px; top: 60px; color: #0b8ecc">
      北京
    </div>
    <div class="sjly-tag" style="left: 100px; top: 30px; color: #11c1b2">
      烟台
    </div>
    <div class="sjly-tag" style="right: 80px; top: 70px; color: #db402d">
      济南
    </div>
    <div class="sjly-tag" style="left: 70px; top: 100px; color: #11c1b2">
      城阳
    </div>
    <div class="sjly-tag" style="right: 100px; bottom: 40px; color: #f8bd29">
      潍坊
    </div>
    <div class="sjly-tag" style="right: 10px; bottom: 140px; color: #f8bd29">
      上海
    </div>
    <div class="sjly-tag" style="right: 50px; bottom: 80px; color: #0b8ecc">
      即墨
    </div>
    <div class="sjly-tag" style="left: 50px; bottom: 80px; color: #0b8ecc">
      南京
    </div>
  </div>
</template>
<style lang="scss" scoped>
  .sjly {
    position: relative;
    height: 100%;

    &-image {
      position: absolute;
      bottom: 30%;
      right: 130px;
      animation: twinkImage 10s linear infinite;
    }

    &-tag {
      position: absolute;
      width: 60px;
      height: 20px;
      line-height: 20px;
      border: 1px solid #0e2348;
      border-radius: 99px;
      font-size: 12px;
      animation: twink 2s linear infinite;
    }

    @keyframes twinkImage {
      0% {
        opacity: 0.9;
        transform: scale(1);
      }
      50% {
        opacity: 1;
        transform: scale(1.1);
      }
      100% {
        opacity: 0.9;
        transform: scale(1);
      }
    }
  }
</style>
