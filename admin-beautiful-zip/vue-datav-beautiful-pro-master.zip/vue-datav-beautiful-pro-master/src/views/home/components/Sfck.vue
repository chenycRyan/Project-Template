<template>
  <div class="sfck">
    <div class="sfck-panel">
      <div class="sfck-count">
        <vab-count
          v-if="show"
          :start-val="countConfig1.startVal"
          :end-val="countConfig1.endVal"
        />
      </div>
      <div class="sfck-text">市场化模型</div>
    </div>
    <div class="sfck-panel">
      <div class="sfck-count">
        <vab-count
          v-if="show"
          :start-val="countConfig2.startVal"
          :end-val="countConfig2.endVal"
        />
      </div>
      <div class="sfck-text">算法框架</div>
    </div>
    <div class="sfck-panel">
      <div class="sfck-count">
        <vab-count
          v-if="show"
          :start-val="countConfig3.startVal"
          :end-val="countConfig3.endVal"
        />
      </div>
      <div class="sfck-text">算法模型</div>
    </div>
  </div>
</template>
<script>
  import { VabCount } from 'zx-count'
  export default {
    name: 'Sfck',
    components: { VabCount },
    props: {
      item: {
        type: Object,
        default: () => {},
      },
    },
    data() {
      return {
        show: true,
        countConfig1: {
          startVal: 0,
          endVal: 0,
        },
        countConfig2: {
          startVal: 0,
          endVal: 0,
        },
        countConfig3: {
          startVal: 0,
          endVal: 0,
        },
      }
    },
    mounted() {
      setTimeout(() => {
        this.handleCount()
      }, 1000)
      setInterval(() => {
        this.handleCount()
      }, 1000 * 15)
    },
    methods: {
      handleCount() {
        this.show = false
        setTimeout(() => {
          this.countConfig1 = {
            startVal: 0,
            endVal: this.item.marketAlgoModelNum,
          }
          this.countConfig2 = {
            startVal: 0,
            endVal: this.item.marketAlgoModelNum,
          }
          this.countConfig3 = {
            startVal: 0,
            endVal: this.item.algoModelNum,
          }
          this.show = true
        }, 0)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .sfck {
    position: relative;
    height: 100%;
    padding-top: 5vh;
    &:before {
      content: '';
      display: block;
      clear: both;
    }
    &-panel {
      background: red;
      width: 33.3333%;
      height: 100%;
      float: left;
      position: relative;
      background: url('~@/assets/ai_big_data_images/qq.png') no-repeat;
    }
    &-count {
      width: 100%;
      text-align: center;
      font-size: 28px;
      font-weight: 400;
      color: #8bdee6;
      position: absolute;
      top: 45px;
      animation: twinkImage 10s linear infinite;
    }
    &-text {
      width: 100%;
      text-align: center;
      font-size: 12px;
      font-weight: 400;
      color: #ffffff;
      position: absolute;
      top: 80px;
    }
  }
</style>
