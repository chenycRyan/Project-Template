<template>
  <el-row>
    <el-col :span="24">
      <div class="home-header">
        <span>Vdb Pro 数据大屏</span>
      </div>
    </el-col>
  </el-row>
</template>
<style lang="scss" scoped>
  .home {
    &-header {
      background: url('~@/assets/ai_big_data_images/bgtop.png') no-repeat;
      background-size: 100% 100%;
      width: 100%;
      margin-bottom: 20px;
      span {
        font-size: 36px;
        font-family: Microsoft YaHei;
        font-weight: bold;
        color: #33e6fa;
        background: linear-gradient(
          -90deg,
          #7cedfb 0%,
          #2ba3ff 0%,
          #02efff 50.2685546875%,
          #2ea5f9 100%
        );
        background-clip: text;
        -webkit-text-fill-color: transparent;

        &::before {
          position: absolute;
          left: 0%;
          display: block;
          width: 100%;
          color: #fff;
          content: 'Vdb Pro 数据大屏';
          background-image: linear-gradient(
            65deg,
            transparent 10%,
            rgba(255, 255, 255, 1) 20%,
            rgba(255, 255, 255, 1) 27.5%,
            transparent 30%,
            transparent 100%
          );
          background-clip: text;
          animation: flare 5s infinite;
        }

        &::after {
          position: absolute;
          top: 0;
          z-index: -1;
          display: block;
          color: #fff;
          content: 'Vdb Pro 数据大屏';
        }
        @keyframes flare {
          0% {
            background-position: -180px;
          }

          30% {
            background-position: 900px;
          }

          100% {
            background-position: 900px;
            opacity: 0;
          }
        }
      }
    }
  }
</style>
