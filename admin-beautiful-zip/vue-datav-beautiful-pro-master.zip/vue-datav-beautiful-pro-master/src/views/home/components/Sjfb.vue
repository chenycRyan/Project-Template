<template>
  <div class="sjfb">敬请期待</div>
</template>

<style lang="scss" scoped>
  .sjfb {
    position: relative;
    height: 100%;
  }
</style>
<script></script>
<style lang="scss" scoped>
  ::v-deep {
    .echarts {
      width: 100%;
      height: 100%;
    }
  }
</style>
