<template>
  <div class="sjdt">
    <div class="sjdt-panel">
      <el-image :src="require('@/assets/ai_big_data_images/ic01.png')" />
      <div class="sjdt-count">
        <a>
          <vab-count
            v-if="show"
            :start-val="countConfig1.startVal"
            :end-val="countConfig1.endVal"
          />
        </a>
        <span>张/{{ fileSize }}T</span>
      </div>
      <div class="sjdt-tilte">总图像量</div>
    </div>
    <div class="sjdt-panel">
      <el-image :src="require('@/assets/ai_big_data_images/ic02.png')" />
      <div class="sjdt-count">
        <a>
          <vab-count
            v-if="show"
            :start-val="countConfig2.startVal"
            :end-val="countConfig2.endVal"
          />
        </a>
        <span>张/{{ labelFileSize }}T</span>
      </div>
      <div class="sjdt-tilte">总标注量</div>
    </div>
    <div class="sjdt-panel">
      <el-image :src="require('@/assets/ai_big_data_images/ic03.png')" />
      <div class="sjdt-count">
        <a>
          <vab-count
            v-if="show"
            :start-val="countConfig3.startVal"
            :end-val="countConfig3.endVal"
          />
        </a>
        <span>张/{{ todayAddFileSize }}T</span>
      </div>
      <div class="sjdt-tilte">今日新增图像</div>
    </div>
    <div class="sjdt-panel">
      <el-image :src="require('@/assets/ai_big_data_images/ic04.png')" />
      <div class="sjdt-count">
        <a>
          <vab-count
            v-if="show"
            :start-val="countConfig4.startVal"
            :end-val="countConfig4.endVal"
          />
        </a>
        <span>张/{{ todayLabelFileSize }}T</span>
      </div>
      <div class="sjdt-tilte">今日新增标注</div>
    </div>
  </div>
</template>
<script>
  import { VabCount } from 'zx-count'
  export default {
    name: 'SJdt',
    components: { VabCount },
    props: {
      item: {
        type: Object,
        default: () => {},
      },
    },
    data() {
      return {
        show: true,
        countConfig1: {
          startVal: 0,
          endVal: 0,
        },
        countConfig2: {
          startVal: 0,
          endVal: 0,
        },
        countConfig3: {
          startVal: 0,
          endVal: 0,
        },
        countConfig4: {
          startVal: 0,
          endVal: 0,
        },
        fileSize: 0,
        labelFileSize: 0,
        todayAddFileSize: 0,
        todayLabelFileSize: 0,
      }
    },
    mounted() {
      setTimeout(() => {
        this.handleCount()
      }, 1000)
      setInterval(() => {
        this.handleCount()
      }, 1000 * 15)
    },
    methods: {
      handleCount() {
        this.show = false
        setTimeout(() => {
          this.countConfig1 = {
            startVal: 0,
            endVal: this.item.imgNum,
          }
          this.countConfig2 = {
            startVal: 0,
            endVal: this.item.labelNum,
          }
          this.countConfig3 = {
            startVal: 0,
            endVal: this.item.todayAddImgNum,
          }
          this.countConfig4 = {
            startVal: 0,
            endVal: this.item.todayLabelImgNum,
          }
          this.fileSize = (this.item.fileSize / 1024 / 1024).toFixed(2)
          this.labelFileSize = (this.item.labelFileSize / 1024 / 1024).toFixed(
            2
          )
          this.todayAddFileSize = (
            this.item.todayAddFileSize /
            1024 /
            1024
          ).toFixed(2)
          this.todayLabelFileSize = (
            this.item.todayLabelFileSize /
            1024 /
            1024
          ).toFixed(2)
          this.show = true
        }, 0)
      },
    },
  }
</script>
<style lang="scss" scoped>
  .sjdt {
    position: relative;
    height: 100%;
    padding-top: 5%;
    &:before {
      content: '';
      display: block;
      clear: both;
    }
    &-panel {
      width: 50%;
      height: 47.5%;
      float: left;
      position: relative;
      ::v-deep {
        img {
          width: 95%;
        }
      }
    }
    &-count {
      position: absolute;
      top: 0;
      left: 90px;
      font-weight: bold;
      text-align: left;
      a {
        height: 20px;
        width: 100%;
        margin-right: 5px;
        span {
          font-size: 20px;
          color: #fff;
        }
      }
      span {
        font-size: 12px;
        text-align: left;
        color: #828188;
      }
    }
    &-tilte {
      margin-top: -20px;
      font-size: 12px;
      margin-left: 90px;
      text-align: left;
      color: #c1c7d0;
    }
  }
</style>
