<template>
  <div class="sjfb">
    <vab-chart :option="options" autoresize theme="vab-echarts-theme" />
  </div>
</template>

<style lang="scss" scoped>
  .sjfb {
    position: relative;
    height: 100%;
  }
</style>
<script>
  import * as echarts from 'echarts'
  import VabChart from '@/extra/VabChart'
  import { algoUseHistory } from '@/api/kanban'
  export default {
    name: 'Sjfb',
    components: { VabChart },
    data() {
      return {
        options: {
          legend: {
            show: true,
            icon: 'rect',
            itemWidth: 14,
            itemHeight: 5,
            itemGap: 10,
            right: '35%',
            top: 0,
            textStyle: {
              fontSize: 10,
              color: '#ccc',
            },
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              lineStyle: {
                color: {
                  type: 'linear',
                  x: 0,
                  y: 0,
                  x2: 0,
                  y2: 1,
                  colorStops: [
                    {
                      offset: 0,
                      color: 'rgba(0, 255, 233,0)',
                    },
                    {
                      offset: 0.5,
                      color: 'rgba(255, 255, 255,1)',
                    },
                    {
                      offset: 1,
                      color: 'rgba(0, 255, 233,0)',
                    },
                  ],
                  global: false,
                },
              },
            },
          },
          grid: {
            top: '15%',
            left: '5%',
            right: '5%',
            bottom: '15%',
            // containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              axisLine: {
                show: true,
              },
              splitArea: {
                // show: true,
                color: '#f00',
                lineStyle: {
                  color: '#f00',
                },
              },
              axisLabel: {
                color: '#fff',
              },
              splitLine: {
                show: false,
              },
              boundaryGap: false,
              data: [],
            },
          ],

          yAxis: [
            {
              type: 'value',
              min: 0,
              // max: 140,
              splitNumber: 4,
              splitLine: {
                show: true,
                lineStyle: {
                  color: 'rgba(255,255,255,0.1)',
                },
              },
              axisLine: {
                show: false,
              },
              axisLabel: {
                show: false,
                margin: 20,
                textStyle: {
                  color: '#d1e6eb',
                },
              },
              axisTick: {
                show: false,
              },
            },
          ],
          series: [
            {
              name: '',
              type: 'line',
              smooth: true, //是否平滑
              showAllSymbol: false,
              // symbol: 'image://./static/images/guang-circle.png',
              symbol: 'circle',
              symbolSize: 2,
              lineStyle: {
                normal: {
                  color: '#00b3f4',
                },
              },
              itemStyle: {
                color: '#00b3f4',
              },
              tooltip: {
                show: true,
              },
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                    0,
                    0,
                    0,
                    1,
                    [
                      {
                        offset: 0,
                        color: 'rgba(0,179,244,0.3)',
                      },
                      {
                        offset: 1,
                        color: 'rgba(0,179,244,0)',
                      },
                    ],
                    false
                  ),
                  shadowColor: 'rgba(0,179,244, 0.9)',
                  shadowBlur: 20,
                },
              },
              data: [502.84, 205.97, 332.79, 281.55, 398.35, 214.02, 214.02],
            },
          ],
        },
      }
    },
    created() {
      algoUseHistory({ type: 1 }).then(({ data }) => {
        this.options.xAxis[0].data = data[0].xAxisData
        this.options.series[0].data = data[0].seriesData
      })
      setInterval(() => {
        algoUseHistory({ type: 1 }).then(({ data }) => {
          this.options.xAxis[0].data = data[0].xAxisData
          this.options.series[0].data = data[0].seriesData
        })
      }, 1000 * 15)
    },
    methods: {},
  }
</script>
<style lang="scss" scoped>
  ::v-deep {
    .echarts {
      width: 100%;
      height: 100%;
    }
  }
</style>
