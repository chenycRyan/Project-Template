<template>
  <div class="card-title">
    <el-col :span="7"><slot /></el-col>
    <el-col :span="17">
      <div class="card-title-background"></div>
    </el-col>
  </div>
</template>
<style lang="scss" scoped>
  .card-title {
    border-left: 2px solid #01ffff;
    height: 20px;
    line-height: 20px;
    text-align: left;
    padding-left: 10px;
    &-background {
      widows: 100%;
      background: url('~@/assets/ai_big_data_images/dz.png') no-repeat right;
      background-size: 100% 100%;
      margin-top: 5px;
      height: 10px;
    }
  }
</style>
