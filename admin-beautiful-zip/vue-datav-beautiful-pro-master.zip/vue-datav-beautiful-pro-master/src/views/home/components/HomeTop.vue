<template>
  <el-row>
    <el-col :span="6">
      <el-col :span="12">
        <el-image
          class="home-top-icon"
          :src="require('@/assets/ai_big_data_images/top01.png')"
        />
      </el-col>
      <el-col :span="12">
        <div class="home-top-text">
          <vab-count
            v-if="show"
            :start-val="countConfig1.startVal"
            :end-val="countConfig1.endVal"
          />
          <p>累计访问次数</p>
        </div>
      </el-col>
    </el-col>
    <el-col :span="6">
      <el-col :span="12">
        <el-image
          class="home-top-icon"
          :src="require('@/assets/ai_big_data_images/top02.png')"
        />
      </el-col>
      <el-col :span="12">
        <div class="home-top-text">
          <vab-count
            v-if="show"
            :start-val="countConfig2.startVal"
            :end-val="countConfig2.endVal"
          />
          <p>用户数</p>
        </div>
      </el-col>
    </el-col>
    <el-col :span="6">
      <el-col :span="12">
        <el-image
          class="home-top-icon"
          :src="require('@/assets/ai_big_data_images/top03.png')"
        />
      </el-col>
      <el-col :span="12">
        <div class="home-top-text">
          <vab-count
            v-if="show"
            :start-val="countConfig3.startVal"
            :end-val="countConfig3.endVal"
          />
          <p>累计产出模型</p>
        </div>
      </el-col>
    </el-col>
    <el-col :span="6">
      <el-col :span="12">
        <el-image
          class="home-top-icon"
          :src="require('@/assets/ai_big_data_images/top04.png')"
        />
      </el-col>
      <el-col :span="12">
        <div class="home-top-text">
          <vab-count
            v-if="show"
            :start-val="countConfig4.startVal"
            :end-val="countConfig4.endVal"
          />
          <p>累计评估模型</p>
        </div>
      </el-col>
    </el-col>
  </el-row>
</template>
<script>
  import { VabCount } from 'zx-count'
  export default {
    name: 'HomeContainer',
    components: { VabCount },
    props: {
      item: {
        type: Object,
        default: () => {},
      },
    },
    data() {
      return {
        show: true,
        countConfig1: {
          startVal: 0,
          endVal: 0,
        },
        countConfig2: {
          startVal: 0,
          endVal: 0,
        },
        countConfig3: {
          startVal: 0,
          endVal: 0,
        },
        countConfig4: {
          startVal: 0,
          endVal: 0,
        },
      }
    },
    mounted() {
      setTimeout(() => {
        this.handleCount()
      }, 1000)
      setInterval(() => {
        this.handleCount()
      }, 1000 * 15)
    },
    methods: {
      handleCount() {
        this.show = false
        setTimeout(() => {
          this.countConfig1 = {
            startVal: 0,
            endVal: this.item.totalAccessNum,
          }
          this.countConfig2 = {
            startVal: 0,
            endVal: this.item.totalUserNum,
          }
          this.countConfig3 = {
            startVal: 0,
            endVal: this.item.totalModelNum,
          }
          this.countConfig4 = {
            startVal: 0,
            endVal: this.item.totalModelEavluationNum,
          }
          this.show = true
        }, 0)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .home {
    &-top-icon {
      animation: twink 3s linear infinite;
    }
    &-top-text {
      margin-top: 20px;
      text-align: left;
      color: #64c5d9;
      p {
        margin-top: 10px;
        color: #fff;
        font-size: 12px;
      }
    }
  }
</style>
