<template>
  <div class="sjfb">
    <vab-chart :option="options" autoresize theme="vab-echarts-theme" />
  </div>
</template>

<style lang="scss" scoped>
  .sjfb {
    position: relative;
    height: 100%;
  }
</style>
<script>
  import * as echarts from 'echarts'
  import VabChart from '@/extra/VabChart'
  export default {
    name: 'Sjfb',
    components: { VabChart },
    props: {
      item: {
        type: Object,
        default: () => {},
      },
    },
    data() {
      return {
        options: {
          grid: {
            left: '5%',
            right: '5%',
            bottom: '5%',
            top: '10%',
            containLabel: true,
          },
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'none',
            },
          },
          xAxis: {
            show: false,
            type: 'value',
          },
          yAxis: [
            {
              type: 'category',
              inverse: true,
              data: [
                '车辆目标数',
                '行人目标数',
                '非机动车目标数',
                '信号灯目标数',
              ],
              axisLine: {
                //y轴
                show: false,
              },
              axisTick: {
                //y轴刻度线
                show: false,
              },
              splitLine: {
                //网格线
                show: false,
              },
            },
          ],
          series: [
            {
              name: '',
              type: 'bar',
              zlevel: 1,
              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 0, 1, 0, [
                    {
                      offset: 0,
                      color: 'rgb(57,89,255,1)',
                    },
                    {
                      offset: 1,
                      color: 'rgb(46,200,207,1)',
                    },
                  ]),
                },
              },
              barWidth: 15,
              data: [],
            },
          ],
        },
      }
    },
    mounted() {
      setTimeout(() => {
        const data = [
          this.item.vehicleTargetNum,
          this.item.pedestrianTargetNum,
          this.item.bikerTargetNum,
          this.item.lightClaTargetNum,
        ]
        this.options.series[0].data = data
      }, 1000)
      setInterval(() => {
        const data = [
          this.item.vehicleTargetNum,
          this.item.pedestrianTargetNum,
          this.item.bikerTargetNum,
          this.item.lightClaTargetNum,
        ]
        this.options.series[0].data = data
      }, 1000 * 15)
    },
  }
</script>
<style lang="scss" scoped>
  ::v-deep {
    .echarts {
      width: 100%;
      height: 100%;
    }
  }
</style>
