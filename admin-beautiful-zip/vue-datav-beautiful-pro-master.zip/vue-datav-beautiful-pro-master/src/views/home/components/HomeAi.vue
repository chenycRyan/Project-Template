<template>
  <div class="home-ai">
    <div class="home-ai-card home-ai-card-1">
      <span>数据</span>
    </div>
    <div class="home-ai-card home-ai-card-2">
      <span>模型</span>
    </div>
    <div class="home-ai-card home-ai-card-3">
      <span>算法</span>
    </div>
    <div class="home-ai-card home-ai-card-4">
      <span>评估</span>
    </div>
    <div class="home-ai-images">
      <el-image
        class="home-ai-images-1"
        :src="require('@/assets/ai_big_data_images/ai.png')"
      />
      <el-image
        class="home-ai-images-2"
        :src="require('@/assets/ai_big_data_images/ai02.png')"
      />
      <el-image
        class="home-ai-images-3"
        :src="require('@/assets/ai_big_data_images/ai03.png')"
      />
      <el-image
        class="home-ai-images-4"
        :src="require('@/assets/ai_big_data_images/ai04.png')"
      />
    </div>
  </div>
</template>
<style lang="scss" scoped>
  .home {
    &-ai {
      position: relative;
      width: 600px;
      height: 450px;
      margin: 0 auto 40px auto;
      &-card {
        position: absolute;
        width: 200px;
        height: 70px;
        z-index: 100;
        animation: twink 6s linear infinite1;
        span {
          text-align: center;
          font-size: 22px;
          font-family: Microsoft YaHei;
          font-weight: bold;
          color: #7bcbfe;
          line-height: 50px;
          background: linear-gradient(0deg, #7bcbfe 0%, #ffffff 100%);
          background-clip: text;
          -webkit-text-fill-color: transparent;
        }
        &-1 {
          top: 0;
          left: 0;
          background: url('~@/assets/ai_big_data_images/bgzuo.png') no-repeat;
          background-size: 100% 100%;
        }
        &-2 {
          background: url('~@/assets/ai_big_data_images/bgyou.png') no-repeat;
          background-size: 100% 100%;
          top: 0;
          right: 0;
        }
        &-3 {
          background: url('~@/assets/ai_big_data_images/bgzuo.png') no-repeat;
          background-size: 100% 100%;
          bottom: 0;
          left: 0;
        }
        &-4 {
          background: url('~@/assets/ai_big_data_images/bgyou.png') no-repeat;
          background-size: 100% 100%;
          bottom: 0;
          right: 0;
        }
      }
      &-images {
        position: relative;
        width: 450px;
        height: 450px;
        margin: auto;
        &-1 {
          position: absolute;
          z-index: 99;
          width: 200px;
          height: 200px;
          left: 50%;
          top: 50%;
          left: calc(50% - 100px);
          top: calc(50% - 100px);
          animation: twink 24s linear infinite;
        }
        &-2 {
          position: absolute;
          z-index: 98;
          width: 220px;
          height: 220px;
          left: 50%;
          top: 50%;
          left: calc(50% - 110px);
          top: calc(50% - 110px);
          animation: twink 6s linear infinite;
        }
        &-3 {
          position: absolute;
          z-index: 97;
          width: 340px;
          height: 340px;
          left: calc(50% - 170px);
          top: calc(50% - 170px);
          animation: rotate-left 6s linear infinite;
        }
        &-4 {
          position: absolute;
          z-index: 96;
          width: 450px;
          height: 450px;
          left: calc(50% - 225px);
          top: calc(50% - 225px);
          animation: rotate-right 6s linear infinite;
        }
      }
    }
  }
</style>
