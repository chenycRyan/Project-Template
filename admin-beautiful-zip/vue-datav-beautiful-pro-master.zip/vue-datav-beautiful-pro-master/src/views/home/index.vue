<template>
  <div class="home-container">
    <home-header
      :style="{
        height: headerContentHeight,
        'line-height': headerContentHeight,
      }"
    />
    <div style="padding: 0 20px 0px 20px">
      <el-row :gutter="20">
        <el-col :span="6">
          <div class="home-card" :style="{ height: leftCardHeight }">
            <card-title>数据动态</card-title>
            <sjdt :item="item" />
          </div>
          <!--  <div class="home-card" :style="{ height: leftCardHeight }">
            <card-title>数据分布</card-title>
            <sjfb :item="item" />
          </div> -->
          <div class="home-card" :style="{ height: leftCardHeight }">
            <card-title>数据集合</card-title>
            <sjjh :item="item" />
          </div>
          <div class="home-card" :style="{ height: leftCardHeight }">
            <card-title>数据来源</card-title>
            <sjly />
          </div>
        </el-col>
        <el-col :span="12">
          <div :style="{ height: topCardHeight }">
            <home-top :item="item" />
          </div>
          <home-ai />
          <div class="home-card" :style="{ height: bottomCardHeight }">
            <card-title>算法资源池</card-title>
            <sfzyc />
          </div>
        </el-col>
        <el-col :span="6">
          <div class="home-card" :style="{ height: rightCardHeight }">
            <card-title>算法种类</card-title>
            <sfzl />
          </div>
          <div class="home-card" :style="{ height: rightCardHeight }">
            <card-title>算法仓库</card-title>
            <sfck :item="item" />
          </div>
          <div class="home-card" :style="{ height: rightCardHeight }">
            <card-title>算法使用频次</card-title>
            <Sfsypc />
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
  import HomeHeader from './components/HomeHeader'
  import HomeTop from './components/HomeTop'
  import HomeAi from './components/HomeAi'
  import CardTitle from './components/CardTitle'
  import Sjly from './components/Sjly'
  import Sfzl from './components/Sfzl'
  import Sjdt from './components/Sjdt'
  import Sfck from './components/Sfck'
  /* import Sjfb from './components/Sjfb' */
  import Sjjh from './components/Sjjh'
  import Sfzyc from './components/Sfzyc'
  import Sfsypc from './components/Sfsypc'
  import { listByPage } from '@/api/kanban'

  export default {
    name: 'HomeContainer',
    components: {
      HomeAi,
      HomeHeader,
      HomeTop,
      CardTitle,
      Sjly,
      Sfzl,
      Sjdt,
      Sfck,
      /*  Sjfb, */
      Sjjh,
      Sfzyc,
      Sfsypc,
    },
    data() {
      return {
        headerContentHeight: '60px',
        topCardHeight: '120px',
        leftCardHeight: 'calc((100vh - 150px) / 3)',
        rightCardHeight: 'calc((100vh - 150px) / 3)',
        bottomCardHeight: 'calc((100vh - 720px)',
        item: {},
      }
    },
    created() {
      listByPage().then(({ data }) => {
        this.item = data[0]
      })
      setInterval(() => {
        listByPage().then(({ data }) => {
          this.item = data[0]
        })
      }, 1000 * 15)
    },
  }
</script>

<style lang="scss" scoped>
  .home {
    &-container {
      background: #01062f;
      color: #fff;
      box-sizing: border-box;
      min-width: 1720px;
      min-height: 937px;
    }

    &-card {
      width: 100%;
      margin-bottom: 20px;
      background: url('~@/assets/ai_big_data_images/bgchang.png') no-repeat;
      background-size: 100% 100%;
      min-height: 160px;
      padding: 20px;
    }
  }
</style>
<style lang="scss">
  @keyframes twink {
    0% {
      opacity: 0.9;
      transform: scale(1);
    }
    50% {
      opacity: 1;
      transform: scale(1.2);
    }
    100% {
      opacity: 0.9;
      transform: scale(1);
    }
  }
  @keyframes twinkImage {
    0% {
      opacity: 0.9;
      transform: scale(1);
    }
    50% {
      opacity: 1;
      transform: scale(1.1);
    }
    100% {
      opacity: 0.9;
      transform: scale(1);
    }
  }
  @keyframes rotate-left {
    0% {
      transform: rotate(0deg);
    }

    50% {
      transform: rotate(-180deg);
    }

    100% {
      transform: rotate(-360deg);
    }
  }
  @keyframes rotate-right {
    0% {
      transform: rotate(0deg);
    }

    50% {
      transform: rotate(180deg);
    }

    100% {
      transform: rotate(360deg);
    }
  }
</style>
