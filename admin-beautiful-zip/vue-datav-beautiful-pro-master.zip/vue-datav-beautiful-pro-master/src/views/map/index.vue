<template>
  <div class="map-container homepage">
    <el-row>
      <el-col :span="5" class="height-box">
        <div class="grid-content" style="position: relative; z-index: 999">
          <el-card class="box-card vab-screen-card">
            <div slot="header" class="clearfix">
              <span class="vab-card-header">数字视网膜终端</span>
            </div>
            <div class="text item card4-body right-panel2-item">
              <el-row :gutter="12" style="margin-bottom: 0">
                <el-col :span="12">
                  <div class="circle-box">
                    <p class="num">
                      <vab-count
                        :startVal="0"
                        :endVal="2360"
                        suffix=""
                        :duration="1000"
                      />
                    </p>
                    <p class="txt">人脸卡口</p>
                  </div>
                </el-col>
                <el-col :span="12">
                  <div class="circle-box">
                    <p class="num">
                      <vab-count
                        :startVal="0"
                        :endVal="2542"
                        suffix=""
                        :duration="1000"
                      />
                    </p>
                    <p class="txt">车辆卡口</p>
                  </div>
                </el-col>
                <el-col :span="12">
                  <div class="circle-box">
                    <p class="num">
                      <vab-count
                        :startVal="0"
                        :endVal="197"
                        suffix=""
                        :duration="1000"
                      />
                    </p>
                    <p class="txt">5G终端</p>
                  </div>
                </el-col>
                <el-col :span="12">
                  <div class="circle-box">
                    <p class="num">
                      <vab-count
                        :startVal="0"
                        :endVal="170"
                        suffix=""
                        :duration="1000"
                      />
                    </p>
                    <p class="txt">智能分析盒</p>
                  </div>
                </el-col>
              </el-row>
              <div class="circle-div">
                <p class="num">
                  <vab-count
                    :startVal="0"
                    :endVal="5269"
                    suffix=""
                    :duration="1000"
                  />
                </p>
                <p class="txt">设备总数</p>
              </div>
            </div>
          </el-card>
          <el-card class="box-card vab-screen-card">
            <div slot="header" class="clearfix">
              <span class="vab-card-header">视网膜终端算法分布</span>
            </div>
            <div
              class="text item card4-body right-panel-item"
              style="height: 190px"
            >
              <vab-chart
                auto-resize
                ref="bar"
                :option="area"
                style="width: 316px; height: 185px"
              />
            </div>

            <div class="right-panel3-item">
              <span class="left-span">实时解析目标</span>
              <span class="right-span">
                <vab-count
                  :startVal="oldNum2"
                  :endVal="num2"
                  suffix="个/秒"
                  :duration="1000"
                />
              </span>
            </div>
            <div class="right-panel3-item">
              <span class="left-span">日解析目标</span>
              <span class="right-span">
                <vab-count
                  :startVal="oldNum3"
                  :endVal="num3"
                  suffix="个"
                  :duration="1000"
                />
              </span>
            </div>
            <div class="right-panel3-item">
              <span class="left-span">总解析目标</span>
              <span class="right-span">
                <vab-count
                  :startVal="oldNum1"
                  :endVal="num1"
                  :decimals="2"
                  suffix="亿个"
                  :duration="1000"
                />
              </span>
            </div>
          </el-card>
          <el-card class="box-card vab-screen-card">
            <div slot="header" class="clearfix">
              <span class="vab-card-header">数字视网膜数据总量</span>
            </div>
            <div class="text item card4-body right-panel1-item">
              <!-- <p>特征:</p> -->
              <div class="img-div">
                <img class="data-img" src="@/assets/map_images/ccc.png" />
                <div class="img-data">
                  <p style="line-height: 24px">2.75TB</p>
                  <p style="line-height: 53px">11TB</p>
                  <p style="line-height: 44px">4.71TB</p>
                  <p style="line-height: 54px">1.36TB</p>
                  <p style="line-height: 64px">6.35PB</p>
                </div>
              </div>
              <div class="data-div">
                <div class="data-item" style="line-height: 24px">
                  <hr class="data-line" />
                  结构化特征：
                  <span class="data-num">118.96亿个</span>
                </div>
                <div class="data-item" style="line-height: 53px">
                  <hr class="data-line" />
                  深度特征专用：
                  <span class="data-num">170.24亿条</span>
                </div>
                <div class="data-item" style="line-height: 44px">
                  <hr class="data-line" />
                  CDVS特征通用：
                  <span class="data-num">24.32亿条</span>
                </div>
                <div class="data-item" style="line-height: 54px">
                  <hr class="data-line" />
                  图片：
                  <span class="data-num">24.32亿张</span>
                </div>
                <div class="data-item" style="line-height: 64px">
                  <hr class="data-line" />
                  视频:
                  <span class="data-num">3793.68小时</span>
                </div>
              </div>
            </div>
            <!-- <div class="text item card4-body right-panel1-item">
              <p>视图数据:</p>
              <div class="img-div">
                <img class="data-img" src="@/assets/map_images/lgq.png"  style="margin-top: 8px;"/>
                <div class="img-data">
                  <p style="line-height: 52px;">135.67TB</p>
                  <p>6.35PB</p>
                </div>
              </div>
              <div class="data-div">
                <div class="data-item">
                  <hr class="data-line" style="width: 62px!important;left: -66px!important;"/>
                  视频：
                  <span class="data-num">3793.68小时</span>
                </div>
                <div class="data-item">
                  <hr class="data-line" style="width: 48px!important;left: -51px!important;" />
                  图片：
                  <span class="data-num">2.37亿张</span>
                </div>
              </div>
            </div> -->
          </el-card>
        </div>
      </el-col>
      <el-col :span="14">
        <div class="grid-content">
          <div class="homecenter">
            <div class="btn-box">
              <a href="#/gadsjztyy">
                <button class="vab-btn1" style="margin-right: 20px">
                  公安大数据专题应用
                </button>
              </a>
              <a href="#/videoIntelligent">
                <button class="vab-btn1">交通大数据专题应用</button>
              </a>
            </div>
            <!-- <el-row> -->
            <!-- <el-col :span="6"> -->
            <!-- <a href="#/gadsjztyy"><button class="vab-btn1">公安大数据专题应用</button></a> -->
            <!-- </el-col> -->
            <!-- <el-col :span="6"> -->
            /
            <!-- </el-col> -->
            <!-- <el-col :span="6"> -->
            <!-- <a><button class="vab-btn1" @click="jqqd">综治大数据专题应用</button></a> -->
            <!-- </el-col> -->
            <!-- </el-row> -->
            <!-- <div style="width:750px;">
              <el-row :gutter="12">
                <el-col :span="8">
                  <div class="footer-div1">
                    数据总量
                    <p>8422<span>GB</span></p>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="footer-div1">
                    今日增量
                    <p>6239<span>GB</span></p>
                  </div>
                </el-col>
                <el-col :span="8">
                  <div class="footer-div1">
                    社会数据
                    <p>2<span>GB</span></p>
                  </div>
                </el-col>
              </el-row> -->
          </div>
        </div>
      </el-col>
      <el-col :span="5" class="height-box">
        <div class="grid-content">
          <!-- <div>
          <div class="hometitle">城市交通大数据</div>
          <el-row>
            <el-col :span="12"></el-col>
            <el-col :span="12"></el-col>
          </el-row>
        </div> -->
          <el-card
            class="box-card vab-screen-card index-dsjgl"
            style="height: 360px"
          >
            <div slot="header" class="clearfix">
              <span class="vab-card-header">云端算法仓</span>
            </div>
            <div
              style="
                position: relative;
                height: 28px;
                border-bottom: 1px solid #075294;
              "
            >
              <div class="tab-div">
                <div
                  class="left-panel1-item"
                  :class="activeItem1 == 'item11' ? 'active' : ''"
                  @mouseover="activeItem1 = 'item11'"
                >
                  视频分析算法
                </div>
                <transition name="fade">
                  <div v-show="activeItem1 == 'item11'" class="item-detail1">
                    <el-table
                      class="ydsfc-table"
                      :data="behaviorData"
                      stripe
                      style="width: 100%"
                      height="270"
                    >
                      <el-table-column
                        prop="name"
                        label="算法名称"
                        show-overflow-tooltip
                      ></el-table-column>
                      <el-table-column
                        sortable
                        prop="count"
                        label="版本号"
                        width="100"
                      ></el-table-column>
                      <!-- <el-table-column prop="desc" label="算法描述" width="100" show-overflow-tooltip>
                    </el-table-column> -->
                      <el-table-column label="操作" width="60">
                        <template slot-scope="scope">
                          <a
                            v-if="scope.row.show"
                            @click="handleClick(scope.row)"
                          >
                            升级
                          </a>
                          <a v-else @click="handleClick(scope.row)">下发</a>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </transition>
              </div>
              <div class="tab-div">
                <div
                  class="left-panel1-item"
                  :class="activeItem1 == 'item12' ? 'active' : ''"
                  @mouseover="activeItem1 = 'item12'"
                >
                  业务分析算法
                </div>
                <transition name="fade">
                  <div v-show="activeItem1 == 'item12'" class="item-detail1">
                    <el-table
                      class="ydsfc-table"
                      :data="workData"
                      stripe
                      style="width: 100%"
                      height="270"
                    >
                      <el-table-column
                        prop="name"
                        label="算法名称"
                        show-overflow-tooltip
                      ></el-table-column>
                      <el-table-column
                        sortable
                        prop="count"
                        label="运行次数"
                      ></el-table-column>
                      <!-- <el-table-column prop="desc" label="算法描述" width="100" show-overflow-tooltip>
                    </el-table-column> -->
                      <el-table-column label="操作" width="60">
                        <template slot-scope="scope">
                          <a @click="handleClick(scope.row)">查看</a>
                        </template>
                      </el-table-column>
                    </el-table>
                  </div>
                </transition>
              </div>
            </div>
          </el-card>
          <el-card
            class="box-card vab-screen-card index-dsjgl"
            style="padding-top: 15px; padding-bottom: 0px; height: 260px"
          >
            <div slot="header" class="clearfix">
              <span class="vab-card-header">云端算力</span>
            </div>
            <el-row>
              <!--  -->
              <el-col :span="24">
                <!-- style="display: flex;justify-content: space-between;" -->
                <div>
                  <ul>
                    <li style="font-size: 14px; text-align: right">
                      <i
                        class="el-icon-s-opportunity"
                        style="color: #c91554; padding-top: 10px"
                      ></i>
                      高性能计算资源：
                      <span class="homebglt">13.64</span>
                      <span class="homesmlt" style="font-size: 12px">
                        PFLOPS
                      </span>
                      <!-- <div>

                      </div> -->
                    </li>
                    <!-- <li style="line-height: 24px;">
                      <i class="el-icon-help"></i>
                      故障率: 0.13%
                    </li> -->
                  </ul>
                </div>

                <vab-chart
                  auto-resize
                  :option="chBar"
                  style="width: 100%; height: 180px"
                />
              </el-col>
            </el-row>
          </el-card>

          <el-card
            class="box-card vab-screen-card index-dsjgl"
            style="height: 245px"
          >
            <div slot="header" class="clearfix" style="position: relative">
              <span class="vab-card-header">融合大数据</span>
            </div>
            <el-row :gutter="6">
              <el-col :span="8">
                <div
                  class="left-panel1-item"
                  :class="activeItem == 'item1' ? 'active' : ''"
                  @mouseover="activeItem = 'item1'"
                >
                  <img class="item-img" src="@/assets/map_images/sjjr.png" />
                  <div class="item-txt">
                    <p>数据接入</p>
                    <p class="color-txt">
                      <span>5</span>
                      大类
                    </p>
                  </div>
                </div>
                <transition name="fade">
                  <div v-show="activeItem == 'item1'" class="item-detail">
                    <i class="el-icon-caret-top icon1"></i>
                    <div class="item-detail-content">
                      <el-row :gutter="15">
                        <el-col
                          v-for="item in sjjrList"
                          :key="item.id"
                          :span="12"
                        >
                          <div class="content-item">{{ item.name }}</div>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </transition>
              </el-col>
              <el-col :span="8">
                <div
                  class="left-panel1-item"
                  :class="activeItem == 'item2' ? 'active' : ''"
                  @mouseover="activeItem = 'item2'"
                >
                  <img class="item-img" src="@/assets/map_images/rhfx.png" />
                  <div class="item-txt">
                    <p>融合分析</p>
                    <p class="color-txt">
                      <span>18</span>
                      种
                    </p>
                  </div>
                </div>
                <transition name="fade">
                  <div v-show="activeItem == 'item2'" class="item-detail">
                    <i class="el-icon-caret-top icon2"></i>
                    <div class="item-detail-content">
                      <el-row :gutter="15">
                        <el-col
                          v-for="item in rhfxList"
                          :key="item.id"
                          :span="12"
                        >
                          <div
                            class="content-item text-ellipsis"
                            :title="item.name"
                          >
                            {{ item.name }}
                          </div>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </transition>
              </el-col>
              <el-col :span="8">
                <div
                  class="left-panel1-item"
                  :class="activeItem == 'item3' ? 'active' : ''"
                  @mouseover="activeItem = 'item3'"
                >
                  <img class="item-img" src="@/assets/map_images/ywyy.png" />
                  <div class="item-txt">
                    <p>业务数据库</p>
                    <p class="color-txt">
                      <span>6</span>
                      个
                    </p>
                  </div>
                </div>
                <transition name="fade">
                  <div v-show="activeItem == 'item3'" class="item-detail">
                    <i class="el-icon-caret-top icon3"></i>
                    <div class="item-detail-content">
                      <el-row :gutter="15">
                        <el-col
                          v-for="item in ywyyList"
                          :key="item.id"
                          :span="12"
                        >
                          <div class="content-item">{{ item.name }}</div>
                        </el-col>
                      </el-row>
                    </div>
                  </div>
                </transition>
              </el-col>
            </el-row>
          </el-card>

          <!-- <el-card class="box-card vab-screen-card index-dsjgl">
            <div slot="header" class="clearfix"><span class="vab-card-header">数字视网膜终端利用率</span></div>

          </el-card> -->
        </div>
      </el-col>
    </el-row>
    <div id="map" class="container-map"></div>
    <canvas id="canvas"></canvas>
    <tan-kuang ref="tankuang"></tan-kuang>
    <tan-kuang1 ref="tankuang1"></tan-kuang1>
    <tan-kuang2 ref="tankuang2"></tan-kuang2>
    <tan-kuang3 ref="tankuang3"></tan-kuang3>
    <tan-kuang4 ref="tankuang4"></tan-kuang4>
    <tan-kuang5 ref="tankuang5"></tan-kuang5>
    <tan-kuang6 ref="tankuang6"></tan-kuang6>
    <tan-kuang7 ref="tankuang7"></tan-kuang7>
  </div>
</template>

<script>
  import * as maptalks from 'maptalks'
  import { getList } from '@/api/mapv'
  import TanKuang from './components/TanKuang'
  import TanKuang1 from './components/TanKuang1'
  import TanKuang2 from './components/TanKuang2'
  import TanKuang3 from './components/TanKuang3'
  import TanKuang4 from './components/TanKuang4'
  import TanKuang5 from './components/TanKuang5'
  import TanKuang6 from './components/TanKuang6'
  import TanKuang7 from './components/TanKuang7'
  import { mapGetters } from 'vuex'
  import * as echarts from 'echarts'

  export default {
    name: 'Map',
    components: {
      TanKuang,
      TanKuang1,
      TanKuang2,
      TanKuang3,
      TanKuang4,
      TanKuang5,
      TanKuang6,
      TanKuang7,
    },
    data() {
      return {
        oldNum1: 0,
        oldNum2: 0,
        oldNum3: 0,
        num1: 24.32,
        num2: 3,
        num3: 3140000,
        activeName: 'first', //tabs
        area: {
          tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(255,255,255,0.1)',
            axisPointer: {
              type: 'shadow',
            },
          },
          /* color: ['#003366', '#006699', '#4cabce', '#e5323e'], */
          grid: {
            top: '14%',
            left: '3%',
            right: '4%',
            bottom: '0%',
            height: '90%',
            containLabel: true,
          },
          legend: {
            data: [],
            right: 10,
            top: 12,
            textStyle: {
              color: '#fff',
            },
            itemWidth: 12,
            itemHeight: 10,
          },
          xAxis: [
            {
              type: 'category',
              color: '#3b90f3',
              data: [
                '人脸识别',
                '人体结构化',
                '机动车解析',
                '非机动车解析',
                '行为解析',
              ],
              axisLine: {
                lineStyle: {
                  color: '#3b90f3',
                },
              },
              axisLabel: {
                interval: 0,
                rotate: 20,
                color: '#3b90f3',
              },
            },
          ],
          yAxis: [
            {
              scale: true,
              name: '',
              nameGap: 8,
              type: 'value',
              min: 0,
              max: 6000,
              color: '#3b90f3',
              axisLine: {
                lineStyle: {
                  color: '#3b90f3',
                },
              },
              splitLine: {
                show: false,
              },
              nameTextStyle: {
                color: '#3b90f3',
              },
              axisLabel: {
                // margin: 20,
                color: '#3b90f3',
                textStyle: {
                  fontSize: 12,
                },
              },
            },
          ],
          series: [
            {
              type: 'bar',
              data: [3360, 1020, 3542, 723, 632],
              animationDelay: function (idx) {
                return idx * 10 + 100
              },
              barWidth: 20,
              itemStyle: {
                normal: {
                  color: '#2490fd',
                  /* barBorderRadius: [11, 11, 0, 0], */
                  shadowColor: 'rgba(0,160,221,1)',
                  shadowBlur: 4,
                },
              },
              label: {
                normal: {
                  show: true,
                  borderRadius: 200,
                  width: 36,
                  position: ['0', '-15'],
                  formatter: [' {a|{c}}     \n'].join(','),
                  rich: {
                    a: {
                      color: '#2490fd',
                      align: 'center',
                    },
                  },
                },
              },
            },
          ],
          animationEasing: 'elasticOut',
          animationDelayUpdate: function (idx) {
            return idx * 5
          },
        },
        area1: {
          tooltip: {
            trigger: 'axis',
          },
          color: ['#80CAD8'],
          grid: {
            top: 'middle',
            left: '3%',
            right: '4%',
            bottom: '3%',
            height: '80%',
            containLabel: true,
          },
          xAxis: [
            {
              type: 'category',
              color: '#03E2DA',
              data: ['城阳', '市南', '市北', '李沧', '崂山', '开发区'],
              // axisPointer: {
              //   type: 'line'
              // },
              axisLine: {
                lineStyle: {
                  color: '#272456',
                },
              },
              axisLabel: {
                interval: 0,
                color: '#03E2DA',
              },
            },
          ],
          yAxis: [
            {
              type: 'value',
              min: 0,
              max: 140,
              color: '#03E2DA',
              // axisLabel: {
              //   // formatter: '{value}%',
              //   color: '#03E2DA'
              // },
              axisLine: {
                lineStyle: {
                  color: '#03E2DA',
                },
              },
              splitLine: {
                show: false,
              },
              nameTextStyle: {
                color: '#999',
              },
              // axisLine: {
              //   lineStyle: {
              //     color: '#03E2DA'
              //   }
              // },
              axisLabel: {
                // margin: 20,
                color: '#03E2DA',
                textStyle: {
                  fontSize: 12,
                },
              },
            },
          ],
          series: [
            {
              type: 'bar',
              data: [100, 90, 10, 90, 90, 20, 56, 89],
              barWidth: 5,
              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                    0,
                    0,
                    0,
                    1,
                    [
                      {
                        offset: 0,
                        color: '#41E1D4', // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: '#10A7DB', // 100% 处的颜色
                      },
                    ],
                    false
                  ),
                  barBorderRadius: [30, 30, 0, 0],
                },
              },
            },
          ],
        },
        behaviorData: [
          {
            id: 0,
            name: '人脸检测跟踪算法',
            count: 'V.5.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 1,
            name: '人脸识别结构化算法',
            count: 'V.1.3.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 2,
            name: '车/行人/人骑车目标检测跟踪算法',
            count: 'V.1.2.3',
            show: false,
            desc: '算法描述',
          },
          {
            id: 3,
            name: '车/行人/人骑车结构化算法',
            count: 'V.4.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 4,
            name: '车行人人骑车图片结构化算法',
            count: 'V.4.4.4',
            show: false,
            desc: '算法描述',
          },
          {
            id: 5,
            name: '人脸图片结构化算法',
            count: 'V.1.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 6,
            name: '双侧绊线检测',
            count: 'V.5.6.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 7,
            name: '入侵检测',
            count: 'V.4.2.4',
            show: false,
            desc: '算法描述',
          },
          {
            id: 8,
            name: '人群密度检测',
            count: 'V.7.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 9,
            name: '徘徊检测',
            count: 'V.6.5.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 10,
            name: '物品遗留',
            count: 'V.3.2.5',
            show: true,
            desc: '算法描述',
          },
          {
            id: 11,
            name: '剧烈运动检测',
            count: 'V.7.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 12,
            name: '客流量统计',
            count: 'V.5.2.8',
            show: false,
            desc: '算法描述',
          },
          {
            id: 13,
            name: '物品移位',
            count: 'V.1.5.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 14,
            name: '车辆拥堵',
            count: 'V.3.2.4',
            show: true,
            desc: '算法描述',
          },
          {
            id: 14,
            name: '进行检则及单向绊线检测',
            count: 'V.4.2.4',
            show: false,
            desc: '算法描述',
          },
        ],
        workData: [
          {
            id: 0,
            name: '同行分析',
            count: 528,
            desc: '算法描述',
          },
          {
            id: 1,
            name: '时空碰撞分析',
            count: 348,
            desc: '算法描述',
          },
          {
            id: 2,
            name: '轨迹追球落脚点分析',
            count: 756,
            desc: '算法描述',
          },
          {
            id: 3,
            name: '活动规律分析',
            count: 781,
            desc: '算法描述',
          },
          {
            id: 4,
            name: '里点区域出没',
            count: 545,
            desc: '算法描述',
          },
          {
            id: 5,
            name: '敏感时间出没',
            count: 434,
            desc: '算法描述',
          },
          {
            id: 6,
            name: '频繁出没',
            count: 312,
            desc: '算法描述',
          },
          {
            id: 7,
            name: '昼伏夜出',
            count: 412,
            desc: '算法描述',
          },
        ],
        value1: true,
        activeItem1: 'item11',
        sjjrList: [
          {
            id: 0,
            name: '视频数据',
          },
          {
            id: 1,
            name: '物联网感知数据',
          },
          {
            id: 2,
            name: '社会各行业数据',
          },
          {
            id: 3,
            name: '公安业务数据',
          },
          {
            id: 4,
            name: '互联网数据',
          },
        ],
        rhfxList: [
          {
            id: 0,
            name: '10种社会数据',
          },
          {
            id: 1,
            name: '3种公安业务数据',
          },
          {
            id: 2,
            name: '4种视频结构化数据',
          },
          {
            id: 3,
            name: '1种物联网感知数据',
          },
        ],
        ywyyList: [
          {
            id: 0,
            name: '车辆库',
          },
          {
            id: 1,
            name: '行人库',
          },
          {
            id: 2,
            name: '人脸库',
          },
          {
            id: 3,
            name: '手机Mac库',
          },
          {
            id: 4,
            name: '人骑车库',
          },
          {
            id: 5,
            name: '图谱分析库',
          },
        ],
        activeItem: 'item1',
        videoSrc: 'video/people.mp4',
        chGauge: {
          color: ['#fff', 'rgba(255,255,255,.5)', 'rgba(255,255,255,.2)'],
          series: [
            {
              type: 'pie',
              center: ['50%', '50%'],
              radius: ['48%', '50%'],
              hoverAnimation: false,
              data: [
                {
                  name: '',
                  value: 68,
                  itemStyle: {
                    normal: {
                      color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                          offset: 0.5,
                          color: '#0c36fa',
                        },
                        {
                          offset: 1,
                          color: '#1ed9ba',
                        },
                      ]),
                    },
                  },
                  label: {
                    show: true,
                    position: 'center',
                    color: '#bfbfc7',
                    fontSize: 20,
                    formatter: function () {
                      return '68%'
                    },
                  },
                  labelLine: {
                    show: false,
                    emphasis: {
                      show: false,
                    },
                  },
                },
                {
                  //画中间的图标
                  name: '',
                  value: 0,
                  label: {
                    position: 'inside',
                    backgroundColor: {
                      image:
                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAA6E2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS41LWMwMTQgNzkuMTUxNDgxLCAyMDEzLzAzLzEzLTEyOjA5OjE1ICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgICAgICAgICB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIgogICAgICAgICAgICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgICAgICAgICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC94bXA6Q3JlYXRvclRvb2w+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDE5LTA0LTMwVDEyOjI0OjUyKzA4OjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNZXRhZGF0YURhdGU+MjAxOS0wNC0zMFQxMjoyNDo1MiswODowMDwveG1wOk1ldGFkYXRhRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMTktMDQtMzBUMTI6MjQ6NTIrMDg6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wTU06SW5zdGFuY2VJRD54bXAuaWlkOjAxNzk3ZjYxLWRhMGQtNmQ0My1iN2I1LWNiZWFiYzFhZjhkZTwveG1wTU06SW5zdGFuY2VJRD4KICAgICAgICAgPHhtcE1NOkRvY3VtZW50SUQ+eG1wLmRpZDozMjBiNzQ0MC0xZWI3LWU2NGMtYWExMi01MmVjNzFjZmU0NDQ8L3htcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ+eG1wLmRpZDozMjBiNzQ0MC0xZWI3LWU2NGMtYWExMi01MmVjNzFjZmU0NDQ8L3htcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOkhpc3Rvcnk+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmFjdGlvbj5jcmVhdGVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6MzIwYjc0NDAtMWViNy1lNjRjLWFhMTItNTJlYzcxY2ZlNDQ0PC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE5LTA0LTMwVDEyOjI0OjUyKzA4OjAwPC9zdEV2dDp3aGVuPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6c29mdHdhcmVBZ2VudD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC9zdEV2dDpzb2Z0d2FyZUFnZW50PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDphY3Rpb24+c2F2ZWQ8L3N0RXZ0OmFjdGlvbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0Omluc3RhbmNlSUQ+eG1wLmlpZDowMTc5N2Y2MS1kYTBkLTZkNDMtYjdiNS1jYmVhYmMxYWY4ZGU8L3N0RXZ0Omluc3RhbmNlSUQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDp3aGVuPjIwMTktMDQtMzBUMTI6MjQ6NTIrMDg6MDA8L3N0RXZ0OndoZW4+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpzb2Z0d2FyZUFnZW50PkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cyk8L3N0RXZ0OnNvZnR3YXJlQWdlbnQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpjaGFuZ2VkPi88L3N0RXZ0OmNoYW5nZWQ+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwveG1wTU06SGlzdG9yeT4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgICAgPHBob3Rvc2hvcDpDb2xvck1vZGU+MzwvcGhvdG9zaG9wOkNvbG9yTW9kZT4KICAgICAgICAgPHBob3Rvc2hvcDpJQ0NQcm9maWxlPnNSR0IgSUVDNjE5NjYtMi4xPC9waG90b3Nob3A6SUNDUHJvZmlsZT4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+NzIwMDAwLzEwMDAwPC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj43MjAwMDAvMTAwMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+MTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+NTQ8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+NTQ8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/PiP4UGsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAxRJREFUeNrcmk1PE1EUhh8mCIoiNdMmboQSqIFoUugaF641iv/FhQt3bkz8M8To2oWsKSwIidCk1piQ0BFRPhQJdTFnzGScfjD33OmUJ7mbpvfMfed+zLnnnKFWq4UlXCAvbQK4CpwDJ8Ah0JTm2Xj4kJKw4ZCIoF2EZqSd9VvYDHAngZBehH4BamkLKwIlWWI2+QF8Auq2hTnAIjBNutSBNdmj6sIKQAUYpz/8FHF7msLmgPtkg01gS0PYAjBLttgB1rvtmU6UMygKGVM5qbA5OfmySgmYv6iwQob2VCfuyVh7EubI6TcoVOJ0xAlb7OORnoTxuIlwYjyKaQaPorS2wkoMLqV2wmZS8P1sMiEa/l03AiaVH3QdWJI9OwXk5DriAbtAFVgFjhSfORncCALPYxhYVjJ+BXgMPBVxnTgC3gLvgFOl568AZ4Gw2/J2TSkALxLMfgN43auD24VVYDfYYxoXRRd4lXBJT0pfV2Ec+fDhkVdYfs8NB+aKjRFNYaZv6pGSszwrtlSEucCQgaEbwDPFk21ZbBptC0dhGS4BY4rCxhQOsryGsLKFj+2ChrCcoREbvmXRsH/OAUYVXBkb7pEJow4XCGm14U8WHUcH+GVo47uFcR0Y9v/t4MfrTPhqQVjd9GU7+HFyEzYsCFs37N/UELYKHCuKOhabxsI8wCTlcihXBS1WxKYJXuArmibf3svVw5SG2DKarbATbLocT4E3wL6BjW9i4zRLwpDr/suEM9eQvrsK42jaCg2MSGjgSRZCAwAPlW6w4WDOA3Fop4Bb8vs+8FmO9I/KwRwP+BCeMfBDV4sMNlUkShWOK9YUXJl+ckAoGR+NBG8PsLDtqBMc9dHqAyjqv3HHZVvWFBzjNAmS7nQTdh73xwwTWybRLqO5h5+dzzqbtIked8pBb2FQ8pMCNTqURXSrGqjilx5kjR0ZW1t6LWCZx09kZ2X5qRSwBFzKkqPw0q1gHvdL8p2yViQWpgjcBW5aFpRaWV+UGfzclqssyJM7WuqFmFEuXelsJ6LFztfk9xPxxK0WO/8dAPx/3zmf5r6TAAAAAElFTkSuQmCC',
                    },
                    width: 10,
                    height: 10,
                    borderRadius: 10,
                    padding: 10,
                  },
                },
                {
                  //画剩余的刻度圆环
                  name: '',
                  value: 32,
                  label: {
                    show: false,
                  },
                  labelLine: {
                    show: false,
                    emphasis: {
                      show: false,
                    },
                  },
                },
              ],
            },
          ],
        },
        chGauge2: {
          color: ['#fff', 'rgba(255,255,255,.5)', 'rgba(255,255,255,.2)'],
          series: [
            {
              type: 'pie',
              center: ['50%', '50%'],
              radius: ['48%', '50%'],
              hoverAnimation: false,
              data: [
                {
                  name: '',
                  value: 52,
                  itemStyle: {
                    normal: {
                      color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                        {
                          offset: 0.5,
                          color: '#0c36fa',
                        },
                        {
                          offset: 1,
                          color: '#1ed9ba',
                        },
                      ]),
                    },
                  },
                  label: {
                    show: true,
                    position: 'center',
                    color: '#bfbfc7',
                    fontSize: 20,
                    formatter: function () {
                      return '52%'
                    },
                  },
                  labelLine: {
                    show: false,
                    emphasis: {
                      show: false,
                    },
                  },
                },
                {
                  //画中间的图标
                  name: '',
                  value: 0,
                  label: {
                    position: 'inside',
                    backgroundColor: {
                      image:
                        'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADYAAAA2CAYAAACMRWrdAAAACXBIWXMAAAsTAAALEwEAmpwYAAAKTWlDQ1BQaG90b3Nob3AgSUNDIHByb2ZpbGUAAHjanVN3WJP3Fj7f92UPVkLY8LGXbIEAIiOsCMgQWaIQkgBhhBASQMWFiApWFBURnEhVxILVCkidiOKgKLhnQYqIWotVXDjuH9yntX167+3t+9f7vOec5/zOec8PgBESJpHmomoAOVKFPDrYH49PSMTJvYACFUjgBCAQ5svCZwXFAADwA3l4fnSwP/wBr28AAgBw1S4kEsfh/4O6UCZXACCRAOAiEucLAZBSAMguVMgUAMgYALBTs2QKAJQAAGx5fEIiAKoNAOz0ST4FANipk9wXANiiHKkIAI0BAJkoRyQCQLsAYFWBUiwCwMIAoKxAIi4EwK4BgFm2MkcCgL0FAHaOWJAPQGAAgJlCLMwAIDgCAEMeE80DIEwDoDDSv+CpX3CFuEgBAMDLlc2XS9IzFLiV0Bp38vDg4iHiwmyxQmEXKRBmCeQinJebIxNI5wNMzgwAABr50cH+OD+Q5+bk4eZm52zv9MWi/mvwbyI+IfHf/ryMAgQAEE7P79pf5eXWA3DHAbB1v2upWwDaVgBo3/ldM9sJoFoK0Hr5i3k4/EAenqFQyDwdHAoLC+0lYqG9MOOLPv8z4W/gi372/EAe/tt68ABxmkCZrcCjg/1xYW52rlKO58sEQjFu9+cj/seFf/2OKdHiNLFcLBWK8ViJuFAiTcd5uVKRRCHJleIS6X8y8R+W/QmTdw0ArIZPwE62B7XLbMB+7gECiw5Y0nYAQH7zLYwaC5EAEGc0Mnn3AACTv/mPQCsBAM2XpOMAALzoGFyolBdMxggAAESggSqwQQcMwRSswA6cwR28wBcCYQZEQAwkwDwQQgbkgBwKoRiWQRlUwDrYBLWwAxqgEZrhELTBMTgN5+ASXIHrcBcGYBiewhi8hgkEQcgIE2EhOogRYo7YIs4IF5mOBCJhSDSSgKQg6YgUUSLFyHKkAqlCapFdSCPyLXIUOY1cQPqQ28ggMor8irxHMZSBslED1AJ1QLmoHxqKxqBz0XQ0D12AlqJr0Rq0Hj2AtqKn0UvodXQAfYqOY4DRMQ5mjNlhXIyHRWCJWBomxxZj5Vg1Vo81Yx1YN3YVG8CeYe8IJAKLgBPsCF6EEMJsgpCQR1hMWEOoJewjtBK6CFcJg4Qxwicik6hPtCV6EvnEeGI6sZBYRqwm7iEeIZ4lXicOE1+TSCQOyZLkTgohJZAySQtJa0jbSC2kU6Q+0hBpnEwm65Btyd7kCLKArCCXkbeQD5BPkvvJw+S3FDrFiOJMCaIkUqSUEko1ZT/lBKWfMkKZoKpRzame1AiqiDqfWkltoHZQL1OHqRM0dZolzZsWQ8ukLaPV0JppZ2n3aC/pdLoJ3YMeRZfQl9Jr6Afp5+mD9HcMDYYNg8dIYigZaxl7GacYtxkvmUymBdOXmchUMNcyG5lnmA+Yb1VYKvYqfBWRyhKVOpVWlX6V56pUVXNVP9V5qgtUq1UPq15WfaZGVbNQ46kJ1Bar1akdVbupNq7OUndSj1DPUV+jvl/9gvpjDbKGhUaghkijVGO3xhmNIRbGMmXxWELWclYD6yxrmE1iW7L57Ex2Bfsbdi97TFNDc6pmrGaRZp3mcc0BDsax4PA52ZxKziHODc57LQMtPy2x1mqtZq1+rTfaetq+2mLtcu0W7eva73VwnUCdLJ31Om0693UJuja6UbqFutt1z+o+02PreekJ9cr1Dund0Uf1bfSj9Rfq79bv0R83MDQINpAZbDE4Y/DMkGPoa5hpuNHwhOGoEctoupHEaKPRSaMnuCbuh2fjNXgXPmasbxxirDTeZdxrPGFiaTLbpMSkxeS+Kc2Ua5pmutG003TMzMgs3KzYrMnsjjnVnGueYb7ZvNv8jYWlRZzFSos2i8eW2pZ8ywWWTZb3rJhWPlZ5VvVW16xJ1lzrLOtt1ldsUBtXmwybOpvLtqitm63Edptt3xTiFI8p0in1U27aMez87ArsmuwG7Tn2YfYl9m32zx3MHBId1jt0O3xydHXMdmxwvOuk4TTDqcSpw+lXZxtnoXOd8zUXpkuQyxKXdpcXU22niqdun3rLleUa7rrStdP1o5u7m9yt2W3U3cw9xX2r+00umxvJXcM970H08PdY4nHM452nm6fC85DnL152Xlle+70eT7OcJp7WMG3I28Rb4L3Le2A6Pj1l+s7pAz7GPgKfep+Hvqa+It89viN+1n6Zfgf8nvs7+sv9j/i/4XnyFvFOBWABwQHlAb2BGoGzA2sDHwSZBKUHNQWNBbsGLww+FUIMCQ1ZH3KTb8AX8hv5YzPcZyya0RXKCJ0VWhv6MMwmTB7WEY6GzwjfEH5vpvlM6cy2CIjgR2yIuB9pGZkX+X0UKSoyqi7qUbRTdHF09yzWrORZ+2e9jvGPqYy5O9tqtnJ2Z6xqbFJsY+ybuIC4qriBeIf4RfGXEnQTJAntieTE2MQ9ieNzAudsmjOc5JpUlnRjruXcorkX5unOy553PFk1WZB8OIWYEpeyP+WDIEJQLxhP5aduTR0T8oSbhU9FvqKNolGxt7hKPJLmnVaV9jjdO31D+miGT0Z1xjMJT1IreZEZkrkj801WRNberM/ZcdktOZSclJyjUg1plrQr1zC3KLdPZisrkw3keeZtyhuTh8r35CP5c/PbFWyFTNGjtFKuUA4WTC+oK3hbGFt4uEi9SFrUM99m/ur5IwuCFny9kLBQuLCz2Lh4WfHgIr9FuxYji1MXdy4xXVK6ZHhp8NJ9y2jLspb9UOJYUlXyannc8o5Sg9KlpUMrglc0lamUycturvRauWMVYZVkVe9ql9VbVn8qF5VfrHCsqK74sEa45uJXTl/VfPV5bdra3kq3yu3rSOuk626s91m/r0q9akHV0IbwDa0b8Y3lG19tSt50oXpq9Y7NtM3KzQM1YTXtW8y2rNvyoTaj9nqdf13LVv2tq7e+2Sba1r/dd3vzDoMdFTve75TsvLUreFdrvUV99W7S7oLdjxpiG7q/5n7duEd3T8Wej3ulewf2Re/ranRvbNyvv7+yCW1SNo0eSDpw5ZuAb9qb7Zp3tXBaKg7CQeXBJ9+mfHvjUOihzsPcw83fmX+39QjrSHkr0jq/dawto22gPaG97+iMo50dXh1Hvrf/fu8x42N1xzWPV56gnSg98fnkgpPjp2Snnp1OPz3Umdx590z8mWtdUV29Z0PPnj8XdO5Mt1/3yfPe549d8Lxw9CL3Ytslt0utPa49R35w/eFIr1tv62X3y+1XPK509E3rO9Hv03/6asDVc9f41y5dn3m978bsG7duJt0cuCW69fh29u0XdwruTNxdeo94r/y+2v3qB/oP6n+0/rFlwG3g+GDAYM/DWQ/vDgmHnv6U/9OH4dJHzEfVI0YjjY+dHx8bDRq98mTOk+GnsqcTz8p+Vv9563Or59/94vtLz1j82PAL+YvPv655qfNy76uprzrHI8cfvM55PfGm/K3O233vuO+638e9H5ko/ED+UPPR+mPHp9BP9z7nfP78L/eE8/sl0p8zAAA6E2lUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4KPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS41LWMwMTQgNzkuMTUxNDgxLCAyMDEzLzAzLzEzLTEyOjA5OjE1ICAgICAgICAiPgogICA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPgogICAgICA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIgogICAgICAgICAgICB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIgogICAgICAgICAgICB4bWxuczpzdEV2dD0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlRXZlbnQjIgogICAgICAgICAgICB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iCiAgICAgICAgICAgIHhtbG5zOnBob3Rvc2hvcD0iaHR0cDovL25zLmFkb2JlLmNvbS9waG90b3Nob3AvMS4wLyIKICAgICAgICAgICAgeG1sbnM6dGlmZj0iaHR0cDovL25zLmFkb2JlLmNvbS90aWZmLzEuMC8iCiAgICAgICAgICAgIHhtbG5zOmV4aWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20vZXhpZi8xLjAvIj4KICAgICAgICAgPHhtcDpDcmVhdG9yVG9vbD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC94bXA6Q3JlYXRvclRvb2w+CiAgICAgICAgIDx4bXA6Q3JlYXRlRGF0ZT4yMDE5LTA0LTMwVDEyOjI0OjUyKzA4OjAwPC94bXA6Q3JlYXRlRGF0ZT4KICAgICAgICAgPHhtcDpNZXRhZGF0YURhdGU+MjAxOS0wNC0zMFQxMjoyNDo1MiswODowMDwveG1wOk1ldGFkYXRhRGF0ZT4KICAgICAgICAgPHhtcDpNb2RpZnlEYXRlPjIwMTktMDQtMzBUMTI6MjQ6NTIrMDg6MDA8L3htcDpNb2RpZnlEYXRlPgogICAgICAgICA8eG1wTU06SW5zdGFuY2VJRD54bXAuaWlkOjAxNzk3ZjYxLWRhMGQtNmQ0My1iN2I1LWNiZWFiYzFhZjhkZTwveG1wTU06SW5zdGFuY2VJRD4KICAgICAgICAgPHhtcE1NOkRvY3VtZW50SUQ+eG1wLmRpZDozMjBiNzQ0MC0xZWI3LWU2NGMtYWExMi01MmVjNzFjZmU0NDQ8L3htcE1NOkRvY3VtZW50SUQ+CiAgICAgICAgIDx4bXBNTTpPcmlnaW5hbERvY3VtZW50SUQ+eG1wLmRpZDozMjBiNzQ0MC0xZWI3LWU2NGMtYWExMi01MmVjNzFjZmU0NDQ8L3htcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD4KICAgICAgICAgPHhtcE1NOkhpc3Rvcnk+CiAgICAgICAgICAgIDxyZGY6U2VxPgogICAgICAgICAgICAgICA8cmRmOmxpIHJkZjpwYXJzZVR5cGU9IlJlc291cmNlIj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0OmFjdGlvbj5jcmVhdGVkPC9zdEV2dDphY3Rpb24+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDppbnN0YW5jZUlEPnhtcC5paWQ6MzIwYjc0NDAtMWViNy1lNjRjLWFhMTItNTJlYzcxY2ZlNDQ0PC9zdEV2dDppbnN0YW5jZUlEPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6d2hlbj4yMDE5LTA0LTMwVDEyOjI0OjUyKzA4OjAwPC9zdEV2dDp3aGVuPgogICAgICAgICAgICAgICAgICA8c3RFdnQ6c29mdHdhcmVBZ2VudD5BZG9iZSBQaG90b3Nob3AgQ0MgKFdpbmRvd3MpPC9zdEV2dDpzb2Z0d2FyZUFnZW50PgogICAgICAgICAgICAgICA8L3JkZjpsaT4KICAgICAgICAgICAgICAgPHJkZjpsaSByZGY6cGFyc2VUeXBlPSJSZXNvdXJjZSI+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDphY3Rpb24+c2F2ZWQ8L3N0RXZ0OmFjdGlvbj4KICAgICAgICAgICAgICAgICAgPHN0RXZ0Omluc3RhbmNlSUQ+eG1wLmlpZDowMTc5N2Y2MS1kYTBkLTZkNDMtYjdiNS1jYmVhYmMxYWY4ZGU8L3N0RXZ0Omluc3RhbmNlSUQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDp3aGVuPjIwMTktMDQtMzBUMTI6MjQ6NTIrMDg6MDA8L3N0RXZ0OndoZW4+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpzb2Z0d2FyZUFnZW50PkFkb2JlIFBob3Rvc2hvcCBDQyAoV2luZG93cyk8L3N0RXZ0OnNvZnR3YXJlQWdlbnQ+CiAgICAgICAgICAgICAgICAgIDxzdEV2dDpjaGFuZ2VkPi88L3N0RXZ0OmNoYW5nZWQ+CiAgICAgICAgICAgICAgIDwvcmRmOmxpPgogICAgICAgICAgICA8L3JkZjpTZXE+CiAgICAgICAgIDwveG1wTU06SGlzdG9yeT4KICAgICAgICAgPGRjOmZvcm1hdD5pbWFnZS9wbmc8L2RjOmZvcm1hdD4KICAgICAgICAgPHBob3Rvc2hvcDpDb2xvck1vZGU+MzwvcGhvdG9zaG9wOkNvbG9yTW9kZT4KICAgICAgICAgPHBob3Rvc2hvcDpJQ0NQcm9maWxlPnNSR0IgSUVDNjE5NjYtMi4xPC9waG90b3Nob3A6SUNDUHJvZmlsZT4KICAgICAgICAgPHRpZmY6T3JpZW50YXRpb24+MTwvdGlmZjpPcmllbnRhdGlvbj4KICAgICAgICAgPHRpZmY6WFJlc29sdXRpb24+NzIwMDAwLzEwMDAwPC90aWZmOlhSZXNvbHV0aW9uPgogICAgICAgICA8dGlmZjpZUmVzb2x1dGlvbj43MjAwMDAvMTAwMDA8L3RpZmY6WVJlc29sdXRpb24+CiAgICAgICAgIDx0aWZmOlJlc29sdXRpb25Vbml0PjI8L3RpZmY6UmVzb2x1dGlvblVuaXQ+CiAgICAgICAgIDxleGlmOkNvbG9yU3BhY2U+MTwvZXhpZjpDb2xvclNwYWNlPgogICAgICAgICA8ZXhpZjpQaXhlbFhEaW1lbnNpb24+NTQ8L2V4aWY6UGl4ZWxYRGltZW5zaW9uPgogICAgICAgICA8ZXhpZjpQaXhlbFlEaW1lbnNpb24+NTQ8L2V4aWY6UGl4ZWxZRGltZW5zaW9uPgogICAgICA8L3JkZjpEZXNjcmlwdGlvbj4KICAgPC9yZGY6UkRGPgo8L3g6eG1wbWV0YT4KICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAKICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIAogICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgCiAgICAgICAgICAgICAgICAgICAgICAgICAgICAKPD94cGFja2V0IGVuZD0idyI/PiP4UGsAAAAgY0hSTQAAeiUAAICDAAD5/wAAgOkAAHUwAADqYAAAOpgAABdvkl/FRgAAAxRJREFUeNrcmk1PE1EUhh8mCIoiNdMmboQSqIFoUugaF641iv/FhQt3bkz8M8To2oWsKSwIidCk1piQ0BFRPhQJdTFnzGScfjD33OmUJ7mbpvfMfed+zLnnnKFWq4UlXCAvbQK4CpwDJ8Ah0JTm2Xj4kJKw4ZCIoF2EZqSd9VvYDHAngZBehH4BamkLKwIlWWI2+QF8Auq2hTnAIjBNutSBNdmj6sIKQAUYpz/8FHF7msLmgPtkg01gS0PYAjBLttgB1rvtmU6UMygKGVM5qbA5OfmySgmYv6iwQob2VCfuyVh7EubI6TcoVOJ0xAlb7OORnoTxuIlwYjyKaQaPorS2wkoMLqV2wmZS8P1sMiEa/l03AiaVH3QdWJI9OwXk5DriAbtAFVgFjhSfORncCALPYxhYVjJ+BXgMPBVxnTgC3gLvgFOl568AZ4Gw2/J2TSkALxLMfgN43auD24VVYDfYYxoXRRd4lXBJT0pfV2Ec+fDhkVdYfs8NB+aKjRFNYaZv6pGSszwrtlSEucCQgaEbwDPFk21ZbBptC0dhGS4BY4rCxhQOsryGsLKFj+2ChrCcoREbvmXRsH/OAUYVXBkb7pEJow4XCGm14U8WHUcH+GVo47uFcR0Y9v/t4MfrTPhqQVjd9GU7+HFyEzYsCFs37N/UELYKHCuKOhabxsI8wCTlcihXBS1WxKYJXuArmibf3svVw5SG2DKarbATbLocT4E3wL6BjW9i4zRLwpDr/suEM9eQvrsK42jaCg2MSGjgSRZCAwAPlW6w4WDOA3Fop4Bb8vs+8FmO9I/KwRwP+BCeMfBDV4sMNlUkShWOK9YUXJl+ckAoGR+NBG8PsLDtqBMc9dHqAyjqv3HHZVvWFBzjNAmS7nQTdh73xwwTWybRLqO5h5+dzzqbtIked8pBb2FQ8pMCNTqURXSrGqjilx5kjR0ZW1t6LWCZx09kZ2X5qRSwBFzKkqPw0q1gHvdL8p2yViQWpgjcBW5aFpRaWV+UGfzclqssyJM7WuqFmFEuXelsJ6LFztfk9xPxxK0WO/8dAPx/3zmf5r6TAAAAAElFTkSuQmCC',
                    },
                    width: 10,
                    height: 10,
                    borderRadius: 10,
                    padding: 10,
                  },
                },
                {
                  //画剩余的刻度圆环
                  name: '',
                  value: 48,
                  label: {
                    show: false,
                  },
                  labelLine: {
                    show: false,
                    emphasis: {
                      show: false,
                    },
                  },
                },
              ],
            },
          ],
        },
        chPieDate: {
          color: [
            '#d21162',
            '#0092ff',
            '#eba954',
            '#21b6b9',
            '#60a900',
            '#01949b',
            ' #f17677',
          ],
          legend: {
            show: true,
            orient: 'vertical',
            right: 'right',
            textStyle: {
              color: '#fff',
            },
            data: ['人脸', '车牌', '行人', '车辆', '人骑车'],
          },
          series: [
            {
              type: 'pie',
              radius: '45%',
              center: ['39%', '33%'],
              data: [
                {
                  value: 335,
                  name: '人脸',
                },
                {
                  value: 310,
                  name: '车牌',
                },
                {
                  value: 234,
                  name: '行人',
                },
                {
                  value: 135,
                  name: '车辆',
                },
                {
                  value: 1548,
                  name: '人骑车',
                },
              ],
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)',
                },
              },
              label: {
                normal: {
                  textStyle: {
                    fontSize: 14,
                    color: '#fff',
                  },
                },
              },
            },
          ],
        },
        chPie: {
          dataset: {
            source: [
              ['product', 'nums'],
              ['数字视网膜IPC', 22],
              ['数字视网膜分析盘', 29],
              ['5G终端', 37],
              ['其他', 12],
            ],
          },
          color: [
            '#d74e67',
            '#0092ff',
            '#eba954',
            '#21b6b9',
            '#60a900',
            '#01949b',
            ' #f17677',
          ],
          tooltip: {
            trigger: 'item',
            formatter: '',
          },
          grid: {
            left: '25%',
            top: 0,
            right: '10%',
            containLabel: true,
          },
          xAxis: [
            {
              show: false,
            },
            {
              show: false,
            },
          ],
          yAxis: {
            type: 'category',
            inverse: true,
            show: false,
          },
          series: [
            {
              tooltip: {
                trigger: 'item',
                formatter: '{b}\n{d}%',
              },
              type: 'pie',
              center: ['25%', '35%'],
              radius: ['35%', '50%'],
              avoidLabelOverlap: false,
              label: {
                normal: {
                  show: true,
                  formatter: '{d}%',
                  position: 'inside',
                },
              },
              labelLine: {
                normal: {},
              },
              encode: {
                itemName: 'product',
                value: 'nums',
              },
            },
            //亮色条 百分比
            {
              show: true,
              type: 'bar',
              barWidth: '20%',
              z: 2,
              color: function (params) {
                // build a color map as your need.
                var colorList = ['#d74e67', '#0092ff', '#eba954', '#21b6b9']
                return colorList[params.dataIndex]
              },
              tooltip: {
                trigger: 'axis',
                formatter: '{b} : {c} ({d}%)',
              },
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    // color: '#ae86e9',
                    fontSize: 12,
                    // fontWeight: 'bold'
                  },
                  // position: 'insideBottomRight',
                  position: 'right',
                },
              },
              encode: {
                x: 'nums',
              },
            },
            //年份
            {
              show: true,
              type: 'bar',
              xAxisIndex: 1, //代表使用第二个X轴刻度
              barGap: '-100%',
              barWidth: '10%',
              itemStyle: {
                normal: {
                  barBorderRadius: 200,
                  color: 'transparent',
                },
              },
              label: {
                normal: {
                  show: true,
                  position: [0, '-15'],
                  formatter: '{b}',
                  textStyle: {
                    fontSize: 14,
                    color: '#ae86e9',
                  },
                },
              },
              encode: {
                y: 'product',
              },
            },
          ],
        },
        chFirstBar: {
          title: {
            text: '单位:百分比',
            top: -3,
            textStyle: {
              color: '#524D76',
              fontSize: 12,
            },
          },
          tooltip: {
            trigger: 'axis',
          },
          color: ['#fff'],
          grid: {
            left: '3%',
            right: '4%',
            bottom: '3%',
            height: '80%',
            containLabel: true,
          },
          xAxis: [
            {
              type: 'category',
              color: '#fff',
              data: ['监测跟踪', '图像分割', '其他', '图搜', '聚类', '其他'],
              // axisPointer: {
              //   type: 'line'
              // },
              axisLine: {
                lineStyle: {
                  color: '#272456',
                },
              },
              axisLabel: {
                interval: 0,
                rotate: 20,
                color: '#fff',
              },
            },
          ],
          yAxis: [
            {
              type: 'value',
              min: 0,
              max: 100,
              color: '#4a3f69',
              // axisLabel: {
              //   // formatter: '{value}%',
              //   color: '#03E2DA'
              // },
              axisLine: {
                lineStyle: {
                  color: '#4a3f69',
                },
              },
              splitLine: {
                show: false,
              },
              nameTextStyle: {
                color: '#999',
              },
              // axisLine: {
              //   lineStyle: {
              //     color: '#03E2DA'
              //   }
              // },
              axisLabel: {
                // margin: 20,
                formatter: '{value} %',
                color: '#4a3f69',
                textStyle: {
                  fontSize: 12,
                },
              },
            },
          ],
          series: [
            {
              type: 'bar',
              data: [100, 90, 10, 90, 90, 20, 56, 89],
              barWidth: 10,
              itemStyle: {
                normal: {
                  color: function (params) {
                    var num = [
                      '#51ca3d',
                      '#51ca3d',
                      '#51ca3d',
                      '#DF1453',
                      '#DF1453',
                      '#DF1453',
                    ].length
                    return [
                      '#51ca3d',
                      '#51ca3d',
                      '#51ca3d',
                      '#DF1453',
                      '#DF1453',
                      '#DF1453',
                    ][params.dataIndex % num]
                  },
                },
              },
            },
          ],
        },
        chBar: {
          grid: {
            left: '5%',
            top: '5%',
            right: '0%',
            bottom: '0%',
            containLabel: true,
          },
          xAxis: [
            {
              show: false,
            },
          ],
          yAxis: [
            {
              axisTick: 'none',
              axisLine: 'none',
              offset: '17',
              axisLabel: {
                textStyle: {
                  color: '#ffffff',
                  fontSize: '12',
                },
                margin: 0,
              },
              data: [
                '计算节点(68个/70个)',
                '存储资源(6.5PB/10PB)',
                '内存资源(8.1TB/22.5TB)',
                'NPU资源(160T/320T)',
                'GPU资源(7.6PFLOPS/13.6PFLOPS)',
                'CPU资源(172.8核/360核 )',
              ],
            },
            {
              axisTick: 'none',
              axisLine: 'none',
              axisLabel: {
                textStyle: {
                  color: '#ffffff',
                  fontSize: '16',
                },
              },
              data: ['', '', '', '', '', ''],
            },
            {
              nameGap: '50',
              nameTextStyle: {
                color: '#ffffff',
                fontSize: '16',
              },
              axisLine: {
                lineStyle: {
                  color: 'rgba(0,0,0,0)',
                },
              },
              data: [],
            },
          ],
          series: [
            {
              name: '条',
              type: 'bar',
              yAxisIndex: 0,
              barWidth: 5,
              data: [97.14, 65, 36, 50, 32, 48],
              label: {
                normal: {
                  show: true,
                  // position: 'insideBottomRight',
                  position: 'insideBottomLeft',
                  formatter: '{c}%',
                  textStyle: {
                    color: '#11CED1',
                    fontSize: '12',
                  },
                },
              },
              itemStyle: {
                normal: {
                  color: function (params) {
                    var num = [
                      '#A54374',
                      '#BD93FD',
                      '#DFF292',
                      '#FFD260',
                      '#e48d37',
                    ].length
                    return [
                      '#A54374',
                      '#BD93FD',
                      '#DFF292',
                      '#FFD260',
                      '#e48d37',
                    ][params.dataIndex % num]
                  },
                  barBorderRadius: [0, 30, 30, 0],
                },
              },
              z: 2,
            },
            {
              name: '白框',
              type: 'bar',
              yAxisIndex: 1,
              barGap: '-100%',
              data: [99, 99.5, 99.5, 99.5, 99.5, 99.5],
              barWidth: 5,
              itemStyle: {
                normal: {
                  color: '#fff',
                  barBorderRadius: 5,
                },
              },
              z: 1,
            },
          ],
        },
        cityData: [
          {
            id: 0,
            icon: 'el-icon-s-data',
            name: '视频数据',
            num: 6343,
            unit: 'PB',
          },
          {
            id: 1,
            icon: 'el-icon-picture',
            name: '图片数据',
            num: 1254,
            unit: 'GB',
          },
          {
            id: 2,
            icon: 'el-icon-s-platform',
            name: '情报数据',
            num: 104,
            unit: 'GB',
          },
          {
            id: 3,
            icon: 'el-icon-s-marketing',
            name: '压缩比',
            num: 83,
            unit: '%',
          },
          {
            id: 4,
            icon: 'el-icon-s-platform',
            name: '数据利用率',
            num: 72,
            unit: '%',
          },
        ],
        analyseTasks: [
          {
            id: 0,
            name: '突发拥堵检测',
            num: 176,
          },
          {
            id: 1,
            name: '故障车辆检测',
            num: 58,
          },
          {
            id: 2,
            name: '交通事故检测',
            num: 8,
          },
          {
            id: 3,
            name: '出口道溢出检测',
            num: 87,
          },
          {
            id: 4,
            name: '违停检测',
            num: 32,
          },
          {
            id: 5,
            name: '其他',
            num: 19,
          },
        ],
        dialogTableVisible: false,
        dialogVisible: false,
        addressPoints: [
          [116.25264, 39.8277],
          [116.35358, 39.95599],
          [116.34671, 39.94968],
          [116.34877, 39.9402],
          [116.37314, 39.93599],
          [116.3419, 39.90703],
          [116.37074, 39.92177],
          [116.34568, 39.9631],
        ],
        // addressPoints1: [[116.3316, 39.94402], [116.35598, 39.9219], [116.3546, 39.87739],],
        addressPoints2: [
          [116.3316, 39.94402],
          [116.35598, 39.9219],
          [116.3546, 39.87739],
          [116.4679, 39.95889],
          [116.47305, 39.90307],
          [116.40198, 39.86909],
          [116.3086, 39.85591],
        ],
        addressPoints3: [
          [116.23375, 39.86184],
          [116.39649, 39.83641],
          [116.52867, 39.83667],
          [116.5345, 39.90202],
          [116.48335, 39.93625],
          [116.30483, 39.90123],
          [116.45142, 39.8878],
          [116.48301, 39.92598],
          [116.39992, 39.91624],
          [116.39134, 39.86224],
        ],
        // addressPoints4: [[116.30483, 39.90123], [116.45142, 39.8878], [116.48301, 39.92598], [116.39992, 39.91624], [116.39134, 39.86224]],
        addressPoints5: [
          [116.30155, 39.82217],
          [116.20783, 39.88305],
          [116.28869, 39.86659],
          [116.36559, 39.84155],
          [116.46824, 39.82178],
          [116.32233, 39.90176],
          [116.42155, 39.92835],
          [116.38413, 39.86105],
          [116.28766, 39.93823],
          [116.23238, 39.98375],
        ],
        // addressPoints6: [[116.38413, 39.86105], [116.28766, 39.93823], [116.23238, 39.98375], [116.37074, 39.92177], [116.34568, 39.9631]],
        interval1: null,
        interval2: null,
        interval3: null,
        interval4: null,
        interval5: null,
        interval6: null,
      }
    },
    computed: {
      ...mapGetters(['name']),
    },
    mounted() {
      this.$nextTick(() => {
        this.getTimeFuc()
        this.initMap()
        this.barAnimate()
        this.barChange()
        /* this.tabPanelAnimate();
        this.tabPanelAnimate1(); */
        this.numChange()
      })
    },
    destroyed() {
      clearInterval(this.interval1)
      clearInterval(this.interval2)
      clearInterval(this.interval3)
      clearInterval(this.interval4)
      clearInterval(this.interval5)
      clearInterval(this.interval6)
      this.interval1 = null
      this.interval2 = null
      this.interval3 = null
      this.interval4 = null
      this.interval5 = null
      this.interval6 = null
    },
    methods: {
      getTimeFuc() {
        const myDate1 = new Date()
        const date51 = new Date(
          myDate1.toLocaleDateString() + ' 5:00:00'
        ).getTime()
        const dataC1 = ((myDate1.getTime() - date51) / 1000) * 3200
        this.num3 = parseFloat(dataC1)
      },
      barChange() {
        const that = this
        this.interval1 = setInterval(() => {
          setTimeout(() => {
            const a = Math.floor(Math.random() * 4) //0-4
            const b = Math.floor(Math.random() * 4 + 1) //1-10
            let val1 = 0
            let val2 = 0
            let c = a
            if (a == 4) {
              c = a - 1
            } else {
              c = a + 1
            }
            if (a <= 2) {
              val1 = parseInt(that.area.series[0].data[a]) - b
              val2 = parseInt(that.area.series[0].data[c]) + b
              if (val1 <= 0) {
                val1 = 1
                val2 = parseInt(that.area.series[0].data[c]) + 1 - val1
              } else {
                val2 = parseInt(that.area.series[0].data[c]) + b
              }
              if (val2 >= 5269) {
                val1 = val2 - 5269 + val1
                val2 = 5269
              }
            } else {
              val1 = parseInt(that.area.series[0].data[a]) + b
              val2 = parseInt(that.area.series[0].data[c]) - b
              if (val2 <= 0) {
                val2 = 1
                val1 = val1 - (1 - val2)
              } else {
                val2 = parseInt(that.area.series[0].data[c]) - b
              }
              if (val1 >= 5269) {
                val2 = val1 - 5269 + val2
                val1 = 5269
              }
            }

            that.$set(that.area.series[0].data, a, val1)
            that.$set(that.area.series[0].data, c, val2)
          }, 10)
        }, 4000)
      },
      // 大数据云脑数字变化
      numChange() {
        const that = this
        this.interval2 = setInterval(() => {
          setTimeout(() => {
            // const a = Math.round(Math.random()*100)/100;
            const b = Math.floor(Math.random() * 500 + 3000)
            //const c = Math.round(Math.random()*100)/100;
            // that.oldNum1 = that.num1;
            that.oldNum2 = that.num2
            that.oldNum3 = that.num3
            // that.num1 = a;
            that.num2 = b
            that.num3 += b
            /* that.oldRate = that.rate; */
          }, 10)
        }, 2000)
      },
      // 融合大数据动效
      tabPanelAnimate() {
        const that = this
        let index = -1
        const activeIndex = ['item1', 'item2', 'item3']
        this.interval3 = setInterval(() => {
          index = (index + 1) % 3
          that.activeItem = activeIndex[index]
        }, 4000)
      },
      // 融合大数据动效
      tabPanelAnimate1() {
        const that = this
        let index = -1
        const activeIndex1 = ['item11', 'item12']
        this.interval4 = setInterval(() => {
          index = (index + 1) % 2
          that.activeItem1 = activeIndex1[index]
        }, 4000)
      },
      // 柱状图动效
      barAnimate() {
        const that = this
        const app = {
          currentIndex: -1,
        }
        const myChart = this.$refs.bar
        this.interval5 = setInterval(function () {
          const dataLen = that.area.series[0].data.length
          // 取消之前高亮的图形
          myChart.dispatchAction({
            type: 'downplay',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          app.currentIndex = (app.currentIndex + 1) % dataLen
          // 高亮当前图形
          myChart.dispatchAction({
            type: 'highlight',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          // 显示 tooltip
          myChart.dispatchAction({
            type: 'showTip',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
        }, 4100)
      },
      handleClick(row) {
        console.log(row)
      },
      jqqd() {
        this.$BaseAlert('当前页面正在重新规划，敬请期待！')
      },
      initMap() {
        const that = this
        var mapv = require('mapv')
        const map = new maptalks.Map('map', this.$baseMap())
        map.on('click', function (param) {
          console.log(param.coordinate.toFixed(5).toArray().join())
        })
        getList().then((res) => {
          const data = []
          const timeData = []
          const rs = res.data.split('\n')
          let maxLength = 0
          for (let i = 0; i < rs.length; i++) {
            const item = rs[i].split(',')
            const coordinates = []
            if (item.length > maxLength) {
              maxLength = item.length
            }
            for (let j = 0; j < item.length; j += 2) {
              const x = (Number(item[j]) / 20037508.34) * 180
              let y = (Number(item[j + 1]) / 20037508.34) * 180
              y =
                (180 / Math.PI) *
                (2 * Math.atan(Math.exp((y * Math.PI) / 180)) - Math.PI / 2)
              // eslint-disable-next-line use-isnan
              if (x == 0 || y == NaN) {
                continue
              }
              coordinates.push([x, y])
              timeData.push({
                geometry: {
                  type: 'Point',
                  coordinates: [x, y],
                },
                count: 1,
                time: j,
              })
            }
            data.push({
              geometry: {
                type: 'LineString',
                coordinates: coordinates,
              },
            })
          }

          const dataSet = new mapv.DataSet(data)

          const options = {
            strokeStyle: '#8B1F17',
            globalCompositeOperation: 'lighter',
            lineWidth: 1.0,
            draw: 'simple',
          }
          new mapv.MaptalksLayer('mapv1', dataSet, options).addTo(map)

          const dataSet2 = new mapv.DataSet(timeData)

          const options2 = {
            fillStyle: '#81F9F7',
            globalCompositeOperation: 'lighter',
            zIndex: '10',
            size: 1.5,
            animation: {
              stepsRange: {
                start: 0,
                end: 100,
              },
              trails: 3,
              duration: 5,
            },
            draw: 'simple',
          }

          new mapv.MaptalksLayer('mapv', dataSet2, options2).addTo(map)
        })
        // mark点击弹框
        function onClick() {
          // that.dialogTableVisible = true;
          console.log(that.$refs)
          that.$refs.tankuang.openTk()
          /* e.target.setInfoWindow({
                  'content': '<div class="map-popover">' +
                    '<div class="mark-info">' +
                    '<div class="waver-box">' +
                    '        <span class="waver-span waver-spanr waver-span1"></span>' +
                    '        <span class="waver-span waver-spanr waver-span2"></span>' +
                    '        <span class="waver-span waver-spanr waver-span3"></span>' +
                    '        <span class="waver-span waver-spanr waver-span4"></span>' +
                    '    </div>' +
                    '</div>' +
                    '</div>',
                  'width': 300,
                  'minHeight': 100,
                  'dy': 5,
                  'autoPan': true,
                  'custom': false,
                  'autoOpenOn': 'click', //set to null if not to open when clicking on marker
                  'autoCloseOn': 'click'
                }) */
        }

        function onClick2() {
          that.$refs.tankuang2.openTk()
        }

        function onClick3() {
          that.$refs.tankuang3.openTk()
        }

        function onClick5() {
          that.$refs.tankuang5.openTk()
        }

        /*maptalks的Mark的变形动画-----------------开始*/
        //图片标注+点击弹框
        const markers = []
        for (let i = 0; i < this.addressPoints.length; i++) {
          const a = this.addressPoints[i]
          markers.push(
            new maptalks.Marker([a[0], a[1]], {
              symbol: [
                {
                  markerType: 'ellipse',
                  markerWidth: 30,
                  markerHeight: 30,
                  markerFill: '#7EF0E8',
                  markerFillOpacity: 0.7,
                  markerLineColor: '#7EF0E8',
                  markerLineWidth: 0,
                },
                {
                  markerType: 'ellipse',
                  markerWidth: 15,
                  markerHeight: 15,
                  markerFill: '#7EF0E8',
                  markerFillOpacity: 0.7,
                  markerLineWidth: 0,
                },
              ],
            }).on('mousedown', onClick)
          )
        }
        const markerLayer = new maptalks.VectorLayer('vector', markers, {
          zIndex: '100',
        })
        // //图片标注+点击弹框
        // const markers1 = [];
        // for (let i = 0; i < this.addressPoints1.length; i++) {
        //   const a = this.addressPoints1[i];
        //   markers1.push(
        //     new maptalks.Marker([a[0], a[1]], {
        //       symbol: [
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 30,
        //           markerHeight: 30,
        //           markerFill: '#7EF0E8',
        //           markerFillOpacity: 0.7,
        //           markerLineColor: '#7EF0E8',
        //           markerLineWidth: 0
        //         },
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 15,
        //           markerHeight: 15,
        //           markerFill: '#7EF0E8',
        //           markerFillOpacity: 0.7,
        //           markerLineWidth: 0
        //         }
        //       ]
        //     }).on('mousedown', onClick1)
        //   );
        // }
        // const markerLayer1 = new maptalks.VectorLayer('vector1', markers1, {
        //   zIndex: '100'
        // });
        //第三个点
        const markers2 = []
        for (let i = 0; i < this.addressPoints2.length; i++) {
          const a = this.addressPoints2[i]
          markers2.push(
            new maptalks.Marker([a[0], a[1]], {
              symbol: [
                {
                  markerType: 'ellipse',
                  markerWidth: 30,
                  markerHeight: 30,
                  markerFill: '#6E72EB',
                  markerFillOpacity: 0.7,
                  markerLineColor: '#6E72EB',
                  markerLineWidth: 0,
                },
                {
                  markerType: 'ellipse',
                  markerWidth: 15,
                  markerHeight: 15,
                  markerFill: '#6E72EB',
                  markerFillOpacity: 0.7,
                  markerLineWidth: 0,
                },
              ],
            }).on('mousedown', onClick2)
          )
        }
        const markerLayer2 = new maptalks.VectorLayer('vector2', markers2, {
          zIndex: '100',
        })
        //第四个
        const markers3 = []
        for (let i = 0; i < this.addressPoints3.length; i++) {
          const a = this.addressPoints3[i]
          markers3.push(
            new maptalks.Marker([a[0], a[1]], {
              symbol: [
                {
                  markerType: 'ellipse',
                  markerWidth: 30,
                  markerHeight: 30,
                  markerFill: '#C91554',
                  markerFillOpacity: 0.7,
                  markerLineColor: '#C91554',
                  markerLineWidth: 0,
                },
                {
                  markerType: 'ellipse',
                  markerWidth: 15,
                  markerHeight: 15,
                  markerFill: '#C91554',
                  markerFillOpacity: 0.7,
                  markerLineWidth: 0,
                },
              ],
            }).on('mousedown', onClick3)
          )
        }
        const markerLayer3 = new maptalks.VectorLayer('vector3', markers3, {
          zIndex: '100',
        })
        // //第五个点
        // const markers4 = [];
        // for (let i = 0; i < this.addressPoints4.length; i++) {
        //   const a = this.addressPoints4[i];
        //   markers4.push(
        //     new maptalks.Marker([a[0], a[1]], {
        //       symbol: [
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 30,
        //           markerHeight: 30,
        //           markerFill: '#FFFFFF',
        //           markerFillOpacity: 0.7,
        //           markerLineColor: '#FFFFFF',
        //           markerLineWidth: 0
        //         },
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 15,
        //           markerHeight: 15,
        //           markerFill: '#FFFFFF',
        //           markerFillOpacity: 0.7,
        //           markerLineWidth: 0
        //         }
        //       ]
        //     }).on('mousedown', onClick4)
        //   );
        // }
        // const markerLayer4 = new maptalks.VectorLayer('vector4', markers4, {
        //   zIndex: '100'
        // });
        //第六个点
        const markers5 = []
        for (let i = 0; i < this.addressPoints5.length; i++) {
          const a = this.addressPoints5[i]
          markers5.push(
            new maptalks.Marker([a[0], a[1]], {
              symbol: [
                {
                  markerType: 'ellipse',
                  markerWidth: 30,
                  markerHeight: 30,
                  markerFill: '#f79737',
                  markerFillOpacity: 0.7,
                  markerLineColor: '#f79737',
                  markerLineWidth: 0,
                },
                {
                  markerType: 'ellipse',
                  markerWidth: 15,
                  markerHeight: 15,
                  markerFill: '#f79737',
                  markerFillOpacity: 0.7,
                  markerLineWidth: 0,
                },
              ],
            }).on('mousedown', onClick5)
          )
        }
        const markerLayer5 = new maptalks.VectorLayer('vector5', markers5, {
          zIndex: '100',
        })
        // //第七个点
        // const markers6 = [];
        // for (let i = 0; i < this.addressPoints6.length; i++) {
        //   const a = this.addressPoints6[i];
        //   markers6.push(
        //     new maptalks.Marker([a[0], a[1]], {
        //       symbol: [
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 30,
        //           markerHeight: 30,
        //           markerFill: '#4db234',
        //           markerFillOpacity: 0.7,
        //           markerLineColor: '#4db234',
        //           markerLineWidth: 0
        //         },
        //         {
        //           markerType: 'ellipse',
        //           markerWidth: 15,
        //           markerHeight: 15,
        //           markerFill: '#4db234',
        //           markerFillOpacity: 0.7,
        //           markerLineWidth: 0
        //         }
        //       ]
        //     }).on('mousedown', onClick6)
        //   );
        // }
        // const markerLayer6 = new maptalks.VectorLayer('vector6', markers6, {
        //   zIndex: '100'
        // });
        // //7结束
        // 聚合效果
        /* const clusterLayer = new ClusterLayer('cluster', markers, {
                'noClusterWithOneMarker': false,
                'maxClusterZoom': 16,
                zIndex: '100',
                //"count" is an internal variable: marker count in the cluster.
                'symbol': {
                  'markerType': 'ellipse',
                  'markerFill': {
                    property: 'count',
                    type: 'interval',
                    stops: [
                      [0, 'rgb(135, 196, 240)'],
                      [9, '#1bbc9b'],
                      [99, 'rgb(216, 115, 149)']
                    ]
                  },
                  'markerFillOpacity': 0.7,
                  'markerLineOpacity': 1,
                  'markerLineWidth': 3,
                  'markerLineColor': '#fff',
                  'markerWidth': {
                    property: 'count',
                    type: 'interval',
                    stops: [
                      [0, 40],
                      [9, 60],
                      [99, 80]
                    ]
                  },
                  'markerHeight': {
                    property: 'count',
                    type: 'interval',
                    stops: [
                      [0, 40],
                      [9, 60],
                      [99, 80]
                    ]
                  }
                },
                'drawClusterText': true,
                'geometryEvents': true,
                'single': true
              }) */
        map.addLayer(markerLayer)
        // map.addLayer(markerLayer1);
        map.addLayer(markerLayer2)
        map.addLayer(markerLayer3)
        // map.addLayer(markerLayer4);
        map.addLayer(markerLayer5)
        // map.addLayer(markerLayer6);

        /*maptalks的Mark的变形动画-----------------结束*/
      },
    },
  }
</script>
<style lang="scss">
  @mixin base-scrollbar {
    &::-webkit-scrollbar {
      width: 8px;
      height: 8px;
    }
    &::-webkit-scrollbar-thumb {
      background-color: rgba(#232b4b, 0.8);
      border: 3px solid transparent;
      border-radius: 7px;
    }
    &::-webkit-scrollbar-thumb:hover {
      background-color: rgba(#232b4b, 0.9);
    }
  }

  * {
    @include base-scrollbar;
  }

  .right-panel-item {
    .el-menu-demo {
      background: transparent;
      color: #fff;

      .el-tabs__item {
        color: #fff;
        padding: 0 10px;
      }

      .el-tabs__nav-wrap::after {
        background: none;
      }

      .el-tabs__header {
        top: 10px;
        left: 40px;
      }

      .el-tabs__item.is-active {
        color: #409eff;
      }
    }
  }
</style>
<style lang="scss" scoped>
  ::v-deep {
    .vab-screen-card {
      background: rgba(0, 0, 0, 0.3);
      color: #fff;
      border: none;
      margin-bottom: 0;
      .el-card__header {
        border-bottom: 0;
      }
      .el-card__body {
        padding-top: 0;
        text-align: left;
      }
      .byui-card-header {
        display: inline-block;
        width: 100% !important;
        font-size: 15px;
        margin-left: -15px;
        text-indent: 13px;
        border-left: 2px solid #00ffff;
        height: 14px;
        line-height: 14px;
      }
    }

    .ydsfc-table {
      background: transparent;
      &::before {
        height: 0px;
      }
      tr,
      td {
        background-color: rgba(6, 50, 117, 0.8) !important;
        color: #fff !important;
        border: 0px;
        border-top: 1px dashed #106ae1;
      }
      tr:hover {
        background-color: rgba(6, 50, 117, 0.3) !important;
      }
      td .cell {
        color: #fff !important;
      }
      .has-gutter {
        background-color: rgba(6, 50, 117, 0.8) !important;
        color: #fff !important;
        .cell {
          color: #fff !important;
        }
        th {
          background-color: rgba(6, 50, 117, 0.8) !important;
          padding: 3px 0px;
          border: 0px;
        }
        .el-table__row {
          border-top: 1px dashed #106ae1;
        }
      }
    }
  }
  .fade-enter-active,
  .fade-leave-active {
    transition: all 0.5s;
  }

  .fade-enter,
  .fade-leave-to {
    opacity: 0;
    transform: translateX(100px);
  }

  ::v-deep.el-card {
    background: none;
    border: none;
    margin-bottom: 0px !important;
  }

  ::v-deep.el-dialog__body {
    padding: 21px 20px 0px 20px !important;
  }

  ::v-deep.vab-dialog2 {
    padding-bottom: 0 !important;
    min-height: 632px !important;
    width: 1357px !important;
  }

  ::v-deep.el-switch {
    width: 194px !important;
    height: 25px;
    margin-right: 31px;
    margin-top: 7px;
  }

  ::v-deep.el-switch__label > span {
    font-size: 15px;
    color: #ffffff;
    width: 120px;
  }

  .left-panel1-item {
    height: 58px;
    background: rgba(22, 53, 125, 0.8);
    padding: 14px 0px 14px 5px;
    /* border: solid 1px transparent; */

    &.active {
      border: solid 1px #3b90f3;
      background: rgba(22, 53, 125, 1);
    }

    .item-img {
      width: 25px;
      margin-right: 2px;
    }

    .item-txt {
      display: inline-block;
      font-size: 12px;
      color: #bee4f8;

      .color-txt {
        color: #fff;

        span {
          display: inline-block;
          font-size: 18px;
          letter-spacing: 1px;
          color: #dfe110;
          margin-right: 5px;
        }
      }
    }
  }

  .item-detail {
    position: absolute;
    left: 6px;
    right: 6px;
    height: 138px;

    i {
      position: relative;
      color: rgba($color: #3b90f3, $alpha: 0.8);
      font-size: 20px;
      z-index: 100;
    }

    .icon1 {
      left: 12%;
    }

    .icon2 {
      left: 46%;
    }

    .icon3 {
      left: 80%;
    }

    .item-detail-content {
      position: relative;
      top: -8px;
      height: 128px;
      background: rgba($color: #063275, $alpha: 0.8);
      border: solid 1px #3b90f3;
      box-shadow: 0px 0px 4px 0 #3b90f3;
      z-index: 10;
      padding: 12px 10px;

      .content-item {
        width: 100%;
        height: 30px;
        background: url('~@/assets/map_images/item_bg.png') no-repeat;
        background-size: 100% 100%;
        margin-bottom: 8px;
        line-height: 28px;
        padding-left: 32px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }
  }

  .homebntjt {
    position: absolute;
    right: 0;
    height: 20px;
    line-height: 18px;
    width: 40px !important;
    border-radius: 10px;
    font-size: 20px;
    text-align: center;
    background-color: #0d0129;
    color: #334ea5;
    cursor: pointer;
    border: solid 1px #41365e;
  }

  .map-container {
    overflow: hidden;
    height: 100vh;

    .height-box {
      position: relative;
      z-index: 999;
      height: 100vh;
      overflow: auto;

      ::-webkit-scrollbar-thumb {
        background: #3b90f3;
        border-radius: 10px;
      }

      ::-webkit-scrollbar-thumb:hover {
        background: #3b90f3;
      }
    }

    .container-map {
      position: fixed;
      top: 0;
      bottom: 0;
      right: 0;
      left: 0;
      z-index: 0;
    }

    .right-panel2-item {
      width: 100%;
      height: 170px;
      position: relative;

      .circle-box {
        width: 100%;
        height: 76px;
        background: url('~@/assets/map_images/szswmzdlx-top-left.png') no-repeat;
        background-size: 100% 100%;
        margin-bottom: 15px;
        padding: 15px 0 0 30px;

        &:hover {
          background: url('~@/assets/map_images/szswmzdlx-top-left-hover.png')
            no-repeat;
          background-size: 100% 100%;
        }

        .num {
          font-size: 26px;
          line-height: 24px;
          letter-spacing: 0px;
          color: #ffffff;
          font-family: font_num;
        }

        .txt {
          font-size: 12px;
          line-height: 24px;
          letter-spacing: 0px;
          color: #6ea7da;
        }
      }

      .el-col:nth-child(2) .circle-box {
        padding: 15px 0 0 65px;
        background: url('~@/assets/map_images/szswmzdlx-top-right.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .el-col:nth-child(3) .circle-box {
        background: url('~@/assets/map_images/szswmzdlx-bottom-left.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .el-col:nth-child(4) .circle-box {
        padding: 15px 0 0 65px;
        background: url('~@/assets/map_images/szswmzdlx-bottom-right.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .el-col:nth-child(2):hover .circle-box {
        padding: 15px 0 0 65px;
        background: url('~@/assets/map_images/szswmzdlx-top-right-hover.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .el-col:nth-child(3):hover .circle-box {
        background: url('~@/assets/map_images/szswmzdlx-bottom-left-hover.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .el-col:nth-child(4):hover .circle-box {
        padding: 15px 0 0 65px;
        background: url('~@/assets/map_images/szswmzdlx-bottom-right-hover.png')
          no-repeat;
        background-size: 100% 100%;
      }

      .circle-div {
        position: absolute;
        left: 50%;
        top: 50%;
        margin-left: -42px;
        margin-top: -42px;
        width: 84px;
        height: 84px;
        border-radius: 50%;
        text-align: center;
        background-image: linear-gradient(35deg, #00577f 0%, #02c9c8 100%);
        padding: 20px 0;
        letter-spacing: 0px;
        color: #ffffff;

        .num {
          font-size: 28px;
          font-family: font_num;
        }

        .txt {
          font-size: 13px;
          line-height: 24px;
        }
      }
    }

    .right-panel3-item {
      width: 100%;
      height: 28px;
      margin-top: 12px;
      line-height: 28px;
      padding: 0 20px;
      background: rgba(22, 53, 125, 0.8);
      border: solid 1px #3b90f3;
      font-size: 16px;
      color: #23c3fe;

      &:hover {
        box-shadow: 0 0 8px 0 #08e5ee;
      }

      .left-span {
      }

      .right-span {
        float: right;
        color: #dfe110;
      }
    }

    .btn-div {
      margin: 25px auto 0;
      text-align: center;

      a {
        display: inline-block;
        height: 30px;
        line-height: 28px;
        margin-right: 15px;
        border-radius: 5px;
        border: solid 1px #07bdc3;
        padding: 0 15px;
        font-size: 12px;

        &:hover {
          border: #72c7d5 solid 2px;
          margin-top: -1px;
        }
      }

      a:nth-child(3) {
        margin-right: 0;
      }
    }
  }

  .hometitle {
    border-left: #72c7d5 solid 3px;
    padding-left: 15px;
    margin-bottom: 15px;
  }

  .homebg {
    background: linear-gradient(90deg, #9305ff, #02b7cd);
    height: 80px;
    padding: 10px;
    text-align: center;
  }

  .homesz {
    margin: 10px;
  }

  .homebglt {
    color: #3ab9ee;
    font-size: 30px;
  }

  .homesmlt {
    color: #3ab9ee;
  }

  .homezxdiv {
    padding: 33px 0 0;
  }

  .homezxdiv li {
    padding: 5px 0;
  }

  .homebnt {
    border-radius: 7px;
    border: #72c7d5 solid 1px;
    color: #fff;
    padding: 10px 20px;
  }

  .homecenter {
    position: relative;
    height: 100%;
    width: 100%;

    .btn-box {
      position: absolute;
      bottom: 50px;
      width: 100%;
      text-align: center;

      .vab-btn1 {
        background: rgba(22, 53, 125, 0.8) !important;
      }
    }

    .footer-div1 {
      width: 238px;
      height: 44px;
      line-height: 42px;
      background: url('~@/assets/map_images/001.png') no-repeat;
      background-size: 100% 100%;
      font-size: 14px;
      color: #fff;
      text-align: left;
      padding-left: 12px;

      p {
        float: right;
        margin-right: 30px;
        color: #f8f505;
        font-size: 28px;
        font-weight: bold;
        font-family: font_num;

        span {
          display: inline-block;
          text-indent: 4px;
          font-size: 14px;
        }
      }
    }
  }

  .homecenter .el-col {
    text-align: center;
  }

  .homepage .grid-content {
    border-radius: 4px;
  }

  .homepage .el-row {
    margin-bottom: 20px;

    &:last-child {
      margin-bottom: 0;
    }
  }

  .index-dsjgl {
    overflow: hidden;

    .tab-div {
      float: left;

      .left-panel1-item {
        height: 28px;
        line-height: 28px;
        padding: 0 20px 0 10px;
        background: url('~@/assets/map_images/ydsfc-1.png') no-repeat;
        background-size: 100% 100%;
        margin-right: 2px;

        &.active {
          border: none;
          background: url('~@/assets/map_images/ydsfc-1-active.png') no-repeat;
          background-size: 100% 100%;
        }
      }

      .item-detail1 {
        position: absolute;
        left: 0;
        right: 0;
        top: 35px;
        height: 272px;
        border: 1px solid #106ae1;
      }
    }
  }

  .right-panel-item {
    background: url('~@/assets/map_images/swmzdsffb.png') no-repeat;
    background-size: 100% 100%;
  }

  .right-panel1-item {
    width: 100%;
    height: 218px;

    .img-div {
      position: relative;
      width: 135px;
      height: 176px;
      float: left;

      .data-img {
        width: 100%;
        // height: 100%;
      }

      .img-data {
        position: absolute;
        left: 0;
        top: 0;
        right: 0;
        text-align: center;
        font-size: 14px;
        line-height: 48px;
        color: #fefbf9;
        z-index: 100;

        p:nth-child(4) {
          line-height: 40px;
        }
      }
    }

    .data-div {
      height: 176px;
      float: right;
      text-align: right;

      .data-item {
        font-size: 14px;
        line-height: 48px;
        letter-spacing: 0px;
        color: #ffffff;
        position: relative;
        z-index: 10;

        .data-num {
          color: #0599ff;
          font-weight: bold;
        }

        .data-line {
          position: absolute;
          width: 63px;
          left: -53px;
          top: 11px;
          display: inline-block;
          border: 1px dashed #0599ff;
        }
      }

      .data-item:nth-child(2) {
        .data-line {
          width: 34px;
          left: -40px;
          top: 25px;
        }

        .data-num {
          color: #31d5de;
        }
      }

      .data-item:nth-child(3) {
        .data-line {
          width: 24px;
          left: -31px;
          top: 21px;
        }

        .data-num {
          color: #f0da3f;
        }
      }

      .data-item:nth-child(4) {
        line-height: 40px;

        .data-line {
          top: 27px;
          width: 78px;
          left: -21px;
        }

        .data-num {
          color: #f08c4c;
        }
      }

      .data-item:nth-child(5) {
        line-height: 40px;

        .data-line {
          width: 57px;
          left: -11px;
          top: 32px;
        }

        .data-num {
          color: #f08c4c;
        }
      }
    }
  }

  .cszadsj-kind {
    width: 80%;
    text-align: center;
    border: 1px solid #02b5cb;
    margin: 4px 0;

    .kind-name {
      border-bottom: 1px solid #02ccd7;
      background-color: #055884;
    }

    .kind-num {
      height: 30px;
      line-height: 30px;
      color: #27b3eb;
    }
  }

  .ztcl-car-icon {
    width: 70px;
    height: 80px;
    border-left: 1px solid #3f6e80;
    border-right: 1px solid #3f6e80;
    margin: 0 auto;

    img {
      width: 100%;
      height: 100%;
    }
  }

  .ztcl-car-content {
    text-align: center;
  }

  .ztcl-car-name {
    width: 100%;
    text-align: center;
    margin-top: -20px;
    margin-bottom: 30px;
  }

  .ztcl-car-num {
    width: 100%;
    text-align: center;
    margin: 20px 0 0;
    color: #f23369;
    font-size: 24px;
  }
</style>
