<template>
  <el-dialog
    :visible.sync="dialogTableVisible"
    :before-close="closeTk"
    style="overflow: hidden"
    custom-class="vab-dialog2"
  >
    <div
      style="
        width: 100%;
        font-size: 22px;
        line-height: 30px;
        text-align: center;
        color: #fefefe;
        font-weight: blod;
        margin-top: -8px;
        margin-bottom: 10px;
      "
    >
      文化路墨水河桥西头
    </div>
    <div class="index-video">
      <h4 style="margin-left: 15px; line-height: 30px">
        ·点位坐标:(116.35358, 39.95599)
      </h4>
      <div
        class="index-video-video"
        style="
          width: 1288px;
          display: flex;
          justify-content: space-between;
          margin: 0 auto;
        "
      >
        <div style="width: 61%">
          <video
            style="width: 100%; border: 1px solid #01efef"
            autoplay="autoplay"
            loop="loop"
            muted
            :src="videoSrc"
          ></video>
          <div
            style="
              width: 100%;
              height: 134px;
              border: 1px solid #01efef;
              display: flex;
              justify-content: space-around;
              margin-top: 15px;
              overflow: hidden;
            "
          >
            <img
              v-for="(item, index) in videoImg"
              :key="index"
              style="height: 130px"
              :src="item.image"
            />
          </div>
          <h4>
            <span style="float: left">
              ·原始视频流:{{ vidNum }}Mb/s&nbsp;&nbsp;&nbsp;·压缩流:{{
                cedNum
              }}Mb/s&nbsp;&nbsp;&nbsp;视频压缩:{{
                ((cedNum / vidNum) * 100).toFixed(2)
              }}%
            </span>
            <span style="float: right">
              ·结构化特征:{{ jghtz }}kb/s&nbsp;&nbsp;&nbsp;·专用特征:{{
                sltz
              }}kb/s&nbsp;&nbsp;&nbsp;·通用特征:{{ sltz }}kb/s
            </span>
          </h4>
          <!-- <p style="color: #fff;width: 340px;height: 30px; line-height: 30px;display: inline-block;">点位坐标:(116.35358, 39.95599)&nbsp;&nbsp;&nbsp;·视频流:{{ vidNum }}Mbps</p><p style="color: #fff;line-height: 32px; width:130px;display: inline-block;">·特征流:{{ cedNum }}Kbps</p> -->
          <!-- <div style="width: 150px;display: inline-block;"><span style="margin-left: 10px;color: #fff;">压缩比:<span style="color: #fff;width: 90px;display: inline-block;">{{ (vidNum * 1024 / cedNum).toFixed(2) }}%</span></span></div> -->
        </div>
        <div style="width: 37%">
          <div style="width: 100%; height: 606px; border: none">
            <!-- 右侧内容 -->
            <div
              style="
                font-size: 16px;
                font-weight: normal;
                font-stretch: normal;
                line-height: 32px;
                letter-spacing: 0px;
                color: #fefefe;
              "
            >
              算法配置：
            </div>
            <div>
              <el-switch
                v-for="(item, index) in switchText"
                :key="index"
                v-model="switchValue[index]"
                :disabled="index > 3 ? true : false"
                active-color="#437af9"
                inactive-color="#cdcdcf"
                :inactive-text="item"
                @change="seitchChange(index)"
              ></el-switch>
              <div
                style="
                  font-size: 16px;
                  font-weight: normal;
                  font-stretch: normal;
                  line-height: 32px;
                  letter-spacing: 0px;
                  color: #fefefe;
                  margin-top: 16px;
                "
              >
                视网膜终端使用情况：
              </div>
              <!--  -->
              <el-card>
                <el-row>
                  <el-col :span="12" style="position: relative">
                    <div style="width: 250px; height: 160px">
                      <vab-chart
                        auto-resize
                        :option="chPies"
                        style="width: 250px; height: 160px"
                      />
                    </div>
                    <span style="position: absolute; top: 58px; left: 95px">
                      <div
                        style="
                          width: 60px;
                          text-align: center;
                          font-size: 18px;
                          font-weight: normal;
                          font-stretch: normal;
                          line-height: 20px;
                          letter-spacing: 0px;
                          color: #437af9;
                        "
                      >
                        4T
                      </div>
                      <div
                        style="
                          width: 60px;
                          text-align: center;
                          font-size: 14px;
                          font-weight: normal;
                          font-stretch: normal;
                          line-height: 20px;
                          letter-spacing: 0px;
                          color: #f5f7fa;
                          opacity: 0.53;
                        "
                      >
                        总算力
                      </div>
                    </span>
                  </el-col>
                  <el-col :span="12" style="position: relative">
                    <template v-for="(item, index) in vision">
                      <div
                        v-if="item.show"
                        :key="index"
                        style="
                          color: #fff;
                          text-align: right;
                          line-height: 20px;
                        "
                      >
                        {{ item.val }}
                      </div>
                    </template>
                  </el-col>
                </el-row>
              </el-card>
              <div
                style="
                  font-size: 16px;
                  font-weight: normal;
                  font-stretch: normal;
                  line-height: 32px;
                  letter-spacing: 0px;
                  color: #fefefe;
                "
              >
                该路今日解析数据量：24201
              </div>
              <div>
                <vab-chart
                  auto-resize
                  :option="categorys"
                  style="width: 100%; height: 150px"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </el-dialog>
  <!-- lzg   10.22更改 -->
</template>
<script>
  let times, powers
  let nums = 0
  let tanTime = Date.parse(new Date())
  setInterval(() => {
    tanTime -= tanTime - 1000
  }, 1000)
  import request from '@/utils/request'
  export default {
    name: 'TanKuang',
    components: {},
    data() {
      return {
        value1: true,
        dialogTableVisible: false,
        videoSrc: '',
        timeData: [
          965, 457, 1554, 1835, 3625, 3457, 3526, 3253, 3625, 3214, 3326, 2256,
        ],
        //   饼状图
        chPies: {
          dataset: {
            source: [],
          },
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(236, 237, 235, 0)',
            },
          },
          color: ['#496183', '#ffc805'],
          tooltip: {
            trigger: 'item',
            formatter: '',
          },
          grid: {
            left: '80px',
            top: '-50px',
            right: '80px',
            containLabel: true,
          },
          xAxis: [
            {
              show: false,
            },
            {
              show: false,
            },
          ],
          yAxis: {
            type: 'category',
            inverse: true,
            show: false,
          },
          series: [
            {
              tooltip: {
                trigger: 'item',
                formatter: '{b}\n{d}%',
              },
              type: 'pie',
              radius: ['40%', '30%'],
              avoidLabelOverlap: false,
              label: {
                normal: {
                  formatter: '{c}',
                  show: true,
                },
                data: {},
              },
              encode: {
                itemName: 'product',
                value: 'nums',
              },
            },
          ],
        },
        // 曲线图
        categorys: {
          tooltip: {
            trigger: 'axis',
          },
          //图例
          legend: {
            color: ['#F58080', '#47D8BE'],
            data: ['历史均值', '实时'],
            textStyle: {
              color: '#fff',
            },
          },
          //网格
          grid: {
            top: 'middle',
            left: '3%',
            right: '4%',
            bottom: '3%',
            height: '80%',
            containLabel: true,
          },
          xAxis: {
            type: 'category',
            color: '#03E2DA',
            data: [
              '0:00',
              '2:00',
              '4:00',
              '6:00',
              '8:00',
              '10:00',
              '12:00',
              '14:00',
              '16:00',
              '18:00',
              '20:00',
              '22:00',
              '24:00',
            ],
            axisLabel: {
              interval: 1,
              color: '#03E2DA',
            },
            axisLine: {
              lineStyle: {
                color: '#03E2DA',
              },
            },
            smooth: true,
          },
          yAxis: {
            type: 'value',
            min: 0,
            max: 4000,
            color: '#03E2DA',
            axisLine: {
              lineStyle: {
                color: '#03E2DA',
              },
            },
            splitLine: {
              show: false,
            },
            nameTextStyle: {
              color: '#999',
            },
            axisLabel: {
              color: '#03E2DA',
              textStyle: {
                fontSize: 12,
              },
            },
          },
          series: [
            {
              name: '',
              type: 'line',
              showSymbol: true,
              data: [965, 457, 2054, 1835, 3625, 3457],
              lineStyle: {
                normal: {
                  width: 2,
                  color: '#ec6b1b',
                  shadowColor: 'rgba(245,128,128, 0.5)',
                  shadowBlur: 5,
                  shadowOffsetY: 7,
                },
              },
              itemStyle: {
                normal: {
                  color: '#ec6b1b',
                  borderWidth: 3,
                  borderColor: '#ec6b1b',
                },
              },
            },
          ],
        },
        flowsChange: null,
        vidNum: 3.8,
        cedNum: 3.0,
        jghtz: 427,
        sltz: 1.5,
        tytz: 6,
        switchText: [
          '人脸解析',
          '行人解析',
          '非机动车解析',
          '机动车解析',
          '断面流量',
          '拥堵检测',
          '出口道溢出检测',
          '事故检测',
        ],
        vision: [
          { val: '人脸解析版本号：v2.1', show: false },
          { val: '行人解析版本号：v3.1', show: true },
          { val: '非机动车解析版本号：v4.3', show: true },
          { val: '机动车解析版本号：v3.6', show: true },
        ],
        switchValue: [false, true, true, true, false, false, false, false],
        videoImg: [],
        powerNum: 0,
      }
    },
    created() {},
    beforeDestroy() {
      nums = 0
      clearInterval(this.flowsChange)
    },
    methods: {
      //  switch change更改
      seitchChange(index) {
        this.vision[index].show = !this.vision[index].show
        const aw = this.videoImg
        if (!this.switchValue[0]) {
          // face
          this.videoImg = aw.filter((res) => {
            return res.type != 'face'
          })
        } else if (!this.switchValue[1]) {
          // pedestrian
          this.videoImg = aw.filter((res) => {
            return res.type != 'pedestrian'
          })
        } else if (!this.switchValue[2]) {
          // nonVehicle
          this.videoImg = aw.filter((res) => {
            return res.type != 'nonVehicle'
          })
        } else if (!this.switchValue[3]) {
          // vehicle
          this.videoImg = aw.filter((res) => {
            return res.type != 'vehicle'
          })
        }
        console.log(this.videoImg)
        this.configuration()
      },
      //  组件打开
      openTk() {
        this.getVideo()
        this.dialogTableVisible = true
        this.changeFlows()
        this.power()
        this.powerNum = Math.round(Math.random() * 4 * 100) / 100
        this.chPies.dataset.source = [
          ['product', 'nums'],
          ['剩余计算', this.powerNum],
          ['使用计算', Math.round((4 - this.powerNum) * 100) / 100],
        ]
        // this.chPies.series[0].label.data = [[{name: this.powerNum,value: '剩余计算'}],[{name: '使用计算', value: 4 - this.powerNum}]]
        //今日解析数据时间
        var myDate = new Date()
        var a = Math.floor(Math.round(myDate.getHours()) / 2)
        this.categorys.series[0].data = this.timeData.slice(0, a + 1)
      },
      //  动态生成计算力
      power() {
        powers = setInterval(() => {
          this.powerNum = Number((Math.random() * 4).toFixed(2))
          this.chPies.dataset.source = [
            ['product', 'nums'],
            ['剩余计算', this.powerNum],
            ['使用计算', Math.round((4 - this.powerNum) * 100) / 100],
          ]
        }, 1000)
      },
      //动态视频流量
      changeFlows() {
        clearInterval(this.flowsChange)
        this.flowsChange = null
        this.flowsChange = setInterval(() => {
          this.jghtz = +(Math.random() * 200).toFixed(0) + 400
          this.sltz = (+(Math.random() * 0.6).toFixed(2) + 1).toFixed(2)
          this.tytz = +(Math.random() * 2).toFixed(0) + 5
          const ac = (+Math.random().toFixed(2) + 3).toFixed(2)
          if (ac > 1) {
            this.vidNum = ac
          } else {
            this.vidNum = 1
          }
          const ab = (+(Math.random() * 0.9).toFixed(2) + 2).toFixed(2)
          if (ab > 1) {
            this.cedNum = ab
          } else {
            this.cedNum = 1
          }
        }, 1000)
      },
      //  组件关闭
      closeTk() {
        this.dialogTableVisible = false
        clearInterval(this.flowsChange)
        clearInterval(powers)
        clearInterval(times)
        this.powerNum = 0
      },
      //   视频接口
      getVideo() {
        request({
          url: '/algorithm/getVideo',
          method: 'post',
        })
          .then((res) => {
            this.videoSrc = res.url
            this.configuration()
            times = setInterval(() => {
              nums += 1
              this.search(nums)
            }, 1000)
          })
          .catch((res) => {
            console.log(res)
          })
      },
      //  数据保存
      configuration() {
        request({
          url: '/algorithm/configuration',
          method: 'post',
          data: {
            ids: JSON.stringify(this.switchValue),
          },
        })
          .then((res) => {
            console.log(res)
          })
          .catch((res) => {
            console.log(res)
          })
      },
      //  图片推送
      search(val) {
        request({
          url: '/algorithm/search',
          method: 'post',
          data: {
            begin: (val - 1) * 1000,
            end: val * 1000,
          },
        })
          .then((res) => {
            if (res.images.length > 0) {
              res.images.forEach((val) => {
                if (this.videoImg.length >= 6) {
                  this.videoImg.shift()
                }
                this.videoImg.push(val)
              })
            }
          })
          .catch(() => {
            clearInterval(times)
          })
      },
    },
  }
</script>
