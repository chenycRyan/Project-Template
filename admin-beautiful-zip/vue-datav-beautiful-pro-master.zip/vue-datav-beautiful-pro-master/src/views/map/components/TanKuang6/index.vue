<template>
  <el-dialog
    :visible.sync="dialogTableVisible"
    custom-class="vab-dialog3"
    :before-close="closeTk"
  >
    <div class="index-video3-top"></div>
    <div class="index-video3">
      <div class="index-video-video3">
        <div class="index-video-top3">
          <h3>滨海大道卡口(116.35358, 39.95599)</h3>
          <!-- <p>·视频流:{{ flows }}Mbps</p> -->
          <video autoplay="autoplay" loop="loop" muted :src="videoSrc"></video>
        </div>
        <div class="index-video-down3">
          <div
            style="
              font-size: 16px;
              font-weight: 600;
              font-stretch: normal;
              line-height: 28px;
              letter-spacing: 0px;
              color: #fefefe;
            "
          >
            算法配置：
          </div>
          <div>
            <el-switch
              v-for="(item, index) in switchText"
              :key="index"
              v-model="switchValue[index]"
              active-color="#437af9"
              inactive-color="#cdcdcf"
              :inactive-text="item"
              @change="seitchChange"
            ></el-switch>
            <div
              style="
                font-size: 16px;
                font-weight: 600;
                font-stretch: normal;
                line-height: 28px;
                margin-top: 10px;
                letter-spacing: 0px;
                color: #fefefe;
              "
            >
              拥堵状况：
              <span style="color: red">拥堵</span>
            </div>
            <div
              style="
                width: 70%;
                display: flex;
                justify-content: space-between;
                margin-left: 9%;
              "
            >
              <div>
                <p style="color: #00cbd6">
                  <span class="number">{{ line }}</span>
                  米
                </p>
                <p class="numberText">排队长度</p>
              </div>
              <div>
                <p style="color: #00cbd6">
                  <span class="number">{{ speed }}</span>
                  千米/时
                </p>
                <p class="numberText">过车速度</p>
              </div>
              <div>
                <p style="color: #00cbd6">
                  <span class="number">{{ allCarNum }}</span>
                  辆
                </p>
                <p class="numberText">排队车辆</p>
              </div>
            </div>
            <div
              style="
                font-size: 16px;
                font-weight: 600;
                font-stretch: normal;
                line-height: 28px;
                margin-top: 10px;
                letter-spacing: 0px;
                color: #fefefe;
              "
            >
              累计过车辆：{{ leijiCar }}辆
            </div>
            <vab-chart
              auto-resize
              ref="speed"
              :option="speedChart"
              style="width: 480px; height: 150px"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="index-video3-bottom"></div>
  </el-dialog>
</template>
<script>
  export default {
    name: 'TanKuang5',
    components: {},
    data() {
      return {
        dialogTableVisible: false,
        videoSrc: 'video/paiduichangdu.mp4',
        flows: 3,
        line: 10,
        carNum1: 2,
        carNum2: 2,
        carNum3: 2,
        speed: 2,
        allCarNum: 100,
        leijiCar: 102,
        flowsChange: null,
        SpeedChartTnt: null,
        switchText: [
          '人脸检测',
          '行人检测',
          '非机动车检测',
          '机动车检测',
          '断面流量',
          '拥堵检测',
          '出口道溢出检测',
          '事故检测',
        ],
        switchValue: [false, false, false, false, false, true, false, false],
        speedChart: {
          tooltip: {
            trigger: 'axis',
            axisPointer: {
              type: 'line',
              lineStyle: {
                color: '#169ef6',
              },
              label: {
                backgroundColor: '#6a7985', //水平线上提示框颜色
                formatter: '{value}',
              },
            },
            backgroundColor: '#011a44',
            borderColor: '#169ef6',
            borderWidth: 1,
            textStyle: {
              color: '#b2e1ff',
              fontSize: '14px',
            },
            padding: 10,
          },
          grid: {
            top: '8%',
            left: '8%',
            right: '8%',
            bottom: '12%',
            containLabel: true,
          },
          xAxis: [
            {
              type: 'category',
              boundaryGap: false,
              axisLine: {
                //坐标轴轴线相关设置。数学上的x轴
                show: true,
                lineStyle: {
                  color: '#233e64',
                },
              },
              axisLabel: {
                //坐标轴刻度标签的相关设置
                textStyle: {
                  color: '#fff',
                  margin: 15,
                },
              },
              axisTick: { show: false },
              data: [
                '6:00',
                '8:00',
                '10:00',
                '12:00',
                '14:00',
                '16:00',
                '18:00',
                '20:00',
              ],
            },
          ],
          yAxis: [
            {
              type: 'value',
              min: 0,
              max: 600,
              splitNumber: 3,
              splitLine: {
                show: true,
                lineStyle: {
                  color: '#39435d',
                },
              },
              axisLine: { show: false },
              axisLabel: {
                margin: 20,
                textStyle: {
                  color: '#32b7f9',
                },
              },
              axisTick: { show: false },
            },
          ],
          series: [
            {
              name: '异常流量',
              type: 'line',
              smooth: true, //是否平滑曲线显示
              // 			symbol:'circle',  // 默认是空心圆（中间是白色的），改成实心圆
              symbolSize: 0,

              lineStyle: {
                normal: {
                  color: {
                    type: 'linear',

                    colorStops: [
                      {
                        offset: 0,
                        color: '#003BC9', // 0% 处的颜色
                      },
                      {
                        offset: 1,
                        color: '#02C5C8', // 100% 处的颜色
                      },
                    ],
                    globalCoord: false, // 缺省为 false
                  }, // 线条颜色
                },
              },
              areaStyle: {
                //区域填充样式
                color: '#081c51',
                // normal: {
                //   //线性渐变，前4个参数分别是x0,y0,x2,y2(范围0~1);相当于图形包围盒中的百分比。如果最后一个参数是‘true’，则该四个值是绝对像素位置。
                //   // color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{ offset: 0, color: 'rgba(61,234,255, 0.9)' }, { offset: 0.7, color: 'rgba(61,234,255, 0)' }], false),

                //   shadowColor: '081c51', //阴影颜色
                //   // shadowBlur: 20 //shadowBlur设图形阴影的模糊大小。配合shadowColor,shadowOffsetX/Y, 设置图形的阴影效果。
                // }
              },
              data: [300, 200, 484, 335, 260, 392, 308, 300],
            },
          ],
        },
      }
    },
    created() {},
    beforeDestroy() {
      clearInterval(this.flowsChange)
    },
    methods: {
      //  switch change更改
      seitchChange() {
        console.log(this.switchValue)
      },
      openTk() {
        this.dialogTableVisible = true
        this.changeFlows()
        // this.changeSpeedChart();
      },
      //图表轮换
      changeSpeedChart() {
        const that = this
        var app = {
          currentIndex: -1,
        }
        const myCharts = this.$refs['speed']
        that.SpeedChartTnt = null
        that.SpeedChartTnt = setInterval(() => {
          var dataLen = that.speedChart.series[0].data.length
          // 取消之前高亮的图形
          myCharts.dispatchAction({
            type: 'downplay',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          app.currentIndex = (app.currentIndex + 1) % dataLen
          console.log(app.currentIndex)
          // 高亮当前图形
          myCharts.dispatchAction({
            type: 'highlight',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          // 显示 tooltip
          myCharts.dispatchAction({
            type: 'showTip',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
        }, 1000)
      },
      //动态视频流量
      changeFlows() {
        clearInterval(this.flowsChange)
        const that = this
        that.flowsChange = null
        that.flowsChange = setInterval(() => {
          that.flows = +(Math.random() * 0.2).toFixed(2) + 3
          this.line = +(Math.random() * 3).toFixed(0) + 8
          this.speed = +(Math.random() * 2).toFixed(0) + 1
          this.allCarNum = +(Math.random() * 13).toFixed(0) + 90
          this.leijiCar += +(Math.random() * 8).toFixed(0)
        }, 1000)
        // that.flowsChange = setInterval(() => {
        //   that.flows = +(Math.random() * 0.2).toFixed(2) + 3;

        //   // this.carNum1 = +(Math.random() * 4).toFixed(0);
        //   // this.carNum2 = +(Math.random() * 4).toFixed(0);
        //   // this.carNum3 = +(Math.random() * 4).toFixed(0);
        //   // this.speed1 = 18 - +(Math.random() * 4).toFixed(0);
        //   // this.speed2 = 18 - +(Math.random() * 4).toFixed(0);
        //   // this.speed3 = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[0].data = [+(Math.random() * 4).toFixed(0), +(Math.random() * 4).toFixed(0), +(Math.random() * 4).toFixed(0)];
        //   // that.speedChart.series[0].data[1] = +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[0].data[2] = +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data[0] = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data[1] = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data = [18 - +(Math.random() * 4).toFixed(0), 18 - +(Math.random() * 4).toFixed(0), 18 - +(Math.random() * 4).toFixed(0)];
        // }, 2000);
      },
      closeTk() {
        this.dialogTableVisible = false
        clearInterval(this.flowsChange)
        clearInterval(this.SpeedChartTnt)
      },
    },
  }
</script>
