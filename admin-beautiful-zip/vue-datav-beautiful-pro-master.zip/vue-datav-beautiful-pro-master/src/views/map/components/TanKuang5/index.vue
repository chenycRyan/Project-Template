<template>
  <el-dialog
    :visible.sync="dialogTableVisible"
    custom-class="vab-dialog3"
    :before-close="closeTk"
  >
    <div class="index-video3-top"></div>
    <div class="index-video3">
      <h2>辽阳路龙门架监控</h2>
      <div class="index-video-video3">
        <div class="index-video-top3">
          <div class="hengxian1"></div>
          <div class="hengxian2"></div>
          <div class="hengxian3"></div>
          <!-- <p>·视频流:{{ flows }}Mbps</p> -->
          <video
            autoplay="autoplay"
            loop="loop"
            muted
            :src="videoSrc"
            style="height: 396px !important"
          ></video>
          <h4>
            点位坐标:(116.35358, 39.95599)
            <span style="float: right">
              ·视频流:{{ flows }}Mbps&nbsp;&nbsp;&nbsp;·特征流:{{
                kbps
              }}/kbps&nbsp;&nbsp;&nbsp;压缩比:{{
                ((flows * 1024) / kbps).toFixed(2)
              }}%
            </span>
          </h4>
        </div>
        <div class="index-video-down3">
          <div
            style="
              font-size: 16px;
              font-weight: 600;
              font-stretch: normal;
              line-height: 28px;
              letter-spacing: 0px;
              color: #fefefe;
            "
          >
            算法配置：
          </div>
          <div>
            <el-switch
              v-for="(item, index) in switchText"
              :key="index"
              v-model="switchValue[index]"
              active-color="#437af9"
              inactive-color="#cdcdcf"
              :inactive-text="item"
              @change="seitchChange"
            ></el-switch>
            <div
              style="
                font-size: 16px;
                font-weight: 600;
                font-stretch: normal;
                line-height: 28px;
                margin-top: 10px;
                letter-spacing: 0px;
                color: #fefefe;
              "
            >
              交通参数：
              <!-- <span style="color: red;">断面流量</span> -->
            </div>
            <div
              style="
                width: 70%;
                display: flex;
                justify-content: space-between;
                margin-left: 9%;
              "
            >
              <div>
                <p style="color: #00cbd6">
                  <span class="number">{{ line }}</span>
                  辆/分钟
                </p>
                <p class="numberText">平均过车</p>
              </div>
              <div>
                <p style="color: #00cbd6">
                  <span class="number">{{ speed }}</span>
                  千米/时
                </p>
                <p class="numberText">平均车速</p>
              </div>
              <div>
                <p style="color: #00cbd6">
                  <span class="number">
                    {{ this.allCarNum >= 996 ? 999 : allCarNum }}
                  </span>
                  辆
                </p>
                <p class="numberText">累计过车</p>
              </div>
            </div>
            <div
              style="
                font-size: 16px;
                font-weight: 600;
                font-stretch: normal;
                line-height: 28px;
                margin-top: 10px;
                letter-spacing: 0px;
                color: #fefefe;
              "
            >
              断面流量:
            </div>
            <vab-chart
              auto-resize
              ref="speed"
              :option="speedChart"
              style="width: 480px; height: 200px"
            />
          </div>
        </div>
      </div>
    </div>
    <div class="index-video3-bottom"></div>
  </el-dialog>
</template>
<script>
  import * as echarts from 'echarts'

  export default {
    name: 'TanKuang5',
    components: {},
    data() {
      return {
        dialogTableVisible: false,
        videoSrc: 'video/duanmianliuliang.mp4',
        flows: 3,
        kbps: 1,
        line: 77,
        carNum1: 2,
        carNum2: 2,
        carNum3: 2,
        speed: 50,
        allCarNum: 301,
        leijiCar: 102,
        flowsChange: null,
        SpeedChartTnt: null,
        switchText: [
          '人脸检测',
          '行人检测',
          '非机动车检测',
          '机动车检测',
          '断面流量',
          '拥堵检测',
          '出口道溢出检测',
          '事故检测',
        ],
        switchValue: [false, false, false, false, true, false, false, false],
        speedChart: {
          title: {
            text: '',
            x: 'center',
            y: 0,
            textStyle: {
              color: '#B4B4B4',
              fontSize: 16,
              fontWeight: 'normal',
            },
          },
          tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(255,255,255,0.1)',
            axisPointer: {
              type: 'shadow',
              label: {
                show: true,
                backgroundColor: '#7B7DDC',
              },
            },
          },
          legend: {
            // data: ['平均车速', '平均过车数'],
            textStyle: {
              color: '#B4B4B4',
            },
            top: '0%',
          },
          grid: {
            x: '12%',
            width: '75%',
            y: '11%',
          },
          xAxis: {
            data: ['断面一', '断面二', '断面三'],
            axisLine: {
              lineStyle: {
                color: '#B4B4B4',
              },
            },
            axisTick: {
              show: false,
            },
          },
          yAxis: [
            {
              // scale: true,
              // name: '平均车速(km/h)',
              axisLine: {
                show: false,
                lineStyle: {
                  color: '#2DA3E2',
                },
              },
              min: 0,
              max: 25,
              axisLabel: {
                formatter: '{value} ',
              },
              splitLine: {
                lineStyle: {
                  color: '#39435d',
                },
              },
            },
            {
              // scale: true,
              // name: '平均过车数(辆/秒)',
              min: 0,
              max: 5,
              axisLine: {
                show: false,
                lineStyle: {
                  color: '#ED9C2B',
                },
              },

              axisLabel: {
                formatter: '{value} ',
              },
              splitLine: {
                lineStyle: {
                  color: '#39435d',
                },
              },
            },
          ],

          series: [
            {
              name: '平均过车数',
              type: 'line',
              showAllSymbol: true,
              symbol: 'emptyCircle',
              symbolSize: 8,
              yAxisIndex: 1,
              itemStyle: {
                normal: {
                  color: '#DC932C',
                },
              },
              data: [2, 3, 1],
              areaStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(
                    0,
                    0,
                    0,
                    1,
                    [
                      {
                        offset: 0,
                        color: '#4B3D31',
                      },
                      {
                        offset: 1,
                        color: '#202334',
                      },
                    ],
                    false
                  ),
                },
              },
            },
            {
              name: '平均车速',
              type: 'bar',
              barWidth: 30,
              itemStyle: {
                normal: {
                  color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [
                    { offset: 0, color: '#17B0EF' },
                    { offset: 1, color: '#00FFF8' },
                  ]),
                },
              },
              data: [17, 19, 18],
            },
          ],
        },
      }
    },
    created() {},
    beforeDestroy() {
      clearInterval(this.flowsChange)
    },
    methods: {
      //  switch change更改
      seitchChange() {
        console.log(this.switchValue)
      },
      openTk() {
        this.dialogTableVisible = true
        this.changeFlows()
        this.changeSpeedChart()
      },
      //图表轮换
      changeSpeedChart() {
        const that = this
        var app = {
          currentIndex: -1,
        }
        var myCharts
        this.$nextTick(() => {
          myCharts = this.$refs['speed']
        })
        that.SpeedChartTnt = null
        that.SpeedChartTnt = setInterval(() => {
          var dataLen = that.speedChart.series[0].data.length
          // 取消之前高亮的图形
          myCharts.dispatchAction({
            type: 'downplay',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          app.currentIndex = (app.currentIndex + 1) % dataLen
          // 高亮当前图形
          myCharts.dispatchAction({
            type: 'highlight',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
          // 显示 tooltip
          myCharts.dispatchAction({
            type: 'showTip',
            seriesIndex: 0,
            dataIndex: app.currentIndex,
          })
        }, 2000)
      },
      //动态视频流量
      changeFlows() {
        clearInterval(this.flowsChange)
        const that = this
        that.flowsChange = null
        that.flowsChange = setInterval(() => {
          that.flows = +(Math.random() * 0.2).toFixed(2) + 3
          that.kbps = (Math.round(Math.random() * 3 * 100) / 100 + 1).toFixed(2)
          this.line = +(Math.random() * 20).toFixed(0) + 70
          this.speed = +(Math.random() * 15).toFixed(0) + 45
          this.allCarNum += +(Math.random() * 3).toFixed(0)
          this.leijiCar += +(Math.random() * 8).toFixed(0)
          that.speedChart.series[0].data = [
            +(Math.random() * 4).toFixed(0),
            +(Math.random() * 4).toFixed(0),
            +(Math.random() * 4).toFixed(0),
          ]
          that.speedChart.series[1].data = [
            18 - +(Math.random() * 4).toFixed(0),
            18 - +(Math.random() * 4).toFixed(0),
            18 - +(Math.random() * 4).toFixed(0),
          ]
        }, 1000)
        // that.flowsChange = setInterval(() => {
        //   that.flows = +(Math.random() * 0.2).toFixed(2) + 3;

        //   // this.carNum1 = +(Math.random() * 4).toFixed(0);
        //   // this.carNum2 = +(Math.random() * 4).toFixed(0);
        //   // this.carNum3 = +(Math.random() * 4).toFixed(0);
        //   // this.speed1 = 18 - +(Math.random() * 4).toFixed(0);
        //   // this.speed2 = 18 - +(Math.random() * 4).toFixed(0);
        //   // this.speed3 = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[0].data = [+(Math.random() * 4).toFixed(0), +(Math.random() * 4).toFixed(0), +(Math.random() * 4).toFixed(0)];
        //   // that.speedChart.series[0].data[1] = +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[0].data[2] = +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data[0] = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data[1] = 18 - +(Math.random() * 4).toFixed(0);
        //   // that.speedChart.series[1].data = [18 - +(Math.random() * 4).toFixed(0), 18 - +(Math.random() * 4).toFixed(0), 18 - +(Math.random() * 4).toFixed(0)];
        // }, 2000);
      },
      closeTk() {
        this.dialogTableVisible = false
        clearInterval(this.flowsChange)
        clearInterval(this.SpeedChartTnt)
        this.flows = 3
        this.kbps = 1
        this.line = 80
        this.speed = 50
        this.allCarNum = 301
        this.leijiCar = 102
      },
    },
  }
</script>
