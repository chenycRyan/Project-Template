import Vue from 'vue'
import VueRouter from 'vue-router'
import Index from '../views/index'
import Home from '../views/home'
import Map from '../views/map'

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    name: 'Root',
    component: Index,
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
  },
  {
    path: '/map',
    name: 'Map',
    component: Map,
  },
]

const router = new VueRouter({
  routes,
})

export default router
