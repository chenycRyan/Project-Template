import * as maptalks from 'maptalks'
import 'maptalks/dist/maptalks.css'

const install = (Vue) => {
  /* 全局map图层 */
  Vue.prototype.$baseMap = () => {
    return {
      center: [116.41348403785, 39.910843952376],
      zoom: 12,
      spatialReference: {
        projection: 'baidu',
      },
      fpsOnInteracting: 0,
      baseLayer: new maptalks.TileLayer('base', {
        urlTemplate:
          'http://online{s}.map.bdimg.com/onlinelabel/?qt=tile&x={x}&y={y}&z={z}&styles=pl&scaler=1&p=1',
        subdomains: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        attribution:
          '&copy; <a target="_blank" href="http://map.baidu.com">百度地图</a>',
        cssFilter: 'sepia(100%) invert(92.5%)',
      }),
    }
  }
}

if (typeof window !== 'undefined' && window.Vue) {
  install(window.Vue)
}

export default {
  install,
}
