import axios from 'axios'
import { Message } from 'element-ui'
import qs from 'qs'
import router from '@/router'
const service = axios.create({
  baseURL: 'mock',
  headers: {
    'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
  },
})
let loadingInstance
service.interceptors.request.use(
  (config) => {
    if (config.data) config.data = qs.stringify(config.data)

    return config
  },
  (error) => {
    return Promise.reject(error)
  }
)

const errorMsg = (message) => {
  return Message({
    message: message,
    type: 'error',
  })
}

service.interceptors.response.use(
  (response) => {
    if (loadingInstance) {
      loadingInstance.close()
    }
    const { data } = response
    const { code, msg } = data
    if (code !== 200 && code !== 0) {
      switch (code) {
        case 402:
          errorMsg(msg || `后端接口${code}异常`)
          break
        case 401:
          router.push({
            path: '/401',
          })
          break
        default:
          errorMsg(msg || `后端接口${code}异常`)
          break
      }
      return Promise.reject({ code, msg } || 'Error')
    } else {
      return data
    }
  },
  (error) => {
    if (loadingInstance) {
      loadingInstance.close()
    }
    let { message } = error
    switch (message) {
      case 'Network Error':
        message = '后端接口连接异常'
        break
      case 'timeout':
        message = '后端接口请求超时'
        break
      case 'Request failed with status code':
        message = '后端接口' + message.substr(message.length - 3) + '异常'
        break
    }
    errorMsg(message || '后端接口未知异常')
    return Promise.reject(error)
  }
)
export default service
