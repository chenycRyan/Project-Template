import axios from 'axios'

export function getList(params) {
  return axios({
    url: 'data/od-xierqi.txt',
    method: 'get',
    params,
  })
}
