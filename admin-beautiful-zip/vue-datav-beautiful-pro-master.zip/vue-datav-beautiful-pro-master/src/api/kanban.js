import request from '@/utils/request'

export function listByPage() {
  return request({
    url: '/panelData/listByPage',
    method: 'get',
  })
}

export function getAllNodeResource() {
  return request({
    url: '/panelData/getAllNodeResource',
    method: 'get',
  })
}

export function algoUseHistory(params) {
  return request({
    url: '/panelData/algoUseHistory',
    method: 'get',
    params,
  })
}
