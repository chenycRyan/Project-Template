import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import VabCount from '@/extra/VabCount'

import vab from '@/utils/vab'
Vue.component('vab-count', VabCount)
import VabChart from '@/extra/VabChart'
Vue.component('vab-chart', VabChart)

Vue.use(vab)
Vue.use(ElementUI)

Vue.config.productionTip = false

/**
 * @description 正式环境默认使用mock，正式项目记得注释后再打包
 */
if (process.env.NODE_ENV === 'production') {
  const { mockXHR } = require('@/utils/static')
  mockXHR()
}

new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app')
