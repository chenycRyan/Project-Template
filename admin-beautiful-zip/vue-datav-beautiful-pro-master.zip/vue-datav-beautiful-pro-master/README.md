<div align="center">
<img width="200" src="https://gitee.com/chu1204505056/image/raw/master/logo/vdb.svg"/>
<h1> vue-datav-beautiful </h1>
</div>

### 常规版(master)使用

```bash
# 克隆项目
git clone https://github.com/vue-datav-beautiful/vue-datav-beautiful-pro.git
# 进入项目目录
cd vue-datav-beautiful-pro
# 安装依赖
npm i --registry=https://registry.npm.taobao.org
# 本地开发 启动项目
npm run serve
```

- 如何修改地址去`src/requst.js`中修改
