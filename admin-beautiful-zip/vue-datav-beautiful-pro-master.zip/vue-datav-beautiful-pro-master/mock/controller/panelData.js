module.exports = [
  {
    url: '/panelData/listByPage',
    type: 'get',
    response: () => {
      return {
        code: 200,
        msg: 'success',
        data: [
          {
            imgNum: 117,
            fileSize: 59031.0,
            labelNum: 3444,
            labelFileSize: 12876.0,
            todayAddImgNum: 3425,
            todayAddFileSize: 809.0,
            todayLabelImgNum: 1343,
            todayLabelFileSize: 4283.0,
            reidImgNum: 334,
            multipleObjDetectImgNum: 24,
            lightClaImgNum: 3443,
            pedestrianTargetNum: 2332,
            bikerTargetNum: 2333,
            vehicleTargetNum: 6235,
            lightClaTargetNum: 2332,
            totalAccessNum: 1420,
            totalUserNum: 4252,
            totalModelNum: 2343,
            totalModelEavluationNum: 6443,
            collectTime: '2021-02-24 14:48:54',
            algoFrameworkNum: 2435,
            marketAlgoModelNum: 2433,
            algoModelNum: 2343,
          },
        ],
      }
    },
  },
  {
    url: '/panelData/getAllNodeResource',
    type: 'get',
    response: () => {
      return {
        code: 200,
        msg: 'success',
        data: [
          {
            cpuAvailable: 324324,
            gpuMemTotal: 44712,
            gpuUsedTotal: 19934,
            gpuAvailable: '44%',
            memAvailable: 24224432,
          },
        ],
      }
    },
  },
  {
    url: '/panelData/algoUseHistory',
    type: 'get',
    response: () => {
      return {
        code: 200,
        msg: '操作成功',
        data: [
          {
            seriesData: [34523, 24354, 245, 245, 4325, 6456, 35635],
            xAxisData: [
              '2021-02-18',
              '2021-02-19',
              '2021-02-20',
              '2021-02-21',
              '2021-02-22',
              '2021-02-23',
              '2021-02-24',
            ],
          },
        ],
      }
    },
  },
]
