/**
 * @description vue.config.js全局配置
 */
const webpack = require('webpack')

module.exports = {
  publicPath: '',
  devServer: {
    hot: true,
    open: true,
    noInfo: false,
    overlay: {
      warnings: true,
      errors: true,
    },
    after: require('./mock'),
  },
  configureWebpack: {
    plugins: [
      new webpack.ProvidePlugin({
        maptalks: 'maptalks',
        'window.maptalks': 'maptalks',
      }),
    ],
  },
}
