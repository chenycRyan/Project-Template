<template>
  <vab-card
    :animation="'fade-in-right'"
    class="right-center"
    description=""
    title="服务器访问人数"
  >
    <el-row>
      <el-col :span="12">
        <el-image
          class="left-images"
          :src="require('@/assets/index_images/terminal.png')"
        />
      </el-col>
      <el-col :span="12">
        <vab-count
          class="right-count"
          :decimals="countConfig.decimals"
          :duration="countConfig.duration"
          :end-val="countConfig.endVal"
          :prefix="countConfig.prefix"
          :separator="countConfig.separator"
          :start-val="countConfig.startVal"
          :suffix="countConfig.suffix"
        />
      </el-col>
    </el-row>
  </vab-card>
</template>

<script>
  import _ from 'lodash'

  export default {
    name: 'RIghtCenter',
    data() {
      return {
        countConfig: {
          startVal: 0,
          endVal: _.random(20000, 60000),
          decimals: 0,
          prefix: '',
          suffix: '',
          separator: ',',
          duration: 8000,
        },
      }
    },
  }
</script>

<style lang="scss" scoped>
  .right-center {
    height: 150px;
    margin-top: $base-margin;

    .left-images {
      width: 90%;
      margin-top: -10px;
    }

    .right-count {
      font-family: 'vab-count';
      font-size: 40px;
      line-height: 80px;
      color: #23f7b4;
    }
  }
</style>
