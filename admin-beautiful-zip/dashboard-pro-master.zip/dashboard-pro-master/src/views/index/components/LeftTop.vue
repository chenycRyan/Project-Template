<template>
  <vab-card
    animation="fade-in-left"
    class="left-top"
    description="Vue admin beautiful wish"
    title="待办事项"
  >
    <el-row>
      <el-col v-for="item in list" :key="item.id" :span="8">
        <div class="grid-content">
          <vab-icon :icon="item.icon" />
          <p class="grid-num">{{ item.num }}</p>
          <p class="grid-txt">{{ item.txt }}</p>
        </div>
      </el-col>
    </el-row>
  </vab-card>
</template>

<script>
  import { getLeftTopList } from '@/api/index'

  export default {
    name: 'LeftTop',
    data() {
      return {
        list: [],
      }
    },
    created() {
      this.fetchData()
    },
    methods: {
      async fetchData() {
        const {
          data: { list },
        } = await getLeftTopList()
        this.list = list
      },
    },
  }
</script>

<style lang="scss" scoped>
  .left-top {
    height: 350px;

    .grid-content {
      margin: 5px 0;
      text-align: center;

      i {
        font-size: 25px;
      }

      .grid-num {
        font-family: 'vab-count';
        font-size: 20px;
        font-weight: bold;
        color: #23f7b4;
        border-right: 1px solid rgba(35, 247, 180, 0.3);
      }

      .grid-txt {
        font-size: 12px;
      }
    }
  }
</style>
