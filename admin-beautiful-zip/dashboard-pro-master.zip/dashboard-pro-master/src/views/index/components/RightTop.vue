<template>
  <vab-card
    animation="fade-in-right"
    class="right-top"
    description="Industry distribution"
    title="行业分布"
  >
    <vab-chart
      ref="myBar"
      auto-resize
      class="my-chart"
      :init-options="initOptions"
      :options="options"
      theme="vab-echarts-theme"
    />
  </vab-card>
</template>

<script>
  /*  import * as echarts from 'echarts' */
  import VabChart from '@/extra/VabChart'

  export default {
    name: 'RightTop',
    components: { VabChart },
    data() {
      return {
        initOptions: {
          renderer: 'svg',
        },
        options: {
          series: {
            name: '面积模式',
            type: 'pie',
            radius: [12, 58],
            center: ['50%', '30%'],
            roseType: 'area',
            itemStyle: {
              borderRadius: 2,
            },
            label: {
              formatter: '{name|{b}}',
              rich: {
                name: {
                  fontSize: 12,
                  color: '#00c2ff',
                },
              },
            },
            data: [
              { value: 40, name: '协同研发设计' },
              { value: 38, name: '远程设备操控' },
              { value: 32, name: '设备协同作业' },
              { value: 30, name: '柔性生产制造' },
              { value: 28, name: '现场辅助装配' },
              { value: 26, name: '机器视觉质检' },
              { value: 22, name: '设备故障诊断' },
              { value: 18, name: '厂区智能物流' },
            ],
          },
        },
      }
    },
  }
</script>

<style lang="scss" scoped>
  .right-top {
    height: 250px;

    .my-chart {
      width: 100%;
      height: 100%;
    }
  }
</style>
