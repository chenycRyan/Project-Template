<template>
  <div class="map-pannel">
    <!-- <el-button-group class="button-group">
      <el-button type="primary" @click="doMark">标注地图点位</el-button>
      <el-button type="primary" @click="delMark">移除点位</el-button>
      <el-button type="primary" @click="doAnimateMark(1)">动态图标1</el-button>
      <el-button type="primary" @click="doAnimateMark(2)">动态图标2</el-button>
      <el-button type="primary" @click="moveTo">联动：飞行到指定地点</el-button>
      <el-button type="primary" @click="frameSelect">框选</el-button>
      <el-button type="primary" @click="endFrameSelect">框选结束</el-button>
      <el-button type="primary" @click="manualMark">手动标注</el-button>
      <el-button type="primary" @click="endManualMark">结束手动标注</el-button>
      <el-button type="primary" @click="initRouteLine">动态绘制路线</el-button>
      <el-button type="primary" @click="doFilter('all')">
        点位筛选-显示全部
      </el-button>
      <el-button type="primary" @click="doFilter('none')">
        点位筛选-隐藏全部
      </el-button>
      <el-button type="primary" @click="doFilter('other', { status: [0] })">
        点位筛选-显示status为0的点位
      </el-button>
    </el-button-group> -->
    <!-- <div>
      框选结果：
      <el-input v-model="selectRes" style="width: 150px" />
      手动标注结果（x,y）：
      <el-input
        v-model="coordinate[0]"
        style="width: 150px; margin-right: 10px"
      />
      <el-input v-model="coordinate[1]" style="width: 150px" />
    </div> -->
    <vab-map
      ref="vabMap"
      class="map-box"
      @getMousedownVal="getMousedownVal"
      @selectMark="selectMark"
    />
  </div>
</template>

<script>
  import VabMap from '@/extra/VabMap'

  export default {
    name: 'CenterMap',
    components: { VabMap },
    data() {
      return {
        selectRes: '',
        coordinate: [],
        routeData: [
          {
            status: 1,
            coordinate: [116.46917, 40.019438],
            date: '2019-08-20 10:09:23',
            title: '演示地址暂不提供推流演示',
            description: 'hls实时流推送演示',
            image:
              'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=274127356,2630773985&fm=26&gp=0.jpg',
          },
          {
            status: 1,
            coordinate: [116.39722, 39.9096],
            date: '2019-08-20 15:54:32',
            title: '演示地址暂不提供推流演示',
            description: 'hls实时流推送演示',
            image:
              'https://ss3.bdstatic.com/70cFv8Sh_Q1YnxGkpoWK1HF6hhy/it/u=274127356,2630773985&fm=26&gp=0.jpg',
          },
        ],
      }
    },
    mounted() {
      this.doAnimateMark(1)
    },
    methods: {
      doMark() {
        const addressPoints = [
          {
            id: 0,
            status: 0,
            coordinate: [116.42182, 39.92433],
          },
          {
            id: 1,
            status: 0,
            coordinate: [116.44827, 39.91637],
          },
          {
            id: 2,
            status: 0,
            coordinate: [116.37295, 39.90707],
          },
          {
            id: 3,
            status: 0,
            coordinate: [116.66271, 39.9069],
          },
          {
            id: 4,
            status: 1,
            coordinate: [116.30454, 39.95521],
          },
          {
            id: 5,
            status: 1,
            coordinate: [116.29591, 39.85439],
          },
          {
            id: 6,
            status: 1,
            coordinate: [116.22347, 39.90001],
          },
          {
            id: 7,
            status: 1,
            coordinate: [116.42182, 39.98433],
          },
        ]
        this.$refs.vabMap.initMark(addressPoints)
      },
      delMark() {
        this.$refs.vabMap.removeMark(this.$refs.vabMap.clusterLayer)
        this.$refs.vabMap.clusterLayer = null
      },
      moveTo() {
        this.$refs.vabMap.changeView([116.42182, 39.92433])
      },
      doAnimateMark(type) {
        this.$refs.vabMap.animateMarker(this.routeData, type)
      },
      frameSelect() {
        this.$refs.vabMap.clearDraw()
        this.$refs.vabMap.doDraw('Rectangle')
      },
      selectMark(res) {
        this.selectRes = res.join(',')
      },
      endFrameSelect() {
        this.$refs.vabMap.drawTool.disable()
        this.$refs.vabMap.startDraw = false
      },
      manualMark() {
        this.$refs.vabMap.startMark = true
        this.$refs.vabMap.manualMark()
      },
      endManualMark() {
        this.$refs.vabMap.startMark = false
      },
      getMousedownVal(val) {
        this.coordinate = val
      },
      initRouteLine() {
        this.$refs.vabMap.initRouteLine(this.routeData)
      },
      doFilter(type, value) {
        const that = this
        if (type == 'all') {
          that.$refs.vabMap.filter(that.$refs.vabMap.clusterLayer)
        } else if (type == 'other') {
          that.$refs.vabMap.filter(that.$refs.vabMap.clusterLayer, type, value)
        } else {
          that.$refs.vabMap.filter(that.$refs.vabMap.clusterLayer, type)
        }
      },
    },
  }
</script>

<style lang="scss" scoped>
  .map-pannel {
    .button-group {
      position: absolute;
      top: 20px;
      right: 320px;
      left: 320px;
      z-index: 999;

      .el-button {
        margin-bottom: 20px;
      }
    }

    .map-box {
      position: absolute;
      top: 0;
      right: 0;
      bottom: -5px;
      left: 0;
    }
  }
</style>
