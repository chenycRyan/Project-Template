<template>
  <vab-card
    animation="fade-in-right"
    class="right-bottom"
    description="Personnel distribution"
    title="人员分布"
  >
    <ul class="list">
      <li
        v-for="(item, index) in list"
        :key="item.id"
        class="list-item"
        :style="{ 'animation-delay': index * 0.1 + 's' }"
      >
        <el-image :src="item.avatar" />
        <div class="list-item-right">
          <p>{{ item.name }}</p>
          <p>{{ item.description }}</p>
          <p>{{ item.datetime }}</p>
        </div>
      </li>
    </ul>
  </vab-card>
</template>

<script>
  import { getRightBottomList } from '@/api/index'

  export default {
    name: 'RightBottom',
    data() {
      return {
        list: [],
      }
    },
    created() {
      this.fetchData()
    },
    methods: {
      async fetchData() {
        const {
          data: { list },
        } = await getRightBottomList()
        this.list = list
      },
    },
  }
</script>

<style lang="scss" scoped>
  .list {
    height: calc(100vh - 750px);
    padding: 0 0 10px 0;
    margin-top: -10px;
    overflow-y: auto;

    &-item {
      width: 100%;
      height: 80px;
      padding: 0 !important;
      margin: 10px auto;
      color: #fff;
      background-image: linear-gradient(
        to right,
        rgba(30, 110, 217, 0.5),
        transparent
      );
      animation: move 1s cubic-bezier(0.62, -0.5, 0.45, 1.5);
      animation-fill-mode: both;

      &-right {
        float: left;
        width: calc(100% - 80px);
        padding: 10px;

        p {
          padding: 0;
          margin: 0;
          overflow: hidden;
          line-height: 20px;
          text-overflow: ellipsis;
          white-space: nowrap;
        }
      }

      ::v-deep {
        .el-image {
          float: left;
          width: 80px;
          height: 80px;
          padding: 0;
          margin: 0;

          &_inner {
            margin: 0;
          }
        }
      }
    }

    @keyframes move {
      from {
        opacity: 0;
        transform: translateX(100%);
      }

      to {
        opacity: 1;
        transform: translateX(0%);
      }
    }
  }
</style>

<style lang="scss" scoped>
  .right-bottom {
    height: calc(100vh - 650px);
    margin-top: $base-margin;
  }
</style>
