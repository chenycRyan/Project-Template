<template>
  <vab-card
    animation="fade-in-left"
    class="left-bottom"
    description="Consumption TOP8 ranking"
    title="TOP8排名"
  >
    <vab-chart
      ref="myBar"
      auto-resize
      class="my-chart"
      :init-options="initOptions"
      :options="options"
      theme="vab-echarts-theme"
    />
  </vab-card>
</template>

<script>
  import * as echarts from 'echarts'
  import VabChart from '@/extra/VabChart'

  export default {
    name: 'LeftBottom',
    components: { VabChart },
    data() {
      return {
        options: {
          tooltip: {
            trigger: 'axis',
            show: false,
            axisPointer: {
              type: 'shadow',
            },
          },
          legend: {
            left: '0%',
            top: '2%',
            selectedMode: false,
            textStyle: {
              color: '#fff',
            },
          },
          grid: {
            top: '15%',
            containLabel: true,
          },
          xAxis: {
            splitLine: {
              show: false,
            },
            type: 'value',
            show: false,
            axisLabel: {
              interval: 0,
              color: '#999',
              margin: 15,
            },
          },
          yAxis: {
            splitLine: {
              show: false,
            },
            axisLine: {
              show: false,
            },
            type: 'category',
            axisTick: {
              show: false,
            },
            data: [],
            axisLabel: {
              interval: 0,
              color: '#fff',
              margin: 15,
            },
          },
          series: {
            name: '能耗',
            type: 'bar',
            barWidth: 10,
            label: {
              show: true,
              position: 'right',
              color: '#1CD8A8',
              fontSize: 14,
              fontWeight: 'bold',
              distance: 5,
            },
            itemStyle: {
              color: new echarts.graphic.LinearGradient(
                0,
                0,
                1,
                0,
                ['rgba(74,254,252,0)', '#23f7b4'].map((color, offset) => ({
                  color,
                  offset,
                }))
              ),
            },
            data: [],
          },
        },
        initOptions: {
          renderer: 'svg',
        },
      }
    },
    mounted() {
      setTimeout(() => {
        this.options.yAxis.data = [
          'top8',
          'top7',
          'top6',
          'top5',
          'top4',
          'top3',
          'top2',
          'top1',
        ]
        this.options.series.data = [1, 2, 3, 4, 5, 6, 7, 8]
      }, 500)
    },
  }
</script>

<style lang="scss" scoped>
  .left-bottom {
    height: calc(100vh - 580px);
    margin-top: $base-margin;

    .my-chart {
      width: 100%;
      height: calc(100vh - 600px);
    }
  }
</style>
