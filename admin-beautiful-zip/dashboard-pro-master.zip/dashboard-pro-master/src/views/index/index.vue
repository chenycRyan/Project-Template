<template>
  <div class="index-container">
    <center-map />
    <div class="left-panel">
      <left-top />
      <left-bottom />
    </div>
    <div class="right-panel">
      <right-top />
      <right-center />
      <right-bottom />
    </div>
  </div>
</template>

<script>
  import CenterMap from './components/CenterMap.vue'
  import LeftTop from './components/LeftTop'
  import LeftBottom from './components/LeftBottom'
  import RightTop from './components/RightTop'
  import RightCenter from './components/RightCenter'
  import RightBottom from './components/RightBottom'

  export default {
    name: 'Index',
    components: {
      CenterMap,
      LeftTop,
      LeftBottom,
      RightTop,
      RightCenter,
      RightBottom,
    },
    data() {
      return {}
    },
  }
</script>

<style lang="scss" scoped>
  .index-container {
    .left-panel {
      position: absolute;
      top: 20px;
      top: 0;
      bottom: 20px;
    }

    .right-panel {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 20px;
    }
  }
</style>
