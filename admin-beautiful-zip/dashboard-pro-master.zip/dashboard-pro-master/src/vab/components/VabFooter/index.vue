<template>
  <footer class="vab-footer">
    Copyright
    <vab-icon icon="copyright-line" />
    {{ title }} {{ fullYear }}
  </footer>
</template>

<script>
  import { title } from '@/config'

  export default {
    name: 'VabFooter',
    data() {
      return {
        fullYear: new Date().getFullYear(),
        title,
      }
    },
  }
</script>

<style lang="scss" scoped>
  .vab-footer {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 25px;
    padding: 0 $base-padding 0 $base-padding;
    color: $base-color-white;
    background: $base-color-background-light;

    i {
      margin: 0 5px;
    }
  }
</style>
