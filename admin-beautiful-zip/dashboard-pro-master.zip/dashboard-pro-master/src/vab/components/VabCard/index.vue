<template>
  <div class="card-box" :class="animation">
    <h3>{{ title }}</h3>
    <p>{{ description }}</p>
    <slot />
  </div>
</template>

<script>
  export default {
    name: 'VabCard',
    props: {
      animation: {
        type: String,
        default: 'fade-in-down',
      },
      title: {
        type: String,
        default: '',
      },
      description: {
        type: String,
        default: '',
      },
    },
  }
</script>

<style lang="scss" scoped>
  .card-box {
    width: 300px;
    padding: 0 10px;
    background-color: rgba(21, 76, 150, 0.3);
    border: 2px solid #0ff;
    border-radius: $base-border-radius;
    box-shadow: 0 6px 12px 0 rgba(0, 41, 79, 0.5);

    &:hover {
      background-color: rgba(21, 76, 150, 0.4);
    }

    &:before {
      position: absolute;
      top: -2px;
      bottom: -2px;
      left: 10px;
      z-index: 0;
      width: calc(100% - 20px);
      pointer-events: none;
      content: '';
      border-top: 2px solid #163661;
      border-bottom: 2px solid #163661;
    }

    &:after {
      position: absolute;
      top: 10px;
      right: -2px;
      left: -2px;
      z-index: 0;
      height: calc(100% - 20px);
      pointer-events: none;
      content: '';
      border-right: 2px solid #163661;
      border-left: 2px solid #163661;
    }

    h3 {
      height: 25px;
      padding-left: 10px;
      font-size: 14px;
      line-height: 25px;
      background: url(~@/assets/index_images/card-header.png) no-repeat;
    }
  }

  /* 上方淡入 */
  .fade-in-down {
    animation: fadeInDown 1s 0.2s ease both;
  }

  @keyframes fadeInDown {
    0% {
      opacity: 0;
      transform: translateY(-40px);
    }

    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* 下方淡入 */
  .fade-in-up {
    animation: fadeInUp 1s 0.2s ease both;
  }

  @keyframes fadeInUp {
    0% {
      opacity: 0;
      transform: translateY(40px);
    }

    100% {
      opacity: 1;
      transform: translateY(0);
    }
  }

  /* 左边淡入 */
  .fade-in-left {
    animation: fadeInLeft 1s 0.2s ease both;
  }

  @keyframes fadeInLeft {
    0% {
      opacity: 0;
      transform: translateX(-40px);
    }

    100% {
      opacity: 1;
      transform: translateX(0);
    }
  }

  /* 右边淡入 */
  .fade-in-right {
    animation: fadeInRight 1s 0.2s ease both;
  }

  @keyframes fadeInRight {
    0% {
      opacity: 0;
      transform: translateX(40px);
    }

    100% {
      opacity: 1;
      transform: translateX(0);
    }
  }
</style>
