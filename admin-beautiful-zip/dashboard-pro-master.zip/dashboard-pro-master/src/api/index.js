import request from '@/utils/request'

export function getLeftTopList(params) {
  return request({
    url: '/index/getLeftTopList',
    method: 'get',
    params,
  })
}

export function getRightBottomList(params) {
  return request({
    url: '/index/getRightBottomList',
    method: 'get',
    params,
  })
}
