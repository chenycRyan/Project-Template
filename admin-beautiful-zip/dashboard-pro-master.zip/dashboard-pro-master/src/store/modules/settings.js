/**
 * @description 所有全局配置的状态管理，如无必要请勿修改
 */
import { isJson } from '@/utils/validate'
import {
  fixedHeader,
  i18n,
  logo,
  showFullScreen,
  showLanguage,
  showProgressBar,
  showRefresh,
  showTabs,
  showTabsBarIcon,
  showTheme,
  showThemeSetting,
  title,
} from '@/config'

const defaultTheme = {
  fixedHeader,
  showProgressBar,
  showTabs,
  showTabsBarIcon,
  showLanguage,
  showRefresh,
  showFullScreen,
  showTheme,
  showThemeSetting,
}
const getLocalStorage = (key) => {
  const value = localStorage.getItem(key)
  if (isJson(value)) {
    return JSON.parse(value)
  } else {
    return false
  }
}
const { language } = getLocalStorage('language')
const state = () => ({
  logo,
  title,
  language: language || i18n,
  theme: getLocalStorage('theme') || { ...defaultTheme },
  extra: { first: '', transferRouteName: '' },
})
const getters = {
  logo: (state) => state.logo,
  title: (state) => state.title,
  language: (state) => state.language,
  theme: (state) => state.theme,
  extra: (state) => state.extra,
}
const mutations = {
  changeLanguage(state, language) {
    state.language = language
    localStorage.setItem('language', `{"language":"${language}"}`)
  },
  saveTheme(state) {
    localStorage.setItem('theme', JSON.stringify(state.theme))
  },
  resetTheme(state) {
    state.theme = { ...defaultTheme }
    localStorage.removeItem('theme')
    document.getElementsByTagName(
      'body'
    )[0].className = `vab-theme-${state.theme.themeName}`
  },
}
const actions = {
  changeLanguage: ({ commit }, language) => {
    commit('changeLanguage', language)
  },
  saveTheme({ commit }) {
    commit('saveTheme')
  },
  resetTheme({ commit }) {
    commit('resetTheme')
  },
}
export default { state, getters, mutations, actions }
