/**
 * @description 导出主题配置，注意事项：此配置下的项修改后需清理浏览器缓存！！！
 */
module.exports = {
  // 是否固定头部固定
  fixedHeader: false,
  // 是否开启标签页
  showTabs: true,
  // 是否标签页图标
  showTabsBarIcon: true,
  // 是否开启语言选择组件
  showLanguage: true,
  // 是否开启刷新组件
  showRefresh: true,
  // 是否开启全屏组件
  showFullScreen: true,
  // 是否开启主题组件
  showTheme: true,
  // 是否开启右侧悬浮窗
  showThemeSetting: true,
}
