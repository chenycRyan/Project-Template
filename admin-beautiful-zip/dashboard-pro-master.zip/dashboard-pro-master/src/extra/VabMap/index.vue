<template>
  <div class="map-container">
    <div id="map"></div>
  </div>
</template>

<script>
  const symbol1 = [
    {
      markerFile: require('@/assets/index_images/animate.png'),
      markerWidth: 24,
      markerHeight: 26,
      markerOpacity: 0.4,
      markerDy: 1,
    },
    {
      markerFile: require('@/assets/index_images/animate.png'),
      markerWidth: 22,
      markerHeight: 24,
    },
  ]
  const symbol2 = [
    {
      markerFile: require('@/assets/index_images/trapezium.png'),
      markerWidth: 32,
      markerHeight: 22,
      markerOpacity: 0.6,
      markerDy: 25,
    },
    {
      markerFile: require('@/assets/index_images/circle_filled.png'),
      markerWidth: 32,
      markerHeight: 32,
      markerOpacity: 0.6,
      markerDy: 0,
      markerPlacement: 'point',
      markerRotation: 0,
      markerHorizontalAlignment: 'middle',
      markerVerticalAlignment: 'middle',
    },
    {
      textName: '2',
      textFill: '#fff',
      textSize: 12,
      textDy: 0,
    },
  ]
  import * as maptalks from 'maptalks'
  import 'maptalks/dist/maptalks.css'
  import groupBy from 'lodash/groupBy'
  import { ClusterLayer } from 'maptalks.markercluster'
  import HlsPlayer from 'xgplayer-hls.js'
  import axios from 'axios'
  import * as mapv from 'mapv'

  export default {
    name: 'TheMap',
    props: {
      addressPoints: {
        type: Array,
        default: () => {
          return []
        },
      },
    },
    data() {
      return {
        map: null,
        clusterLayer: null,
        clusterLayer1: null,
        manualMarkLayer: null,
        shapeLayer: null,
        drawTool: null,
        startDraw: false,
        startMark: false,
        myhint: null,
        myMap: null,
        shapeType: '',
        routeLayer: null,
        routeLayer1: null,
        routeLayer2: null,
        player: null,
      }
    },
    created() {},
    mounted() {
      this.initMap()
      this.initShapeDraw()
    },
    methods: {
      initMap() {
        this.map = new maptalks.Map('map', {
          center: [116.41348403785, 39.910843952376],
          zoom: 12,
          spatialReference: {
            projection: 'baidu',
          },
          fpsOnInteracting: 0,
          baseLayer: new maptalks.TileLayer('base', {
            urlTemplate:
              'http://online{s}.map.bdimg.com/onlinelabel/?qt=tile&x={x}&y={y}&z={z}&styles=pl&scaler=1&p=1',
            subdomains: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
            attribution:
              '&copy; <a target="_blank" href="http://map.baidu.com">百度地图</a>',
            cssFilter: 'sepia(100%) invert(92.5%)',
          }),
        })
        this.map.animateTo(
          {
            center: [116.41348403785, 39.910843952376],
            zoom: 12,
          },
          {
            duration: 2000,
          }
        )

        const map = this.map

        axios
          .get(
            'https://cdn.jsdelivr.net/npm/mapv@2.0.12/examples/data/od-xierqi.txt'
          )
          .then((rs) => {
            let data = []
            let timeData = []

            rs = rs.data.split('\n')
            let maxLength = 0
            for (let i = 0; i < rs.length; i++) {
              let item = rs[i].split(',')
              let coordinates = []
              if (item.length > maxLength) {
                maxLength = item.length
              }
              for (let j = 0; j < item.length; j += 2) {
                let x = (Number(item[j]) / 20037508.34) * 180
                let y = (Number(item[j + 1]) / 20037508.34) * 180
                y =
                  (180 / Math.PI) *
                  (2 * Math.atan(Math.exp((y * Math.PI) / 180)) - Math.PI / 2)
                // eslint-disable-next-line use-isnan
                if (x == 0 || y == NaN) {
                  continue
                }
                coordinates.push([x, y])
                timeData.push({
                  geometry: {
                    type: 'Point',
                    coordinates: [x, y],
                  },
                  count: 1,
                  time: j,
                })
              }
              data.push({
                geometry: {
                  type: 'LineString',
                  coordinates: coordinates,
                },
              })
            }

            let dataSet = new mapv.DataSet(data)

            let options = {
              strokeStyle: '#23f4b3',
              // globalCompositeOperation: 'lighter',
              shadowColor: '#27a099',
              shadowBlur: 3,
              lineWidth: 3.0,
              draw: 'simple',
            }

            new mapv.MaptalksLayer('mapv1', dataSet, options).addTo(map)

            let dataSet2 = new mapv.DataSet(timeData)

            let options2 = {
              fillStyle: '#ff6806',
              globalCompositeOperation: 'lighter',
              size: 1.5,
              animation: {
                stepsRange: {
                  start: 0,
                  end: 100,
                },
                trails: 3,
                duration: 5,
              },
              draw: 'simple',
            }

            new mapv.MaptalksLayer('mapv2', dataSet2, options2).addTo(map)
          })
      },
      changeView(center) {
        this.map.animateTo(
          {
            center: center,
            zoom: 16,
            pitch: 30,
            bearing: this.map.getBearing(),
          },
          {
            duration: 1000,
          }
        )
      },
      initMark(addressPoints) {
        this.removeMark(this.clusterLayer)
        const markers = []
        for (let i = 0; i < addressPoints.length; i++) {
          const a = addressPoints[i].coordinate
          markers.push(
            new maptalks.Marker([a[0], a[1]], {
              id: addressPoints[i].id,
              properties: {
                status: addressPoints[i].status,
              },
              symbol: [
                {
                  markerFile: require('@/assets/index_images/monitor_map.png'),
                  markerWidth: 28,
                  markerHeight: 36,
                  markerDx: 0,
                  markerDy: 0,
                  markerOpacity: 1,
                },
              ],
            }).on('mousedown', onClick)
          )
        }

        function onClick(e) {
          e.target.setInfoWindow({
            title: 'x:' + e.coordinate.x + ',y:' + e.coordinate.y,
            content:
              '<div class="map-popover">' +
              '<div class="mark-info">' +
              '</div>' +
              '</div>',
            width: 400,
            minHeight: 100,
            dy: 5,
            autoPan: true,
            custom: false,
            autoOpenOn: 'click',
            autoCloseOn: 'click',
          })
        }

        this.clusterLayer = new ClusterLayer('cluster', markers, {
          noClusterWithOneMarker: false,
          maxClusterZoom: 10,
          zIndex: '100',
          symbol: {
            markerType: 'ellipse',
            markerFill: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, 'rgb(135, 196, 240)'],
                [9, '#1bbc9b'],
                [99, 'rgb(216, 115, 149)'],
              ],
            },
            markerFillOpacity: 0.7,
            markerLineOpacity: 1,
            markerLineWidth: 3,
            markerLineColor: '#fff',
            markerWidth: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, 40],
                [9, 60],
                [99, 80],
              ],
            },
            markerHeight: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, 40],
                [9, 60],
                [99, 80],
              ],
            },
          },
          drawClusterText: true,
          geometryEvents: true,
          single: true,
        })
        this.map.addLayer(this.clusterLayer)
      },
      removeMark(obj) {
        if (obj) {
          this.map.removeLayer(obj)
        }
      },
      animateMarker(addressPoints, type) {
        this.removeMark(this.clusterLayer1)
        const markers = []
        let symbol
        if (type == 1) {
          symbol = symbol1
          this.map.animateTo(
            {
              pitch: 30,
              bearing: this.map.getBearing() + 2,
            },
            {
              duration: 1000,
            }
          )
        } else if (type == 2) {
          symbol = symbol2
          this.map.animateTo(
            {
              pitch: 30,
              bearing: this.map.getBearing() + 2,
            },
            {
              duration: 1000,
            }
          )
        }

        let addressPoint = {}

        for (let i = 0; i < addressPoints.length; i++) {
          const marker = new maptalks.Marker(
            [addressPoints[i].coordinate[0], addressPoints[i].coordinate[1]],
            {
              id: addressPoints[i].id,
              properties: {
                title: addressPoints[i].title,
                description: addressPoints[i].description,
                name: addressPoints[i].name,
                image: addressPoints[i].image,
                status: addressPoints[i].status,
              },
              symbol: symbol,
            }
          )
          markers.push(marker.on('mousedown', this.onClick))
          addressPoint = addressPoints[i]
        }

        const layer = new maptalks.VectorLayer('vector').addTo(this.map)
        const marker = new maptalks.Marker(
          [addressPoint.coordinate[0], addressPoint.coordinate[1]],
          {
            id: addressPoint.id,
            properties: {
              title: addressPoint.title,
              description: addressPoint.description,
              name: addressPoint.name,
              image: addressPoint.image,
              status: addressPoint.status,
            },
            symbol: symbol,
          }
        )
        marker.addTo(layer)
        this.onClick({ target: marker })
        marker.openInfoWindow()

        this.clusterLayer1 = new ClusterLayer('cluster1', markers, {
          noClusterWithOneMarker: false,
          maxClusterZoom: 10,
          zIndex: '100',
          symbol: {
            markerType: 'ellipse',
            markerFill: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, '#24ebb1'],
                [9, '#24ebb1'],
                [99, 'rgb(216, 115, 149)'],
              ],
            },
            markerFillOpacity: 0.7,
            markerLineOpacity: 1,
            markerLineWidth: 2,
            markerLineColor: '#fff',
            markerWidth: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, 40],
                [9, 60],
                [99, 80],
              ],
            },
            markerHeight: {
              property: 'count',
              type: 'interval',
              stops: [
                [0, 40],
                [9, 60],
                [99, 80],
              ],
            },
          },
          drawClusterText: true,
          geometryEvents: true,
          single: true,
          forceRenderOnMoving: true,
          forceRenderOnZooming: true,
          forceRenderOnRotating: true,
          enableAltitude: true,
        })
        this.map.addLayer(this.clusterLayer1)

        if (type == 1) {
          this.replay(markers)
          setInterval(() => {
            this.replay(markers)
          }, 1400)
        }
      },
      replay(markers) {
        markers.map((item) => {
          item.animate(
            {
              symbol: [
                {
                  markerWidth: 32,
                  markerHeight: 32,
                  markerOpacity: 0.4,
                  markerDy: 5,
                },
                {
                  markerWidth: 22,
                  markerHeight: 22,
                },
              ],
            },
            {
              duration: 700,
            }
          )
        })
        setTimeout(() => {
          markers.map((item) => {
            item.animate(
              {
                symbol: [
                  {
                    markerWidth: 24,
                    markerHeight: 24,
                    markerOpacity: 0.4,
                    markerDy: 1,
                  },
                  {
                    markerWidth: 22,
                    markerHeight: 22,
                  },
                ],
              },
              {
                duration: 700,
              }
            )
          })
        }, 700)
      },
      onClick(e) {
        e.target.setInfoWindow({
          title:
            '<div>\n' +
            '        <span class="waver-span waver-spanl waver-span1"></span>\n' +
            '        <span class="waver-span waver-spanl waver-span2"></span>\n' +
            '        <span class="waver-span waver-spanl waver-span3"></span>\n' +
            '        <span class="waver-span waver-spanl waver-span4"></span>\n' +
            e.target.properties.title +
            '    </div>',
          content:
            '<div class="map-popover">' +
            /*  '<div class="mark-info">' +
          e.target.properties.description +
          '</div>' + */
            '<div id="vabPlayerHls"></div>' +
            '</div>',
          width: 350,
          dy: 5,
          autoPan: true,
          custom: false,
          autoOpenOn: 'click',
          autoCloseOn: 'click',
          animation: 'fade,scale',
        })
        this.map.on('click', () => {
          this.player &&
            typeof this.player.destroy === 'function' &&
            this.player.destroy()
          this.player = null
        })
        setTimeout(() => {
          this.player &&
            typeof this.player.destroy === 'function' &&
            this.player.destroy()
          this.player = null

          this.player = new HlsPlayer({
            el: document.querySelector('#vabPlayerHls'),
            url: 'http://cdn.jsdelivr.net/gh/chuzhixin/videos@master/video.m3u8',
            autoplay: false,
            fluid: true,
            poster: 'https://i.ytimg.com/vi/lK2ZbbQSHww/hqdefault.jpg',
          })
        }, 1000)
      },
      filter(layer, type, value) {
        if (layer) {
          layer.forEach((feature) => {
            feature.hide()
          })
          if (type == 'other') {
            for (let key in value) {
              layer.forEach((feature) => {
                if (value[key].indexOf(feature.properties[key]) != -1) {
                  feature.show()
                }
              })
            }
          } else if (type == 'none') {
            layer.forEach((feature) => {
              feature.hide()
            })
          } else {
            layer.forEach((feature) => {
              feature.show()
            })
          }
        }
      },
      initShapeDraw() {
        this.map.on('click', () => {
          if (this.startDraw) {
            this.shapeLayer.clear()
            this.$emit('selectMark', [])
            if (this.shapeType == 'Polygon' || this.shapeType == 'LineString') {
              this.WordsFollowMouseDOM(2)
            } else if (
              this.shapeType == 'FreeHandLineString' ||
              this.shapeType == 'FreeHandPolygon'
            ) {
              this.WordsFollowMouseDOM(4)
            } else {
              this.WordsFollowMouseDOM(3)
            }
          }
        })
        this.myMap = document.getElementById('map')
        this.myhint = document.createElement('div')
        this.myhint.style.position = 'absolute'
        this.myMap.appendChild(this.myhint)
        this.shapeLayer = new maptalks.VectorLayer('shapeLayer', null, {
          zIndex: '101',
        }).addTo(this.map)

        this.drawTool = new maptalks.DrawTool({
          mode: 'Point',
          symbol: {
            lineColor: 'rgb(0,208,223)',
            lineWidth: 2,
            polygonFill: 'rgb(135,196,240)',
            polygonOpacity: 0.6,
          },
        })
          .addTo(this.map)
          .disable()
        this.drawTool.on('drawend', (param) => {
          this.shapeLayer.addGeometry(param.geometry)
          this.WordsFollowMouseDOM()
          const selectedMark = []
          if (this.clusterLayer) {
            this.clusterLayer.forEach((feature) => {
              if (param.geometry.containsPoint(feature._coordinates)) {
                selectedMark.push(feature._id)
              }
            })
          }
          this.$emit('selectMark', selectedMark)
        })
      },
      doDraw(shapeType) {
        this.drawTool.setMode(shapeType).enable()
        if (shapeType == 'Point') {
          this.drawTool.setSymbol([
            {
              markerType: 'ellipse',
              markerWidth: 30,
              markerHeight: 30,
              markerFill: 'rgb(64, 158, 255)',
              markerFillOpacity: 0.7,
              markerLineColor: '#73b8ff',
              markerLineWidth: 0,
            },
            {
              markerType: 'ellipse',
              markerWidth: 15,
              markerHeight: 15,
              markerFill: '#006ddd',
              markerFillOpacity: 0.8,
              markerLineWidth: 0,
            },
          ])
        } else {
          this.drawTool.setSymbol({
            lineColor: '#1890ff',
            lineWidth: 2,
            polygonFill: 'rgb(135,196,240)',
            polygonOpacity: 0.6,
          })
        }
        this.WordsFollowMouseDOM(1)
        this.startDraw = true
        this.shapeType = shapeType
      },
      clearDraw() {
        this.WordsFollowMouseDOM()
        this.shapeLayer.clear()
        this.drawTool.disable()
        this.startDraw = false
      },
      WordsFollowMouseDOM(hintwords) {
        this.myMap.addEventListener('mousemove', (e) => {
          this.myhint.style.left =
            e.clientX - document.getElementById('map').offsetLeft + 10 + 'px'
          this.myhint.style.top =
            e.clientY - document.getElementById('map').offsetTop + 2 + 'px'
          this.myhint.style.backgroundColor = 'rgba(52,126,255,0.6)'
          this.myhint.style.padding = '2px 4px'
          this.myhint.style.fontSize = '12px'
          this.myhint.style.color = '#fff'
          this.myhint.style.borderRadius = '2px'
          this.myhint.style.fontWeight = '10'
          switch (hintwords) {
            case 1:
              this.myhint.innerHTML = '单击左键开始绘制'
              this.myhint.style.display = 'block'
              break
            case 2:
              this.myhint.innerHTML = '双击左键结束绘制'
              this.myhint.style.display = 'block'
              break
            case 3:
              this.myhint.innerHTML = '单击左键结束绘制'
              this.myhint.style.display = 'block'
              break
            case 4:
              this.myhint.innerHTML = '连续绘制'
              this.myhint.style.display = 'none'
              break
            default:
              this.myhint.innerHTML = ''
              this.myhint.style.display = 'none'
              break
          }
        })
        this.myMap.addEventListener('mouseout', () => {
          this.myhint.innerHTML = ''
          this.myhint.style.display = 'none'
        })
      },
      manualMark() {
        this.map.on('mousedown', (param) => {
          if (!this.startDraw && this.startMark) {
            this.removeMark(this.manualMarkLayer)
            const coordinate = param.coordinate.toFixed(5).toArray()
            const point = new maptalks.Marker(coordinate, {
              symbol: {
                markerFile: require('@/assets/index_images/map_icon.png'),
                markerWidth: 30,
                markerHeight: 30,
                markerDx: 0,
                markerDy: 0,
                markerOpacity: 1,
              },
            })
            this.manualMarkLayer = new maptalks.VectorLayer(
              'manualMarkLayer',
              point
            )
            this.map.addLayer(this.manualMarkLayer)
            this.$emit('getMousedownVal', coordinate)
          }
        })
      },
      initRouteLine(routeData) {
        this.removeMark(this.routeLayer)
        this.removeMark(this.routeLayer1)
        this.removeMark(this.routeLayer2)
        this.map.animateTo(
          {
            center: routeData[0].coordinate,
            zoom: 18,
          },
          {
            duration: 1000,
          }
        )
        const markers = []
        const lines = []
        const posObj = groupBy(routeData, 'name')
        const indexArr = []
        for (const o in posObj) {
          posObj[o].map((item, index) => {
            const coordinate = [
              item.coordinate[0] - ((index % 3) + 1) * 0.0006,
              item.coordinate[1] - Math.floor(index / 3) * 0.0005 + 0.0002,
            ]
            indexArr.push(
              new maptalks.Marker(coordinate, {
                properties: {
                  name: item.index,
                },
                symbol: {
                  markerWidth: 30,
                  markerHeight: 30,
                  textFaceName: 'sans-serif',
                  textName: item.index,
                  textSize: 16,
                  textFill: '#fff',
                  textOpacity: 1,
                  textHaloFill: 'rgba(178,4,23,0.8)',
                  textHaloRadius: 4,
                  textWrapWidth: null,
                  textLineSpacing: 0,
                  textDx: 0,
                  textDy: 0,
                  textHorizontalAlignment: 'middle',
                  textVerticalAlignment: 'middle',
                  textAlign: 'center',
                },
              })
            )
          })
        }

        for (let i = 0; i < routeData.length; i++) {
          markers.push(
            new maptalks.Marker(routeData[i].coordinate, {
              symbol: [
                {
                  markerPlacement: 'vertex',
                  markerFile: require('@/assets/index_images/map_icon.png'),
                  markerWidth: 30,
                  markerHeight: 30,
                },
                {
                  textFaceName: 'sans-serif',
                  textName: routeData[i].name,
                  textFill: '#1bbc9b',
                  textSize: 14,
                  textDy: 24,
                },
              ],
            })
          )
          if (i < routeData.length - 1) {
            lines.push(
              new maptalks.LineString(
                [routeData[i].coordinate, routeData[i + 1].coordinate],
                {
                  visible: false,
                  arrowStyle: 'classic',
                  arrowPlacement: 'vertex-last',
                  symbol: {
                    lineColor: '#1bbc9b',
                    lineDasharray: [8, 8],
                    lineWidth: 2,
                  },
                }
              )
            )
          }
        }

        this.routeLayer = new maptalks.VectorLayer('routeLayer', markers, {
          zIndex: '100',
        }).addTo(this.map)
        this.routeLayer1 = new maptalks.VectorLayer('routeLayer1', lines, {
          zIndex: '100',
        }).addTo(this.map)
        this.routeLayer2 = new maptalks.VectorLayer('routeLayer2', indexArr, {
          zIndex: '100',
        }).addTo(this.map)

        function linePlay(index) {
          lines[index].animateShow(
            {
              duration: 800,
              easing: 'out',
            },
            function (frame) {
              if (frame.state.playState === 'finished') {
                if (index < lines.length - 1) {
                  linePlay(index + 1)
                }
              }
            }
          )
        }

        setTimeout(() => {
          linePlay(0)
        }, 1000)
      },
    },
  }
</script>

<style lang="scss" scoped>
  .map-container {
    #map {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      left: 0;
    }

    ::v-deep {
      #vabPlayerHls {
        width: 305px;
        height: 176px;
        margin-top: 0px;
        margin-bottom: 10px;
        border-radius: $base-border-radius;
      }

      .maptalks-control {
        display: none;
      }

      .maptalks-msgBox {
        padding: 0 10px;
        background: rgba(0, 0, 0, 0.5);
        border: 2px solid #00f0f3;
        border-radius: $base-border-radius;

        &::before {
          position: absolute;
          top: -2px;
          bottom: -2px;
          left: 10px;
          z-index: 0;
          width: calc(100% - 20px);
          content: '';
          border-top: 2px solid #112a4c;
          border-bottom: 2px solid #112a4c;
        }

        &::after {
          position: absolute;
          top: 10px;
          right: -2px;
          left: -2px;
          z-index: 0;
          height: calc(100% - 20px);
          content: '';
          border-right: 2px solid #112a4c;
          border-left: 2px solid #112a4c;
        }

        h2 {
          font-weight: normal;
          color: #00f0f3;
        }

        em.maptalks-ico {
          display: none;
        }

        a.maptalks-close {
          right: 10px;
          width: 10px;
          height: 10px;
          background: url(~@/assets/index_images/close-line.png);

          &:hover {
            opacity: 0.9;
          }
        }

        .maptalks-msgContent {
          color: #00f0f3;

          .mark-img {
            width: 100%;
            min-height: 100px;
            margin: 10px auto;
            object-fit: cover;
          }
        }
      }

      .waver-span {
        display: inline-block;
        width: 4px;
        height: 10px;
        background-color: #00f0f3;
      }

      .waver-spanl {
        transform: skew(-25deg);
      }

      .waver-spanr {
        transform: skew(25deg);
      }

      .waver-span1 {
        animation: shake1 1s infinite;
      }

      .waver-span2 {
        animation: shake2 1s infinite;
      }

      .waver-span3 {
        animation: shake3 1s infinite;
      }

      .waver-span4 {
        animation: shake4 1s infinite;
      }

      @keyframes shake1 {
        0% {
          opacity: 1;
        }

        25% {
          opacity: 0;
        }

        100% {
          opacity: 1;
        }
      }

      @keyframes shake2 {
        0% {
          opacity: 1;
        }

        50% {
          opacity: 0;
        }

        100% {
          opacity: 1;
        }
      }

      @keyframes shake3 {
        0% {
          opacity: 1;
        }

        75% {
          opacity: 0;
        }

        100% {
          opacity: 1;
        }
      }

      @keyframes shake4 {
        0% {
          opacity: 1;
        }

        100% {
          opacity: 0;
        }
      }
    }
  }
</style>
