const { mock } = require('mockjs')

const leftTopList = []
const rightBottomList = []

leftTopList.push(
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'image-2-line',
    txt: '开发者',
    num: '90000 +',
  },
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'money-cny-box-line',
    txt: '帮助企业',
    num: '10000 +',
  },
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'archive-line',
    txt: '招商项目',
    num: '6000 +',
  },
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'map-pin-user-line',
    txt: '提供就业',
    num: '50000 +',
  },
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'user-5-line',
    txt: '帮助小白',
    num: '10000 +',
  },
  {
    uuid: '@uuid',
    id: '@id',
    icon: 'user-heart-line',
    txt: '结交朋友',
    num: '100 +',
  }
)

for (let i = 0; i < 10; i++) {
  rightBottomList.push(
    mock({
      uuid: '@uuid',
      id: '@id',
      avatar: 'https://i.gtimg.cn/club/item/face/img/5/14205_100.gif',
      name: '@title(1, 2)',
      description: '@title(1, 10)',
      datetime: '@datetime',
    })
  )
}
module.exports = [
  {
    url: '/index/getLeftTopList',
    type: 'get',
    response: () => {
      return {
        code: 200,
        msg: 'success',
        data: { list: leftTopList, ...{ total: leftTopList.length } },
      }
    },
  },
  {
    url: '/index/getRightBottomList',
    type: 'get',
    response: () => {
      return {
        code: 200,
        msg: 'success',
        data: { list: rightBottomList, ...{ total: rightBottomList.length } },
      }
    },
  },
]
