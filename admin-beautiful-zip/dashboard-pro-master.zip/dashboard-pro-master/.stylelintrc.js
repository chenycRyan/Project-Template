module.exports = {
  extends: ['stylelint-config-recess-order', 'stylelint-config-prettier'],
}
