module.exports = {
  // 开发工具控制台名字显示
  webpackBarName: 'dashboard-pro',
  // 浏览器注释显示
  webpackBanner:
    ' build: dashboard-pro \n copyright: chuzhixin 1204505056@qq.com \n time: ',
}
