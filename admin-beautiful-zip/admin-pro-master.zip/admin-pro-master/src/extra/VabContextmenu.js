import { directive, VabContextmenu, VabContextmenuItem } from 'vab-contextmenu'
import 'vab-contextmenu/dist/vab-contextmenu.css'

export { directive, VabContextmenu, VabContextmenuItem }
