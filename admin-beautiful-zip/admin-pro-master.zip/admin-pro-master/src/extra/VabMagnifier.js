import VabMagnifier from 'vab-magnifier'
import 'vab-magnifier/lib/vab-magnifier.css'

export default VabMagnifier
