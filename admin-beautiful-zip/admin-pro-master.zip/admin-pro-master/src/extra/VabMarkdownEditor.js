import VabMarkdownEditor from 'zx-markdown-editor'
import 'zx-markdown-editor/dist/zx-markdown-editor.css'

export default VabMarkdownEditor
