<template>
  <el-config-provider
    :button="{
      autoInsertSpace: true,
    }"
    :locale="messages[locale]"
  >
    <router-view />
    <vab-update ref="vabUpdateRef" />
  </el-config-provider>
</template>

<script>
  import i18n from '@/i18n'

  export default defineComponent({
    name: 'VabApp',
    components: {
      VabUpdate: defineAsyncComponent(() => import('@/plugins/VabUpdate')),
    },
    setup() {
      const locale = toRef(i18n.global, 'locale')
      const messages = toRef(i18n.global, 'messages')

      return {
        locale,
        messages,
      }
    },
  })
</script>
