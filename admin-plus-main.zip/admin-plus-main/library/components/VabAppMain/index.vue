<template>
  <div class="vab-app-main">
    <section>
      <VabRouterView />
    </section>
    <vab-footer />
  </div>
</template>

<script>
  export default defineComponent({
    name: 'VabAppMain',
  })
</script>
