<script setup>
  import { useFullscreen } from '@vueuse/core'

  const { isFullscreen, toggle } = useFullscreen()

  const store = useStore()
  const theme = computed(() => store.getters['settings/theme'])
</script>

<template>
  <vab-icon
    v-if="theme.showFullScreen"
    :icon="isFullscreen ? 'fullscreen-exit-fill' : 'fullscreen-fill'"
    @click="toggle"
  />
</template>
