<template>
  <vab-app />
</template>

<script>
  export default defineComponent({
    name: 'App',
  })
</script>
