<template>
  <div class="github-external-link-container"></div>
</template>

<script>
  export default {
    name: 'GithubExternalLink',
    setup() {
      // const router = useRouter()
      onMounted(() => {
        //window.open(router.path)
      })
    },
  }
</script>
