import 'vab-quill/lib/vab-quill.css'
import VabQuill from 'vab-quill'

export default VabQuill
