import VabCount from 'vab-count'

export default VabCount
